#!/usr/bin/env bash
# Source from a build script. Keep the pinned upstream clone unmodified; each
# patch revision gets its own worktree and static-library cache.
preview_component=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
preview_ffmpeg_patch="$preview_component/patches/matroska-preview-fast-seek.patch"
preview_ffmpeg_pin=946fcce07b6dcd0331c8cc609192aeff5e1924f8
preview_ffmpeg_key=$(sha256sum "$preview_ffmpeg_patch" | cut -c1-16)
if [ ! -d /output/ffmpeg/.git ]; then
  git init /output/ffmpeg
  git -C /output/ffmpeg remote add origin https://github.com/FFmpeg/FFmpeg.git
  git -C /output/ffmpeg fetch --depth 1 origin "$preview_ffmpeg_pin"
  git -C /output/ffmpeg checkout --detach FETCH_HEAD
fi
test "$(git -C /output/ffmpeg rev-parse HEAD)" = "$preview_ffmpeg_pin"
preview_ffmpeg_source="/output/ffmpeg-preview-$preview_ffmpeg_key"
if [ ! -e "$preview_ffmpeg_source/.git" ]; then
  git -C /output/ffmpeg worktree add --detach "$preview_ffmpeg_source" "$preview_ffmpeg_pin"
fi
test "$(git -C "$preview_ffmpeg_source" rev-parse HEAD)" = "$preview_ffmpeg_pin"
if git -C "$preview_ffmpeg_source" apply --check "$preview_ffmpeg_patch" 2>/dev/null; then
  git -C "$preview_ffmpeg_source" apply "$preview_ffmpeg_patch"
else
  git -C "$preview_ffmpeg_source" apply --reverse --check "$preview_ffmpeg_patch"
fi
test "$(git -C "$preview_ffmpeg_source" diff --name-only)" = libavformat/matroskadec.c
# Reject cache edits outside the reviewed patch, including edits in the same file.
test "$(git -C "$preview_ffmpeg_source" hash-object libavformat/matroskadec.c)" = d3624c007b1d0feeed5828c8b414c484c09ee73c
