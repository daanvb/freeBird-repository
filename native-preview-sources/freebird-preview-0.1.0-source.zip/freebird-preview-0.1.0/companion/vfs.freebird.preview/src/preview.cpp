#include "preview.h"
#include <algorithm>
#include <charconv>
#include <cmath>
#include <cstring>
#include <memory>
#include <stdexcept>
#include <vector>
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/opt.h>
#include <libswscale/swscale.h>
}

namespace preview {
namespace {
using Clock = std::chrono::steady_clock;
constexpr int64_t kPixels = 4096LL * 2160;
constexpr size_t kJpegBytes = 512 * 1024;
constexpr int64_t kPacketBytes = 8 * 1024 * 1024;
struct Stop {
  std::atomic<bool>& cancelled;
  Clock::time_point deadline = Clock::now() + std::chrono::seconds(5);
  bool Stopped() const { return cancelled || Clock::now() >= deadline; }
  static int Interrupt(void* opaque) { return static_cast<Stop*>(opaque)->Stopped(); }
  void Check() const { if (Stopped()) throw std::runtime_error("stopped"); }
};
struct Resources {
  AVFormatContext* input = nullptr;
  AVCodecContext *decoder = nullptr, *encoder = nullptr;
  AVPacket* packet = av_packet_alloc();
  AVFrame *frame = av_frame_alloc(), *scaled = av_frame_alloc();
  SwsContext* scaler = nullptr;
  AVDictionary* options = nullptr;
  ~Resources() {
    av_dict_free(&options);
    sws_freeContext(scaler);
    av_frame_free(&scaled); av_frame_free(&frame); av_packet_free(&packet);
    avcodec_free_context(&encoder); avcodec_free_context(&decoder);
    avformat_close_input(&input);
  }
};
void Require(bool good) { if (!good) throw std::runtime_error("decode"); }
bool Hex(const std::string& s) {
  return s.size() == 32 && s.find_first_not_of("0123456789abcdef") == std::string::npos;
}
bool Number(const std::string& text, int64_t maximum, int64_t& value) {
  if (text.empty() || text.size() > 12 || text.find_first_not_of("0123456789") != std::string::npos)
    return false;
  auto result = std::from_chars(text.data(), text.data()+text.size(), value);
  return result.ec == std::errc() && result.ptr == text.data()+text.size() && value <= maximum;
}
std::vector<std::string> Split(const std::string& text) {
  std::vector<std::string> out;
  size_t start = 0;
  for (;;) {
    auto end = text.find('/', start);
    out.push_back(text.substr(start, end == std::string::npos ? end : end-start));
    if (end == std::string::npos) return out;
    start = end + 1;
  }
}
std::string Decode(const std::string& source, const std::string& container,
                   int64_t milliseconds, Stop& stop) {
  Resources r;
  Require(r.packet && r.frame && r.scaled);
  r.input = avformat_alloc_context();
  Require(r.input);
  r.input->interrupt_callback = {Stop::Interrupt, &stop};
  r.input->probesize = 1024 * 1024;
  r.input->max_analyze_duration = AV_TIME_BASE;
  av_dict_set(&r.options, "protocol_whitelist", "http,tcp", 0);
  av_dict_set(&r.options, "rw_timeout", "1000000", 0);
  av_dict_set(&r.options, "max_streams", "8", 0);
  av_dict_set(&r.options, "enable_drefs", "0", 0);
  av_dict_set(&r.options, "use_absolute_path", "0", 0);
  const AVInputFormat* format = av_find_input_format(container.c_str());
  Require(format);
  stop.Check();
  Require(avformat_open_input(&r.input, source.c_str(), format, &r.options) >= 0);
  av_dict_free(&r.options);
  // Codec parameters in MKV/MP4 headers suffice. Avoid a broad stream-info decode pass.
  int video = -1;
  for (unsigned i = 0; i < r.input->nb_streams; ++i) {
    auto* params = r.input->streams[i]->codecpar;
    if (video < 0 && params->codec_type == AVMEDIA_TYPE_VIDEO &&
        !(r.input->streams[i]->disposition & AV_DISPOSITION_ATTACHED_PIC)) video = i;
    else r.input->streams[i]->discard = AVDISCARD_ALL;
  }
  Require(video >= 0);
  auto* stream = r.input->streams[video];
  auto* parameters = stream->codecpar;
  Require(parameters->codec_id == AV_CODEC_ID_H264 || parameters->codec_id == AV_CODEC_ID_HEVC);
  Require(parameters->width > 0 && parameters->height > 0 &&
          int64_t(parameters->width) * parameters->height <= kPixels);
  r.decoder = avcodec_alloc_context3(avcodec_find_decoder(parameters->codec_id));
  Require(r.decoder);
  Require(avcodec_parameters_to_context(r.decoder, parameters) >= 0);
  r.decoder->thread_count = 1;
  r.decoder->thread_type = 0;
  r.decoder->max_pixels = kPixels;
  r.decoder->skip_frame = AVDISCARD_NONKEY;
  Require(avcodec_open2(r.decoder, nullptr, nullptr) >= 0);
  int64_t origin = stream->start_time == AV_NOPTS_VALUE ? 0 : stream->start_time;
  int64_t seek = origin + av_rescale_q(milliseconds, AVRational{1,1000}, stream->time_base);
  stop.Check();
  Require(av_seek_frame(r.input, video, seek, AVSEEK_FLAG_BACKWARD) >= 0);
  avcodec_flush_buffers(r.decoder);
  int64_t bytes = 0;
  bool picture = false;
  for (int packets = 0; packets < 160 && !picture; ++packets) {
    stop.Check();
    int read = av_read_frame(r.input, r.packet);
    if (read < 0 && read != AVERROR_EOF) break;
    if (read >= 0) {
      bytes += r.packet->size;
      Require(bytes <= kPacketBytes);
      if (r.packet->stream_index != video) { av_packet_unref(r.packet); continue; }
    }
    int sent = avcodec_send_packet(r.decoder, read == AVERROR_EOF ? nullptr : r.packet);
    av_packet_unref(r.packet);
    Require(sent >= 0);
    int got = avcodec_receive_frame(r.decoder, r.frame);
    picture = got >= 0;
    if (!picture) Require(got == AVERROR(EAGAIN) || got == AVERROR_EOF);
    if (read == AVERROR_EOF) break;
  }
  Require(picture && r.frame->width > 0 && r.frame->height > 0 &&
          int64_t(r.frame->width) * r.frame->height <= kPixels);
  stop.Check();
  // Preserve display aspect (including non-square pixels), but never upscale.
  AVRational sar = av_guess_sample_aspect_ratio(r.input, stream, r.frame);
  double aspect = double(r.frame->width) / r.frame->height;
  if (sar.num > 0 && sar.den > 0) aspect *= av_q2d(sar);
  Require(std::isfinite(aspect) && aspect > 0);
  int width = std::min(384, r.frame->width);
  // Clamp in floating point before conversion: malformed SAR can exceed int.
  int height = int(std::min({216.0, double(r.frame->height), width / aspect}));
  width = int(std::min(double(width), height * aspect));
  width &= ~1; height &= ~1;
  Require(width >= 2 && height >= 2);
  const AVCodec* jpeg = avcodec_find_encoder(AV_CODEC_ID_MJPEG);
  Require(jpeg);
  r.encoder = avcodec_alloc_context3(jpeg);
  Require(r.encoder);
  r.encoder->width = width; r.encoder->height = height;
  r.encoder->pix_fmt = AV_PIX_FMT_YUVJ420P;
  r.encoder->color_range = AVCOL_RANGE_JPEG;
  r.encoder->time_base = {1,25};
  r.encoder->thread_count = 1;
  r.encoder->flags |= AV_CODEC_FLAG_QSCALE;
  r.encoder->global_quality = 5 * FF_QP2LAMBDA;
  Require(avcodec_open2(r.encoder, jpeg, nullptr) >= 0);
  r.scaled->format = r.encoder->pix_fmt;
  r.scaled->width = width; r.scaled->height = height;
  r.scaled->quality = r.encoder->global_quality;
  r.scaled->color_range = AVCOL_RANGE_JPEG;
  Require(av_frame_get_buffer(r.scaled, 32) >= 0);
  r.scaler = sws_getContext(r.frame->width, r.frame->height,
      static_cast<AVPixelFormat>(r.frame->format), width, height, r.encoder->pix_fmt,
      SWS_FAST_BILINEAR, nullptr, nullptr, nullptr);
  Require(r.scaler);
  Require(sws_scale(r.scaler, r.frame->data, r.frame->linesize, 0, r.frame->height,
      r.scaled->data, r.scaled->linesize) == height);
  stop.Check();
  Require(avcodec_send_frame(r.encoder, r.scaled) >= 0);
  Require(avcodec_receive_packet(r.encoder, r.packet) >= 0);
  Require(r.packet->size >= 100 && size_t(r.packet->size) <= kJpegBytes);
  int64_t stamp = r.frame->best_effort_timestamp;
  Require(stamp != AV_NOPTS_VALUE);
  stamp = av_rescale_q(stamp-origin, stream->time_base, AVRational{1,1000});
  Require(stamp >= 0);
  stop.Check();
  return "FBP1\n" + std::to_string(stamp) + "\n" +
         std::string(reinterpret_cast<char*>(r.packet->data), r.packet->size);
}
}

Service::~Service() {
  cancelled_ = true;
  if (worker_.joinable()) worker_.join();
}

std::string Service::Request(const std::string& url) {
  const std::string prefix = FREEBIRD_PREVIEW_PROTOCOL "://";
  if (url.size() > 256 || url.compare(0, prefix.size(), prefix) != 0) return "invalid\n";
  auto parts = Split(url.substr(prefix.size()));
  if (parts == std::vector<std::string>{"capabilities", ""})
    return "{\"protocol\":1,\"codecs\":[\"h264\",\"hevc\"],\"max_width\":384,\"max_height\":216,\"experimental\":true}\n";
  if (parts.size() < 2 || !Hex(parts[1])) return "invalid\n";
  const auto& operation = parts[0];
  const auto& id = parts[1];
  std::lock_guard<std::mutex> lock(mutex_);
  if (operation == "start" && parts.size() == 6) {
    int64_t port = 0, time = 0;
    if (!Number(parts[2], 65535, port) || port < 1024 || !Hex(parts[3]) ||
        (parts[4] != "matroska" && parts[4] != "mov") || !Number(parts[5], 604800000, time))
      return "invalid\n";
    if (running_) return "busy\n";
    // The worker releases mutex_ only after publishing its result; joining here
    // cannot wait for decode/I/O or require this mutex again.
    if (worker_.joinable()) worker_.join();
    id_ = id; result_.clear(); cancelled_ = false; running_ = true;
    auto source = "http://127.0.0.1:" + std::to_string(port) + "/" + parts[3];
    auto container = parts[4];
    try {
      worker_ = std::thread([this, source, container, time]() {
        Stop stop{cancelled_};
        std::string response;
        try { response = Decode(source, container, time, stop); }
        catch (...) { response = "failed\n"; }
        std::lock_guard<std::mutex> done(mutex_);
        if (cancelled_) response = "cancelled\n";
        else if (Clock::now() >= stop.deadline) response = "timeout\n";
        result_ = std::move(response);
        running_ = false;
      });
    } catch (...) { running_ = false; result_ = "failed\n"; return "failed\n"; }
    return "accepted\n";
  }
  if (parts.size() != 2 || (operation != "result" && operation != "cancel" && operation != "release"))
    return "invalid\n";
  if (id != id_) return "missing\n";
  if (operation == "cancel") {
    cancelled_ = true;
    if (!running_) result_ = "cancelled\n";
    return "cancelled\n";
  }
  if (operation == "release") {
    if (running_) { cancelled_ = true; return "busy\n"; }
    result_.clear(); id_.clear(); return "released\n";
  }
  return running_ ? "pending\n" : result_;
}
}
