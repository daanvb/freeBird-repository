# Native seek-preview decoder

Experimental Kodi VFS addon, version 0.1.0, selected by the preview worker on
Android when installed. Enabling seek previews in freeBird Playback settings
requests its installation through Kodi. It is packaged separately from the app. It does
not depend on FFmpeg Direct or an FFmpeg command. Android packages contain a
minimal, statically linked FFmpeg library with private symbols.

CoreELEC keeps the existing optional FFmpeg Tools executable backend. This source
can be adapted to a CoreELEC native addon, but the Linux x86-64 test build is not a
CoreELEC ARM package. Do not install Android builds on CoreELEC.

## Boundary and protocol

The existing Python `core.seek_preview.Decoder` can provide its authenticated,
bounded loopback range proxy without starting its subprocess. The helper accepts
only the proxy's port and random token, a forced MKV/MP4 demuxer and a timestamp.
Original media URLs and credentials stay with the Python reader. The caller must
keep its five-second/8 MiB per-frame and 64 MiB session budgets active; the native
8 MiB packet limit does not independently bound all demuxer/network reads.

`core/native_preview.py` wraps `xbmcvfs.File` on the existing background preview
worker. Requests use a variant-specific protocol, such as
`freebirdpreviewomegaarmv7://`; the host harness uses `freebirdpreview://`:

| Path | Response |
| --- | --- |
| `capabilities/` | JSON, protocol version 1 |
| `start/<request-id>/<port>/<token>/<matroska-or-mov>/<milliseconds>` | `accepted`, `busy`, `invalid` or `failed` |
| `result/<request-id>` | `pending`, failure status, or `FBP1\n<actual-ms>\n<JPEG>` |
| `cancel/<request-id>` | Cooperative cancellation; no wait for decode |
| `release/<request-id>` | Release finished result; cancel and return `busy` if active |

Addon IDs are `vfs.freebird.preview.<omega|piers>.<armv7|aarch64>`. Independent
IDs/protocols let the ordinary update feed carry all four packages without a
custom repository installer. Selection uses Kodi's major version and the Python
process pointer width, with an ARM machine check. The dependencies are optional
so unsupported devices can still install the app. Enabling the setting is the
only installation trigger; the playback worker only discovers/retries locally.

IDs/tokens are 32 lowercase hex characters. Replies are immutable per opened VFS
file, bounded to 512 KiB plus a short header. All VFS instances share one active
job. A replacement cannot overlap a cancelled worker; old IDs cannot read the
replacement result. The caller must release a finished job before reusing its
client, cancel when retiring a session, and reject results from retired sessions.

Initial scope: H.264 and HEVC, MKV and MP4, software keyframes, one decoder thread,
up to 4096×2160 decoded pixels and 384×216 JPEGs preserving sample aspect ratio.
The helper returns the actual frame timestamp. Stream probing is limited; audio,
subtitles and attached pictures are discarded. A five-second deadline, interrupt
callback, one-second socket timeout and packet limits bound cooperative work.

There is no hard CPU timeout inside FFmpeg, process crash isolation, HDR tone
mapping, display-rotation handling, hardware decode, HLS, DRM or AV1 support.
Closing the addon joins its worker. Each request currently opens a fresh demuxer
and decoder; **warm decoder/index reuse is still future performance work**.

## Reproduce builds

Docker commands below run from the repository root in a POSIX shell. Bind the
source read-only, use an empty writable output directory, and never mount Kodi
profiles or device data. On Windows use equivalent absolute `--mount` paths.

```sh
docker build --target host -t freebird-preview-build:0.0.1 -f companion/vfs.freebird.preview/Dockerfile .
docker build --target android -t freebird-preview-android:0.0.1 -f companion/vfs.freebird.preview/Dockerfile .
mkdir -p .test-run-tmp/native-preview
docker volume create freebird-preview-poc-build
docker run --rm --cpus 4 --memory 3g \
  --mount "type=bind,source=$PWD,target=/work,readonly" \
  --mount type=volume,source=freebird-preview-poc-build,target=/output \
  --mount "type=bind,source=$PWD/.test-run-tmp/native-preview,target=/artifacts" \
  freebird-preview-android:0.0.1 bash -c '
    set -e
    for kodi in omega piers; do
      for abi in armeabi-v7a arm64-v8a; do
        bash companion/vfs.freebird.preview/build_android.sh "$abi" "$kodi"
        mkdir -p "/artifacts/$kodi-$abi"
        cp -a "/output/$abi/package-$kodi/vfs.freebird.preview" "/artifacts/$kodi-$abi/"
      done
    done'
```

Pins: Kodi Omega `f8815ee40f49a700c047982d752be4b2a61420e2`, Piers
`60b9c6b0f7fe7bbb932f7140b4662627f94d7400`, FFmpeg n9.0.2
`946fcce07b6dcd0331c8cc609192aeff5e1924f8`, Android NDK r30 (official archive
checksum verified in the Dockerfile), Android API 21, static C++ runtime.
FFmpeg source/configuration and license stay in the build volume. Use a fresh
volume when changing its pinned version or configuration; the script reuses its
completed static-library build. Ubuntu build packages are not version-pinned, so
these instructions do not claim byte-identical builds across future hosts.

Kodi 21 uses global ABI 2.0.2/minimum 2.0.0; the pinned Kodi 22 SDK uses
2.0.4/minimum 2.0.3. Both use VFS 3.0.1. The manifest derives its versions from the
selected SDK. Choose **Kodi's process ABI**, which can differ from the device CPU.

Package on a development Python installation with `pyelftools` available:

```sh
python tools/package-native-preview.py \
  --package .test-run-tmp/native-preview/omega-armeabi-v7a/vfs.freebird.preview \
  --kodi omega --output .test-run-tmp/native-preview/zips
```

Repeat for the other three combinations. The packager rejects a mismatched ABI,
unexpected exported symbols/dependencies, text relocations or missing 16 KiB
alignment. It includes only the manifest, library and license/notices. These are
release artifacts. The publication also includes matching helper, FFmpeg and
Kodi SDK source archives under `native-preview-sources/` and their checksums.
`tools/build-kodi-repository.py --extra-package` adds the four validated packages;
later app-only feed builds preserve the existing native dependencies.

## Host verification

The harness `dlopen`s the real addon and drives its exported Kodi C ABI and VFS
callbacks. It does not simulate native decoding: FFmpeg extracts actual frames.
It does not prove Kodi's Android loader or Python VFS path on a device.

```sh
docker run --rm --network none --cpus 4 --memory 2g \
  --mount "type=bind,source=$PWD,target=/work,readonly" \
  --mount "type=bind,source=$PWD/.test-run-tmp/native-preview,target=/output" \
  freebird-preview-build:0.0.1 bash -c '
    set -e
    cmake -S companion/vfs.freebird.preview -B /output/host -G Ninja -DCMAKE_BUILD_TYPE=Release
    cmake --build /output/host -j4
    python3 tools/verify-native-preview.py --driver /output/host/preview_driver'
```

This command uses Ubuntu's FFmpeg 6.1.1. The proof was also tested against the
same minimal FFmpeg 9.0.2 source/configuration as Android, compiled for the Linux
host with `--disable-x86asm` and without Android compiler/target flags. Point
CMake's `FFMPEG_PREFIX` at that static installation, and `KODI_HEADERS` at either
SDK to reproduce those runs. Synthetic fixtures still use the host ffmpeg CLI.

For helper AddressSanitizer/UndefinedBehaviorSanitizer checks, configure a
separate host build with `-DCMAKE_BUILD_TYPE=Debug`,
`-DCMAKE_CXX_FLAGS="-fsanitize=address,undefined -fno-omit-frame-pointer"` and both
`CMAKE_SHARED_LINKER_FLAGS`/`CMAKE_EXE_LINKER_FLAGS` set to
`-fsanitize=address,undefined`. Run with `ASAN_OPTIONS=detect_leaks=1` and
`UBSAN_OPTIONS=halt_on_error=1`. System FFmpeg itself is not instrumented.

Eight tests cover real H.264/10-bit SDR HEVC scenes in both containers (12 frame
checks), timestamps, anamorphic aspect, invalid requests/replies, busy/replacement
and stale IDs, cancellation, trickling HTTP timeout, malformed media and oversized
dimensions, plus the production Python adapter and persistent timestamp cache.
Timings printed by the harness describe tiny synthetic local files
on the development PC, not 4K/network/device performance or a controlled speedup
comparison against the executable backend.

Device test: update freeBird and its Player skin, then enable **Playback → Seek
preview images (experimental)** and accept Kodi's decoder installation prompt.
Play a direct MKV/MP4 movie or episode; pause briefly, open the seek bar and move
Left/Right. **Press OK to seek** makes inspection easier. Check rapid direction
changes, Back/Stop/episode replacement and normal playback smoothness. Disable
previews to compare. Real Kodi loading, HDR/DV colour, RAM/CPU and device speed
remain unverified until this user test; the feature stays off by default.
