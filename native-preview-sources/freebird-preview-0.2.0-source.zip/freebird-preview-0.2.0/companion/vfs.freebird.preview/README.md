# Native seek-preview decoder

Experimental Kodi VFS addon, version 0.2.0, selected by the preview worker on
Android when installed. Enabling seek previews in freeBird Playback settings
requests its installation through Kodi. It is packaged separately from the app. It does
not depend on FFmpeg Direct or an FFmpeg command. Android packages contain a
minimal, statically linked FFmpeg library with private symbols.

CoreELEC keeps the existing optional FFmpeg Tools executable backend. This source
can be adapted to a CoreELEC native addon, but the Linux x86-64 test build is not a
CoreELEC ARM package. Do not install Android builds on CoreELEC.

## Boundary and protocol

App 1.8.287 negotiates persistent sessions through `session_protocol: 2` in the
existing protocol-1 capabilities. Older apps keep their original endpoint;
older decoder addons still work with the new app. Only one backend can own native
resources at a time; switching modes waits for active work to finish.

Persistent requests use the same protocol with a `session/` path prefix. Its
capabilities advertise protocol 2, `persistent`, `prepare` and `index_lease`.
`start` adds the known source byte size; `prepare` uses the same fields and time
zero. `lease/<source-token>/<generation>` retains only the exact unexpired index;
`close/<source-token>` retires it. Each index generation is unique across mode
switches. See the [implementation and evidence](../../docs/seek-preview-session-prototype.md).

The production worker waits for five seconds of fresh, healthy snapshots with
at least 25 seconds of conservative headroom (or local/paused playback). It makes
one index-only preparation attempt, capped at ten seconds/8 MiB, and yields to
foreground input or lost eligibility. The existing 15-second playback guard
still applies during work. Preparation reserves one picture's rolling allowance.
The attempt latch and rolling downloads survive decoder recreation for the same
playback source/track. The worker renews the index every ten seconds without I/O;
missed leases expire after thirty seconds. Decoder buffers expire independently
after thirty idle seconds, or immediately after pictures larger than 1080p.

The existing Python `core.seek_preview.Decoder` can provide its authenticated,
bounded loopback range proxy without starting its subprocess. The helper accepts
only the proxy's port and random token, a forced MKV/MP4 demuxer and a timestamp.
Original media URLs and credentials stay with the Python reader. The caller must
keep its five-second/8 MiB per-attempt and 64 MiB/60-second rolling budgets active; the native
8 MiB packet limit does not independently bound all demuxer/network reads.

`core/native_preview.py` wraps `xbmcvfs.File` on the existing background preview
worker. Requests use a variant-specific protocol, such as
`freebirdpreviewomegaarmv7://`; the host harness uses `freebirdpreview://`:

| Path | Response |
| --- | --- |
| `capabilities/` | JSON, protocol version 1 |
| `start/<request-id>/<port>/<token>/<matroska-or-mov>/<milliseconds>` | `accepted`, `busy`, `invalid` or `failed` |
| `result/<request-id>` | `pending`, failure status, or `FBP1\n<actual-ms>\n<JPEG>` |
| `cancel/<request-id>` | Cooperative cancellation; no wait for decode |
| `release/<request-id>` | Release finished result; cancel and return `busy` if active |

Addon IDs are `vfs.freebird.preview.<omega|piers>.<armv7|aarch64>`. Independent
IDs/protocols let the ordinary update feed carry all four packages without a
custom repository installer. Selection uses Kodi's major version and the Python
process pointer width, with an ARM machine check. The dependencies are optional
so unsupported devices can still install the app. Enabling the setting is the
only installation trigger; the playback worker only discovers/retries locally.

IDs/tokens are 32 lowercase hex characters. Replies are immutable per opened VFS
file, bounded to 512 KiB plus a short header. All VFS instances share one active
job. A replacement cannot overlap a cancelled worker; old IDs cannot read the
replacement result. The caller must release a finished job before reusing its
client, cancel when retiring a session, and reject results from retired sessions.

Initial scope: H.264 and HEVC, MKV and MP4, software keyframes, one decoder thread,
up to 4096Ã—2160 decoded pixels and 384Ã—216 JPEGs preserving sample aspect ratio.
The helper returns the actual frame timestamp. Stream probing is limited; audio,
subtitles and attached pictures are discarded. A five-second deadline, interrupt
callback, five-second socket timeout and packet limits bound cooperative work.
Version 0.1.3 skips Matroska attachment payloads (fonts/cover art) through an
explicit `preview_skip_attachments` demuxer option, disabled by default. Element
bounds are still validated; unknown attachment sizes fail instead of scanning.
The helper bounds loopback HTTP requests and short forward reads to 32 KiB so
TCP buffering cannot silently fetch the rest of a discarded response. Remote
cache blocks remain 512 KiB; deadlines, byte limits and retries are unchanged.
An attached-font 1080p fixture that timed out twice with 0.1.2 returns its first
picture in 1.925s and repeats in 0.063s on the host with simulated network cost.
This does not establish the cause of the user's remaining Shield timeout.

Version 0.1.2 drains a decoded keyframe immediately when frame reordering would
otherwise hold it until later keyframes arrive. Only one picture is required;
reading through later GOPs can exhaust the deadline even with cached data.
The bundled FFmpeg patch also lets an explicitly fast backward Matroska seek
use its final known cue without scanning the remaining clusters. The helper sets
`AVFMT_FLAG_FAST_SEEK` only for Matroska. Missing entries, broken cues and ordinary
seeks retain the upstream fallback. Actual frame timestamps and all limits stay
unchanged; Kodi's main-player FFmpeg and CoreELEC's executable are not modified.

Version 0.1.1 removes the premature one-second loopback timeout; the original
five-second overall deadline remains. App 1.8.284 permits one bounded retry of
a focused timeout only when the first attempt cached new source blocks. Updating
the app alone does not replace an installed 0.1.0 native library: update the
matching decoder addon as well, then restart Kodi.

There is no hard CPU timeout inside FFmpeg, process crash isolation, HDR tone
mapping, display-rotation handling, hardware decode, HLS, DRM or AV1 support.
Closing the addon joins its worker. Protocol 1 opens a fresh demuxer and decoder
per request; protocol 2 retains the owned index and eligible decoder allocations.

## Reproduce builds

Docker commands below run from the repository root in a POSIX shell. Bind the
source read-only, use an empty writable output directory, and never mount Kodi
profiles or device data. On Windows use equivalent absolute `--mount` paths.

```sh
docker build --target host -t freebird-preview-build:0.0.1 -f companion/vfs.freebird.preview/Dockerfile .
docker build --target android -t freebird-preview-android:0.0.1 -f companion/vfs.freebird.preview/Dockerfile .
mkdir -p .test-run-tmp/native-preview
docker volume create freebird-preview-poc-build
docker run --rm --cpus 4 --memory 3g \
  --mount "type=bind,source=$PWD,target=/work,readonly" \
  --mount type=volume,source=freebird-preview-poc-build,target=/output \
  --mount "type=bind,source=$PWD/.test-run-tmp/native-preview,target=/artifacts" \
  freebird-preview-android:0.0.1 bash -c '
    set -e
    for kodi in omega piers; do
      for abi in armeabi-v7a arm64-v8a; do
        bash companion/vfs.freebird.preview/build_android.sh "$abi" "$kodi"
        mkdir -p "/artifacts/$kodi-$abi"
        cp -a "/output/$abi/package-$kodi/vfs.freebird.preview" "/artifacts/$kodi-$abi/"
      done
    done'
```

Pins: Kodi Omega `f8815ee40f49a700c047982d752be4b2a61420e2`, Piers
`60b9c6b0f7fe7bbb932f7140b4662627f94d7400`, FFmpeg n9.0.2
`946fcce07b6dcd0331c8cc609192aeff5e1924f8`, Android NDK r30 (official archive
checksum verified in the Dockerfile), Android API 21, static C++ runtime.
FFmpeg source/configuration and license stay in the build volume. The upstream
clone stays clean. `ffmpeg_source.sh` creates a separate patched worktree, checks
its exact source hash, and keys static-library caches by the patch hash. CMake
rejects an unpatched or mismatched FFmpeg prefix. Use a fresh volume when changing
the pinned upstream version or compiler/configuration; completed builds are reused. Ubuntu build packages are not version-pinned, so
these instructions do not claim byte-identical builds across future hosts.

Kodi 21 uses global ABI 2.0.2/minimum 2.0.0; the pinned Kodi 22 SDK uses
2.0.4/minimum 2.0.3. Both use VFS 3.0.1. The manifest derives its versions from the
selected SDK. Choose **Kodi's process ABI**, which can differ from the device CPU.

Package on a development Python installation with `pyelftools` available:

```sh
python tools/package-native-preview.py \
  --package .test-run-tmp/native-preview/omega-armeabi-v7a/vfs.freebird.preview \
  --kodi omega --output .test-run-tmp/native-preview/zips
```

Repeat for the other three combinations. The packager rejects a mismatched ABI,
unexpected exported symbols/dependencies, text relocations or missing 16 KiB
alignment. It includes only the manifest, library and license/notices. These are
release artifacts. The publication also includes matching helper, FFmpeg and
Kodi SDK source archives under `native-preview-sources/` and their checksums.
`tools/build-kodi-repository.py --extra-package` adds the four validated packages;
later app-only feed builds preserve the existing native dependencies.

## Host verification

The harness `dlopen`s the real addon and drives its exported Kodi C ABI and VFS
callbacks. It does not simulate native decoding: FFmpeg extracts actual frames.
It does not prove Kodi's Android loader or Python VFS path on a device.

```sh
docker run --rm --cpus 4 --memory 2g \
  --mount "type=bind,source=$PWD,target=/work,readonly" \
  --mount "type=bind,source=$PWD/.test-run-tmp/native-preview,target=/output" \
  freebird-preview-build:0.0.1 bash -c '
    set -e
    bash companion/vfs.freebird.preview/build_host.sh /output/host
    python3 tools/verify-native-preview.py --driver /output/host/preview_driver
    python3 tools/verify-session-preview.py --integrated --driver /output/host/preview_driver'
```

This command builds the same patched minimal FFmpeg 9.0.2 as Android, using
`--disable-x86asm` and host compiler flags. It needs network access only to fetch
the pinned source initially; cached builds/tests can run with `--network none`.
Set `KODI_HEADERS` to the pinned Piers SDK to repeat against Kodi 22. Synthetic
fixtures use the host ffmpeg CLI; extraction uses the bundled patched libraries.

For helper AddressSanitizer/UndefinedBehaviorSanitizer checks, configure a
separate host build with the patched `FFMPEG_PREFIX`, `-DCMAKE_BUILD_TYPE=Debug`,
`-DCMAKE_CXX_FLAGS="-fsanitize=address,undefined -fno-omit-frame-pointer"` and both
`CMAKE_SHARED_LINKER_FLAGS`/`CMAKE_EXE_LINKER_FLAGS` set to
`-fsanitize=address,undefined`. Run with `ASAN_OPTIONS=detect_leaks=1` and
`UBSAN_OPTIONS=halt_on_error=1`. The linked static FFmpeg itself is not instrumented unless separately rebuilt with sanitizers.

Eleven tests cover real H.264/10-bit SDR HEVC scenes in both containers (12 frame
checks), a streamed 4K/10-bit HEVC fixture with 300 ms per-request latency,
a 1080p fixture with 1.2/2.2-second response delays and a cache-warmed retry,
long-GOP/B-frame MKV/MP4 cold and repeated seeks including the final indexed GOP,
timestamps, anamorphic aspect, invalid requests/replies, busy/replacement
and stale IDs, cancellation, trickling HTTP timeout, malformed media and oversized
dimensions, plus the production Python adapter and persistent timestamp cache.
The local timing summary describes tiny synthetic local files; separate 4K
measurements include the controlled range-request latency. These are development
host measurements, not Fire TV results or a controlled speedup comparison against
the executable backend.

Device test: update freeBird and its Player skin, then enable **Playback â†’ Seek
preview images (experimental)** and accept Kodi's decoder installation prompt.
Play a direct MKV/MP4 movie or episode; pause briefly, open the seek bar and move
Left/Right. **Press OK to seek** makes inspection easier. Check rapid direction
changes, Back/Stop/episode replacement and normal playback smoothness. Disable
previews to compare. Real Kodi loading, HDR/DV colour, RAM/CPU and device speed
remain unverified until this user test; the feature stays off by default.
