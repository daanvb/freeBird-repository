#!/usr/bin/env bash
set -euo pipefail
source /work/companion/vfs.freebird.preview/ffmpeg_source.sh
root="/output/preview-$preview_ffmpeg_key/host"
mkdir -p "$root/ffmpeg-build"
cd "$root/ffmpeg-build"
if [ ! -f "$root/ffmpeg/lib/libavcodec.a" ] || [ ! -f "$root/ffmpeg/freebird-preview-patch.sha256" ]; then
  "$preview_ffmpeg_source/configure" --prefix="$root/ffmpeg" \
    --disable-everything --disable-autodetect --disable-programs --disable-doc --disable-debug \
    --disable-shared --enable-static --enable-pic --enable-pthreads --disable-x86asm \
    --disable-avdevice --disable-avfilter --disable-swresample \
    --enable-avcodec --enable-avformat --enable-avutil --enable-swscale \
    --enable-decoder=h264,hevc --enable-parser=h264,hevc --enable-encoder=mjpeg \
    --enable-demuxer=matroska,mov --enable-protocol=http,tcp \
    --extra-cflags='-fvisibility=hidden -ffunction-sections -fdata-sections' > configure.log
  make -j4 > build.log 2>&1
  make install > install.log
  sha256sum "$preview_ffmpeg_patch" | cut -d' ' -f1 > "$root/ffmpeg/freebird-preview-patch.sha256"
fi
destination=${1:-/output/host-preview-012}
session_mode=${PREVIEW_SESSION_PROTOTYPE:-OFF}
case "$session_mode" in ON|OFF) ;; *) exit 2 ;; esac
cmake -S /work/companion/vfs.freebird.preview -B "$destination" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DFFMPEG_PREFIX="$root/ffmpeg" -DKODI_HEADERS="$KODI_HEADERS" \
  -DPREVIEW_SESSION_PROTOTYPE="$session_mode"
cmake --build "$destination" -j4
