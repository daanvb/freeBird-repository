#include "session.h"
#include <algorithm>
#include <atomic>
#include <charconv>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <limits>
#include <mutex>
#include <optional>
#include <set>
#include <stdexcept>
#include <thread>
#include <vector>
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/opt.h>
#include <libswscale/swscale.h>
}

namespace preview_session {
namespace {
// Compatibility mode switches may recreate Service. A stale lease must never
// collide with a new context even when its caller reuses a source token.
std::atomic<int64_t> next_generation{0};
using Clock = std::chrono::steady_clock;
constexpr int64_t kPixels = 4096LL * 2160;
constexpr int64_t kBytes = 8 * 1024 * 1024;
constexpr int kRead = 32 * 1024;
constexpr auto kLease = std::chrono::seconds(30);
constexpr int kPrepareSeconds = 10;
void Require(bool ok) { if (!ok) throw std::runtime_error("decode"); }
int64_t Micros(Clock::time_point start) {
  return std::chrono::duration_cast<std::chrono::microseconds>(Clock::now()-start).count();
}
bool Hex(const std::string& s) {
  return s.size() == 32 && s.find_first_not_of("0123456789abcdef") == std::string::npos;
}
bool Number(const std::string& s, int64_t limit, int64_t& n) {
  if (s.empty() || s.size() > 12 || s.find_first_not_of("0123456789") != std::string::npos) return false;
  auto r = std::from_chars(s.data(), s.data()+s.size(), n);
  return r.ec == std::errc() && r.ptr == s.data()+s.size() && n <= limit;
}
std::vector<std::string> Split(const std::string& s) {
  std::vector<std::string> parts;
  size_t start = 0;
  for (;;) {
    auto end = s.find('/', start);
    parts.push_back(s.substr(start, end == std::string::npos ? end : end-start));
    if (end == std::string::npos) return parts;
    start = end+1;
  }
}
struct Job {
  std::string id, token, container, url;
  int64_t time = 0, size = 0;
  bool prepare = false;
  bool SameSource(const Job& b) const {
    return token == b.token && url == b.url && container == b.container && size == b.size;
  }
};
struct Metrics {
  bool warm = false;
  bool decoder_warm = false;
  int64_t open_us = 0, seek_us = 0, packet_us = 0, decode_us = 0, image_us = 0;
  int64_t io_us = 0, io_bytes = 0, io_reads = 0, index_entries = 0, generation = 0;
  int64_t actual_ms = -1;
  int candidates = 0;
  const char* phase = "open";
  const char* failure = "none";
  std::string Json(int64_t elapsed) const {
    return "{\"warm\":" + std::string(warm ? "true" : "false") +
      ",\"decoder_warm\":" + std::string(decoder_warm ? "true" : "false") +
      ",\"generation\":"+std::to_string(generation)+",\"elapsed_us\":"+std::to_string(elapsed)+
      ",\"open_us\":"+std::to_string(open_us)+",\"seek_us\":"+std::to_string(seek_us)+
      ",\"packet_us\":"+std::to_string(packet_us)+",\"decode_us\":"+std::to_string(decode_us)+
      ",\"image_us\":"+std::to_string(image_us)+",\"io_us\":"+std::to_string(io_us)+
      ",\"io_bytes\":"+std::to_string(io_bytes)+",\"io_reads\":"+std::to_string(io_reads)+
      ",\"index_entries\":"+std::to_string(index_entries)+",\"actual_ms\":"+std::to_string(actual_ms)+
      ",\"candidates\":"+std::to_string(candidates)+",\"phase\":\""+phase+
      "\",\"failure\":\""+failure+"\"}\n";
  }
};
struct Timer {
  int64_t& sum;
  Clock::time_point start = Clock::now();
  ~Timer() { sum += Micros(start); }
};
struct Stop {
  std::atomic<bool>& cancelled;
  Clock::time_point deadline = Clock::now();
  bool Stopped() const { return cancelled || Clock::now() >= deadline; }
  void Check() const { if (Stopped()) throw std::runtime_error("stopped"); }
  static int Interrupt(void* value) { return static_cast<Stop*>(value)->Stopped(); }
};
struct Remote {
  AVIOContext* stream = nullptr;
  AVDictionary* options = nullptr;
  ~Remote() { avio_closep(&stream); av_dict_free(&options); }
};

// The demuxer sees a seekable file, not a streaming HTTP response. A seek only
// changes position; each actual read obtains exactly its bounded byte range.
// Real URLs/authentication remain in the Python adapter; only loopback is used.
struct RangeIO {
  Stop& stop;
  const Job& source;
  AVIOContext* context = nullptr;
  int64_t position = 0;
  Metrics* metrics = nullptr;  // assigned only for the synchronous worker job
  RangeIO(Stop& s, const Job& j) : stop(s), source(j) {
    auto* buffer = static_cast<uint8_t*>(av_malloc(kRead));
    Require(buffer);
    context = avio_alloc_context(buffer, kRead, 0, this, Read, nullptr, Seek);
    if (!context) { av_free(buffer); Require(false); }
    context->seekable = AVIO_SEEKABLE_NORMAL;
  }
  ~RangeIO() {
    if (context) { av_freep(&context->buffer); avio_context_free(&context); }
  }
  static int64_t Seek(void* value, int64_t offset, int whence) {
    auto& io = *static_cast<RangeIO*>(value);
    if (io.stop.Stopped()) return AVERROR_EXIT;
    if (whence == AVSEEK_SIZE) return io.source.size;
    whence &= ~AVSEEK_FORCE;
    int64_t base = whence == SEEK_SET ? 0 : whence == SEEK_CUR ? io.position :
                   whence == SEEK_END ? io.source.size : -1;
    if (base < 0 || offset < -base || offset > io.source.size-base) return AVERROR(EINVAL);
    return io.position = base+offset;
  }
  static int Read(void* value, uint8_t* buffer, int count) {
    auto& io = *static_cast<RangeIO*>(value);
    if (!io.metrics) return AVERROR_EXIT;
    auto& m = *io.metrics;
    Timer timer{m.io_us};
    try {
      io.stop.Check();
      if (io.position == io.source.size) return AVERROR_EOF;
      // AVIO can ask for a whole packet directly. Preserve that request rather
      // than splitting it into dozens of tiny range round trips.
      int wanted = static_cast<int>(std::min<int64_t>({count, 256*1024, io.source.size-io.position}));
      Require(wanted > 0);
      if (m.io_bytes+wanted > kBytes || m.io_reads >= 512) {
        m.failure = "read_limit";
        return AVERROR(EIO);
      }
      Remote remote;
      av_dict_set(&remote.options, "protocol_whitelist", "http,tcp", 0);
      av_dict_set(&remote.options, "rw_timeout", "5000000", 0);
      av_dict_set_int(&remote.options, "offset", io.position, 0);
      av_dict_set_int(&remote.options, "end_offset", io.position+wanted, 0);
      AVIOInterruptCB interrupt{Stop::Interrupt, &io.stop};
      ++m.io_reads;
      Require(avio_open2(&remote.stream, io.source.url.c_str(), AVIO_FLAG_READ,
                        &interrupt, &remote.options) >= 0);
      int read = avio_read(remote.stream, buffer, wanted);
      if (read > 0) m.io_bytes += read;
      Require(read == wanted);
      io.position += read;
      io.stop.Check();
      return read;
    } catch (...) {
      if (io.stop.Stopped()) return AVERROR_EXIT;
      m.failure = "range";
      return AVERROR(EIO);
    }
  }
};
struct Resources {
  AVFormatContext* input = nullptr;
  AVCodecContext *decoder = nullptr, *encoder = nullptr;
  AVPacket* packet = av_packet_alloc();
  AVFrame *frame = av_frame_alloc(), *scaled = av_frame_alloc();
  SwsContext* scaler = nullptr;
  AVDictionary* options = nullptr;
  void ResetPicture() {
    av_packet_unref(packet); av_frame_unref(frame); av_frame_unref(scaled);
    avcodec_free_context(&encoder); sws_freeContext(scaler); scaler = nullptr;
  }
  ~Resources() {
    av_dict_free(&options); sws_freeContext(scaler);
    av_frame_free(&scaled); av_frame_free(&frame); av_packet_free(&packet);
    avcodec_free_context(&encoder); avcodec_free_context(&decoder);
    avformat_close_input(&input); // custom AVIO belongs to RangeIO
  }
};
struct Session {
  Job source;
  Stop stop;
  RangeIO io;
  Resources r;
  int video = -1;
  int64_t generation;
  Session(const Job& j, std::atomic<bool>& cancel, int64_t g)
      : source(j), stop{cancel}, io(stop, source), generation(g) {}

  void Open(Metrics& m) {
    Timer timer{m.open_us}; m.phase = "open";
    Require(r.packet && r.frame && r.scaled);
    r.input = avformat_alloc_context(); Require(r.input);
    r.input->interrupt_callback = {Stop::Interrupt, &stop};
    r.input->pb = io.context;
    r.input->flags |= AVFMT_FLAG_CUSTOM_IO;
    if (source.container == "matroska") {
      r.input->flags |= AVFMT_FLAG_FAST_SEEK;
      av_dict_set(&r.options, "preview_skip_attachments", "1", 0);
    }
    r.input->probesize = 1024*1024;
    r.input->max_analyze_duration = AV_TIME_BASE;
    av_dict_set(&r.options, "protocol_whitelist", "http,tcp", 0);
    av_dict_set(&r.options, "max_streams", "8", 0);
    av_dict_set(&r.options, "enable_drefs", "0", 0);
    av_dict_set(&r.options, "use_absolute_path", "0", 0);
    auto* format = av_find_input_format(source.container.c_str()); Require(format);
    Require(avformat_open_input(&r.input, nullptr, format, &r.options) >= 0);
    av_dict_free(&r.options);
    for (unsigned i = 0; i < r.input->nb_streams; ++i) {
      auto* stream = r.input->streams[i];
      if (video < 0 && stream->codecpar->codec_type == AVMEDIA_TYPE_VIDEO &&
          !(stream->disposition & AV_DISPOSITION_ATTACHED_PIC)) video = i;
      else stream->discard = AVDISCARD_ALL;
    }
    Require(video >= 0);
    auto* p = r.input->streams[video]->codecpar;
    Require(p->codec_id == AV_CODEC_ID_H264 || p->codec_id == AV_CODEC_ID_HEVC);
    Require(p->width > 0 && p->height > 0 && int64_t(p->width)*p->height <= kPixels);
  }

  void OpenDecoder() {
    auto* p = r.input->streams[video]->codecpar;
    r.decoder = avcodec_alloc_context3(avcodec_find_decoder(p->codec_id)); Require(r.decoder);
    Require(avcodec_parameters_to_context(r.decoder, p) >= 0);
    r.decoder->thread_count = 1; r.decoder->thread_type = 0;
    r.decoder->max_pixels = kPixels; r.decoder->skip_frame = AVDISCARD_NONKEY;
    Require(avcodec_open2(r.decoder, nullptr, nullptr) >= 0);
  }

  void ReleaseDecoder() {
    r.ResetPicture();
    avcodec_free_context(&r.decoder);
  }

  std::string Extract(int64_t milliseconds, Metrics& m, bool prepare) {
    stop.deadline = Clock::now()+std::chrono::seconds(prepare ? kPrepareSeconds : 5);
    m.generation = generation; m.warm = video >= 0;
    m.decoder_warm = r.decoder != nullptr;
    io.metrics = &m;
    struct Clear { RangeIO& io; ~Clear() { io.metrics = nullptr; } } clear{io};
    if (video < 0) Open(m);
    auto* stream = r.input->streams[video];
    int64_t origin = stream->start_time == AV_NOPTS_VALUE ? 0 : stream->start_time;
    if (prepare) {
      // Matroska reads cues lazily at its first seek. Load only the index; no
      // packet decode, JPEG, or speculative target is produced during playback.
      Timer timer{m.seek_us}; m.phase = "index"; stop.Check();
      Require(av_seek_frame(r.input, video, origin, AVSEEK_FLAG_BACKWARD) >= 0);
      m.index_entries = avformat_index_get_entries_count(stream);
      Require(m.index_entries > 0); stop.Check();
      return "prepared\n";
    }
    if (!r.decoder) { Timer timer{m.decode_us}; OpenDecoder(); }
    int64_t seek = origin+av_rescale_q(milliseconds, AVRational{1,1000}, stream->time_base);
    int64_t stamp = -1, bytes = 0;
    int packets = 0;
    for (int attempt = 0; attempt < 3; ++attempt) {
      r.ResetPicture();
      int64_t indexed_time;
      {
        Timer timer{m.seek_us}; m.phase = "seek"; stop.Check();
        Require(av_seek_frame(r.input, video, seek, AVSEEK_FLAG_BACKWARD) >= 0);
        m.index_entries = avformat_index_get_entries_count(stream);
        auto* entry = avformat_index_get_entry_from_timestamp(stream, seek, AVSEEK_FLAG_BACKWARD);
        // Reject a missing index instead of hiding a sequential scan.
        Require(m.index_entries > 0 && entry);
        indexed_time = entry->timestamp;
        avcodec_flush_buffers(r.decoder);
      }
      bool picture = false;
      for (; packets < 160 && !picture; ++packets) {
        stop.Check();
        int read;
        { Timer timer{m.packet_us}; m.phase = "packet"; read = av_read_frame(r.input, r.packet); }
        if (read < 0 && read != AVERROR_EOF) break;
        if (read >= 0) {
          bytes += r.packet->size; Require(bytes <= kBytes);
          if (r.packet->stream_index != video) { av_packet_unref(r.packet); continue; }
        }
        Timer timer{m.decode_us}; m.phase = "decode";
        bool key = read >= 0 && (r.packet->flags & AV_PKT_FLAG_KEY);
        Require(avcodec_send_packet(r.decoder, read == AVERROR_EOF ? nullptr : r.packet) >= 0);
        av_packet_unref(r.packet);
        int got = avcodec_receive_frame(r.decoder, r.frame);
        if (got == AVERROR(EAGAIN) && key) {
          stop.Check(); Require(avcodec_send_packet(r.decoder, nullptr) >= 0);
          got = avcodec_receive_frame(r.decoder, r.frame); Require(got >= 0);
        }
        picture = got >= 0;
        if (!picture) Require(got == AVERROR(EAGAIN) || got == AVERROR_EOF);
        if (read == AVERROR_EOF) break;
      }
      Require(picture && r.frame->width > 0 && r.frame->height > 0 &&
              int64_t(r.frame->width)*r.frame->height <= kPixels);
      stamp = r.frame->best_effort_timestamp; Require(stamp != AV_NOPTS_VALUE);
      stamp = av_rescale_q(stamp-origin, stream->time_base, AVRational{1,1000});
      m.actual_ms = stamp; ++m.candidates;
      if (stamp <= milliseconds) break;
      // MOV sync indexes use decoding timestamps. With reordered HEVC the
      // selected keyframe can be presented after the requested time. Try the
      // preceding indexed key, retaining the same total job/byte limits.
      auto* first = avformat_index_get_entry(stream, 0);
      // Edited MOV timelines can retain negative-time preroll entries that are
      // explicitly discarded. They are not the start of the visible timeline.
      for (int i = 1; first && (first->flags & AVINDEX_DISCARD_FRAME) && i < 4096; ++i)
        first = avformat_index_get_entry(stream, i);
      Require(first && !(first->flags & AVINDEX_DISCARD_FRAME));
      // mov_seek_stream translates presentation time to its decoding index.
      // Account for the initial decoding lead before stepping behind this key;
      // otherwise that translation is applied twice and skips an extra GOP.
      int64_t lead = source.container == "mov" && first ? origin-first->timestamp : 0;
      Require(lead >= 0 && lead <= av_rescale_q(10, AVRational{1,1}, stream->time_base));
      Require(indexed_time > std::numeric_limits<int64_t>::min() &&
              indexed_time <= std::numeric_limits<int64_t>::max()-lead);
      int64_t previous = indexed_time-1+lead;
      Require(previous < seek);
      seek = previous;
    }
    Require(stamp >= 0 && stamp <= milliseconds); // never mislabel a future frame
    Timer timer{m.image_us}; m.phase = "image"; stop.Check();
    AVRational sar = av_guess_sample_aspect_ratio(r.input, stream, r.frame);
    double aspect = double(r.frame->width)/r.frame->height;
    if (sar.num > 0 && sar.den > 0) aspect *= av_q2d(sar);
    Require(std::isfinite(aspect) && aspect > 0);
    int width = std::min(384, r.frame->width);
    int height = int(std::min({216.0, double(r.frame->height), width/aspect}));
    width = int(std::min(double(width), height*aspect)); width &= ~1; height &= ~1;
    Require(width >= 2 && height >= 2);
    r.encoder = avcodec_alloc_context3(avcodec_find_encoder(AV_CODEC_ID_MJPEG)); Require(r.encoder);
    r.encoder->width = width; r.encoder->height = height;
    r.encoder->pix_fmt = AV_PIX_FMT_YUVJ420P; r.encoder->color_range = AVCOL_RANGE_JPEG;
    r.encoder->time_base = {1,25}; r.encoder->thread_count = 1;
    r.encoder->flags |= AV_CODEC_FLAG_QSCALE; r.encoder->global_quality = 5*FF_QP2LAMBDA;
    Require(avcodec_open2(r.encoder, nullptr, nullptr) >= 0);
    r.scaled->format = r.encoder->pix_fmt; r.scaled->width = width; r.scaled->height = height;
    r.scaled->quality = r.encoder->global_quality; r.scaled->color_range = AVCOL_RANGE_JPEG;
    Require(av_frame_get_buffer(r.scaled, 32) >= 0);
    r.scaler = sws_getContext(r.frame->width, r.frame->height,
        static_cast<AVPixelFormat>(r.frame->format), width, height, r.encoder->pix_fmt,
        SWS_FAST_BILINEAR, nullptr, nullptr, nullptr); Require(r.scaler);
    Require(sws_scale(r.scaler, r.frame->data, r.frame->linesize, 0, r.frame->height,
                     r.scaled->data, r.scaled->linesize) == height);
    stop.Check(); Require(avcodec_send_frame(r.encoder, r.scaled) >= 0);
    Require(avcodec_receive_packet(r.encoder, r.packet) >= 0);
    Require(r.packet->size >= 100 && r.packet->size <= 512*1024); stop.Check();
    std::string result = "FBP1\n"+std::to_string(stamp)+"\n"+
      std::string(reinterpret_cast<char*>(r.packet->data), r.packet->size);
    // Large decoder surfaces compete with foreground playback on small devices.
    // Keep their index, but retain no >1080p frame/codec allocations between jobs.
    auto* parameters = r.input->streams[video]->codecpar;
    if (int64_t(parameters->width)*parameters->height > 1920*1080) ReleaseDecoder();
    return result;
  }
};
}

struct Service::State {
  std::mutex mutex;
  std::condition_variable changed;
  std::atomic<bool> cancelled{false};
  bool stopping = false;
  std::optional<Job> pending;
  std::set<std::string> retired;
  std::string latest_id, latest_token, active_id, active_token, cached_token, result, stats;
  int64_t cached_generation = 0;
  Clock::time_point index_expiry = Clock::now(), picture_expiry = Clock::time_point::max();
  std::thread worker;
  State() : worker([this] { Run(); }) {}
  ~State() {
    { std::lock_guard<std::mutex> lock(mutex); stopping = true; cancelled = true; }
    changed.notify_one(); worker.join();
  }
  void Run() {
    std::unique_ptr<Session> session;
    std::unique_lock<std::mutex> lock(mutex);
    for (;;) {
      auto ready = [this] { return stopping || pending || !retired.empty(); };
      // Renewals wake this wait to recalculate the index deadline. They never
      // extend the independent decoder deadline or schedule background I/O.
      if (session && !ready()) changed.wait_until(lock, std::min(index_expiry, picture_expiry));
      else changed.wait(lock, ready);
      if (stopping) break;
      if (session && (retired.count(cached_token) || Clock::now() >= index_expiry)) {
        cached_token.clear(); cached_generation = 0;
        lock.unlock(); session.reset(); lock.lock();
      } else if (session && Clock::now() >= picture_expiry) {
        picture_expiry = Clock::time_point::max();
        lock.unlock(); session->ReleaseDecoder(); lock.lock();
        continue; // process any retirement/replacement received while freeing
      }
      retired.clear();
      if (!pending) continue;
      Job job = std::move(*pending); pending.reset();
      active_id = job.id; active_token = job.token; cancelled = false;
      bool reuse = session && session->source.SameSource(job);
      if (!reuse) { cached_token.clear(); cached_generation = 0; }
      lock.unlock();
      Metrics m;
      auto started = Clock::now();
      std::string response;
      bool failed = false;
      try {
        if (!reuse) { session.reset(); session = std::make_unique<Session>(job, cancelled, ++next_generation); }
        response = session->Extract(job.time, m, job.prepare);
      } catch (...) {
        failed = true; response = "failed\n";
        if (m.failure == std::string("none")) m.failure = "decode";
      }
      lock.lock();
      if (cancelled) { response = "cancelled\n"; m.failure = "cancelled"; failed = true; }
      else if (Clock::now()-started >= std::chrono::seconds(job.prepare ? kPrepareSeconds : 5)) {
        response = "timeout\n"; m.failure = "timeout"; failed = true;
      }
      if (failed || stopping || retired.count(job.token)) {
        cached_token.clear(); cached_generation = 0;
        lock.unlock(); session.reset(); lock.lock();
      } else {
        cached_token = job.token; cached_generation = session->generation;
        index_expiry = Clock::now()+kLease;
        if (!job.prepare) picture_expiry = session->r.decoder ? Clock::now()+kLease : Clock::time_point::max();
        else if (!session->r.decoder) picture_expiry = Clock::time_point::max();
      }
      if (latest_id == job.id) { result = std::move(response); stats = m.Json(Micros(started)); }
      active_id.clear(); active_token.clear();
    }
    lock.unlock(); session.reset();
  }
};
Service::Service() : state_(std::make_unique<State>()) {}
Service::~Service() = default;
bool Service::Busy() {
  std::lock_guard<std::mutex> lock(state_->mutex);
  return !state_->active_id.empty() || state_->pending.has_value();
}
std::string Service::Capabilities() {
  return "{\"protocol\":2,\"persistent\":true,\"indexed_io\":true,\"prepare\":true,\"index_lease\":true,\"experimental\":true}\n";
}
std::string Service::Request(const std::string& url) {
  const std::string prefix = FREEBIRD_PREVIEW_PROTOCOL "://";
  if (url.size() > 256 || url.compare(0, prefix.size(), prefix) != 0) return "invalid\n";
  auto p = Split(url.substr(prefix.size()));
  if (p == std::vector<std::string>{"capabilities", ""})
    return Capabilities();
  if (p.size() < 2 || !Hex(p[1])) return "invalid\n";
  auto& s = *state_;
  std::lock_guard<std::mutex> lock(s.mutex);
  if (p[0] == "lease" && p.size() == 3) {
    int64_t generation = 0;
    if (!Number(p[2], 999999999999LL, generation) || !generation) return "invalid\n";
    if (s.stopping || !s.active_id.empty() || s.pending || s.retired.count(p[1]) ||
        p[1] != s.cached_token || generation != s.cached_generation ||
        Clock::now() >= s.index_expiry) return "missing\n";
    s.index_expiry = Clock::now()+kLease;
    s.changed.notify_one(); return "retained\n";
  }
  if ((p[0] == "start" || p[0] == "prepare") && p.size() == 7) {
    int64_t port = 0, time = 0, size = 0;
    if (!Number(p[2], 65535, port) || port < 1024 || !Hex(p[3]) ||
        (p[4] != "matroska" && p[4] != "mov") || !Number(p[5], 604800000, time) ||
        !Number(p[6], 999999999999LL, size) || size < 16) return "invalid\n";
    if (p[1] == s.latest_id || p[1] == s.active_id) return "invalid\n";
    if (p[0] == "prepare" && time != 0) return "invalid\n";
    // Preparation is lower priority and must never replace a foreground job.
    if (p[0] == "prepare" && (!s.latest_id.empty() || !s.active_id.empty() || s.pending)) return "busy\n";
    s.pending = Job{p[1], p[3], p[4], "http://127.0.0.1:"+std::to_string(port)+"/"+p[3], time, size, p[0] == "prepare"};
    s.latest_id = p[1]; s.latest_token = p[3]; s.result.clear(); s.stats.clear();
    if (!s.active_id.empty()) s.cancelled = true;
    s.changed.notify_one(); return "accepted\n";
  }
  if (p.size() != 2) return "invalid\n";
  if (p[0] == "close") {
    if (p[1] != s.cached_token && p[1] != s.active_token &&
        (!s.pending || p[1] != s.pending->token)) return "missing\n";
    if (s.pending && s.pending->token == p[1]) s.pending.reset();
    if (s.active_token == p[1]) s.cancelled = true;
    if (s.latest_token == p[1]) { s.latest_id.clear(); s.latest_token.clear(); s.result.clear(); s.stats.clear(); }
    // A queued job owns no native resources. Do not accumulate arbitrary
    // retired tokens while one slow request is being cancelled.
    if (p[1] == s.cached_token || p[1] == s.active_token) s.retired.insert(p[1]);
    s.changed.notify_one(); return "closing\n";
  }
  if (p[0] != "result" && p[0] != "stats" && p[0] != "cancel" && p[0] != "release") return "invalid\n";
  if (p[1] != s.latest_id) return "missing\n";
  if (p[0] == "cancel") {
    s.pending.reset();
    if (s.active_id == p[1]) s.cancelled = true;
    s.result = "cancelled\n"; return s.result;
  }
  if (p[0] == "release") {
    if (s.active_id == p[1] || s.pending) return "busy\n";
    s.latest_id.clear(); s.latest_token.clear(); s.result.clear(); s.stats.clear(); return "released\n";
  }
  if (s.active_id == p[1] || s.pending) return "pending\n";
  return p[0] == "stats" ? (s.stats.empty() ? "missing\n" : s.stats) : s.result;
}
}
