#pragma once
#ifdef PREVIEW_SESSION_PROTOTYPE
#include "session.h"
namespace preview { using Service = preview_session::Service; }
#else
#include <memory>
#include <string>
namespace preview {
// Backwards-compatible router: exactly one active legacy/session backend.
class Service {
 public:
  Service();
  ~Service();
  Service(const Service&) = delete;
  Service& operator=(const Service&) = delete;
  std::string Request(const std::string& url);
 private:
  struct State;
  std::unique_ptr<State> state_;
};
}
#endif
