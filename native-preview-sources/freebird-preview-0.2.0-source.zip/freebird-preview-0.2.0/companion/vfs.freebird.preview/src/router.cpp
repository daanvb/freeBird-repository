#include "preview.h"
#include "legacy.h"
#include "session.h"
#include <mutex>

namespace preview {
struct Service::State {
  std::mutex mutex;
  std::unique_ptr<LegacyService> legacy;
  std::unique_ptr<preview_session::Service> session;
};
Service::Service() : state_(std::make_unique<State>()) {}
Service::~Service() = default;

std::string Service::Request(const std::string& url) {
  const std::string prefix = FREEBIRD_PREVIEW_PROTOCOL "://";
  if (url.size() > 264 || url.compare(0, prefix.size(), prefix) != 0) return "invalid\n";
  std::string path = url.substr(prefix.size());
  bool session = path.compare(0, 8, "session/") == 0;
  if (session) path.erase(0, 8);
  if (path == "capabilities/") {
    if (session) return preview_session::Service::Capabilities();
    return "{\"protocol\":1,\"session_protocol\":2,\"codecs\":[\"h264\",\"hevc\"],\"max_width\":384,\"max_height\":216,\"experimental\":true}\n";
  }
  const bool start = path.compare(0, 6, "start/") == 0 ||
                     (session && path.compare(0, 8, "prepare/") == 0);
  auto& s = *state_;
  std::lock_guard<std::mutex> lock(s.mutex);
  if (session) {
    if (!s.session) {
      if (!start) return "missing\n";
      if (s.legacy && s.legacy->Busy()) return "busy\n";
      s.legacy.reset();
      s.session = std::make_unique<preview_session::Service>();
    }
    return s.session->Request(prefix+path);
  }
  if (!s.legacy) {
    if (!start) return "missing\n";
    if (s.session && s.session->Busy()) return "busy\n";
    s.session.reset();
    s.legacy = std::make_unique<LegacyService>();
  }
  return s.legacy->Request(url);
}
}
