#pragma once
#include <memory>
#include <string>

namespace preview_session {
// One worker, one retained decoder and at most one pending/latest request.
class Service {
 public:
  Service();
  ~Service();
  Service(const Service&) = delete;
  Service& operator=(const Service&) = delete;
  std::string Request(const std::string& url);
  static std::string Capabilities();
  bool Busy();
 private:
  struct State;
  std::unique_ptr<State> state_;
};
}
