#pragma once
#include <atomic>
#include <chrono>
#include <mutex>
#include <string>
#include <thread>

namespace preview {
// A single worker and retained result per addon, shared by VFS instances.
// Request handlers never wait for an active decode. Destruction joins safely.
class LegacyService {
 public:
  LegacyService() = default;
  ~LegacyService();
  LegacyService(const LegacyService&) = delete;
  LegacyService& operator=(const LegacyService&) = delete;
  bool Busy();
  std::string Request(const std::string& url);
 private:
  std::mutex mutex_;
  std::thread worker_;
  std::atomic<bool> cancelled_{false};
  bool running_ = false;
  std::string id_, result_;
};
}
