"""Stage matching native source archives alongside the binary feed packages.

The upstream tarballs are git archives of the exact pinned commits (see the
component README). Only the explicit helper/build allowlist is exported from
the private application checkout. No device data or repository history is read.
"""
import argparse
import hashlib
import importlib.util
from pathlib import Path
import shutil
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
COMPONENT = 'companion/vfs.freebird.preview/'
HELPER_FILES = [COMPONENT+name for name in (
    'CMakeLists.txt', 'Dockerfile', 'NOTICE.txt', 'README.md', 'addon.xml.in',
    'build_android.sh', 'build_host.sh', 'ffmpeg_source.sh',
    'patches/matroska-preview-fast-seek.patch',
    'src/addon.cpp', 'src/driver.cpp', 'src/preview.cpp', 'src/preview.h',
    'src/session.cpp', 'src/session.h', 'src/legacy.h', 'src/router.cpp')]
HELPER_FILES += ['LICENSE', 'tools/package-native-preview.py', 'tools/build-native-preview-sources.py']
UPSTREAM = ('ffmpeg-9.0.2-source.tar.xz', 'kodi-sdk-omega-source.tar.xz', 'kodi-sdk-piers-source.tar.xz')
# Pinned upstream tls_openssl.c line 372 documents PEM syntax with an ellipsis,
# not a key. Independently checked against the public commit. Permit this exact
# file/signature only; any source-byte change or other finding still fails.
UPSTREAM_DOCUMENTATION = {
    ('private_key_pem', 'ffmpeg-9.0.2-source.tar.xz/ffmpeg-9.0.2/libavformat/tls_openssl.c'):
        '0567d5c8204c80a61074065a5044abea1f972694d41b60cbcd03dd89d05b677f'
}


def build(upstream, output):
    spec = importlib.util.spec_from_file_location('native_source_audit', ROOT/'tools/audit-public-source.py')
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    output.mkdir(parents=True, exist_ok=True)
    hits = []
    for name in UPSTREAM:
        source = upstream/name
        with tarfile.open(source, 'r:xz') as archive:
            members = archive.getmembers()
            if not members:
                raise ValueError('Empty upstream archive')
            for member in members:
                if member.name.startswith('/') or '..' in Path(member.name).parts:
                    raise ValueError('Unsafe archive path')
                if member.isfile():
                    data = archive.extractfile(member).read()
                    for hit in audit.scan_bytes(name+'/'+member.name, data):
                        if UPSTREAM_DOCUMENTATION.get(tuple(hit)) != hashlib.sha256(data).hexdigest():
                            hits.append(hit)
        shutil.copyfile(source, output/name)
    helper = output/'freebird-preview-0.2.0-source.zip'
    with zipfile.ZipFile(helper, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in HELPER_FILES:
            data = (ROOT/name).read_bytes()
            hits.extend(audit.scan_bytes(name, data))
            info = zipfile.ZipInfo('freebird-preview-0.2.0/'+name, (2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data, compresslevel=9)
    if hits:
        raise ValueError('Source credential audit: '+repr(hits))
    # Retain matching sources for immutable previous native packages, too.
    helpers = sorted(path.name for path in output.glob('freebird-preview-*-source.zip'))
    names = [*helpers, *UPSTREAM]
    checksums = '\n'.join(hashlib.sha256((output/name).read_bytes()).hexdigest()+'  '+name for name in names)+'\n'
    (output/'SHA256SUMS').write_text(checksums, encoding='ascii')
    links = ''.join('<li><a href="{0}">{0}</a></li>'.format(name) for name in [*names, 'SHA256SUMS'])
    (output/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>freeBird preview sources</title>'
        '<h1>freeBird preview decoder 0.2.0 — matching sources</h1>'
        '<p>Helper and build instructions (GPL-2.0-or-later), FFmpeg 9.0.2 (minimal LGPL build), '
        'and Kodi SDK sources/licenses. Android NDK r30 is obtained from Google as specified in the Dockerfile. '
        'The helper archive includes the exact build configuration and pinned upstream commits.</p><ul>'+links+'</ul>', encoding='utf-8')
    print('Validated and staged {} matching native source archives and checksums.'.format(len(names)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--upstream', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    build(args.upstream, args.output)
