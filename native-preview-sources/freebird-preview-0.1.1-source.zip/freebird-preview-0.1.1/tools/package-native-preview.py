#!/usr/bin/env python3
"""Validate and zip an Android preview decoder; never publish or install.

Development dependency: pyelftools. See the companion's README for builds.
"""
import argparse
import hashlib
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

from elftools.elf.elffile import ELFFile

ADDON = 'vfs.freebird.preview'
FILES = ('addon.xml', 'libvfs.freebird.preview.so', 'LICENSE', 'FFMPEG-LICENSE', 'NOTICE.txt')
VERSIONS = {'omega': ('2.0.2', '2.0.0'), 'piers': ('2.0.4', '2.0.3')}
PLATFORMS = {'android-armv7': ('EM_ARM', 32), 'android-aarch64': ('EM_AARCH64', 64)}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def validate(folder, kodi):
    for name in FILES:
        require((folder/name).is_file() and not (folder/name).is_symlink(), 'Missing regular '+name)
    root = ET.parse(folder/'addon.xml').getroot()
    platform = root.findtext("extension[@point='xbmc.addon.metadata']/platform")
    require(platform in PLATFORMS, 'Not a supported Android target')
    identity = ADDON+'.'+kodi+'.'+platform.replace('android-', '')
    require(root.get('id') == identity and root.get('version') == '0.1.1', 'Wrong native addon')
    main = root.find("requires/import[@addon='kodi.binary.global.main']")
    require(main is not None and (main.get('version'), main.get('minversion')) == VERSIONS[kodi],
            'Kodi global ABI does not match selected target')
    vfs = root.find("requires/import[@addon='kodi.binary.instance.vfs']")
    require(vfs is not None and vfs.get('version') == vfs.get('minversion') == '3.0.1', 'Wrong VFS ABI')
    extension = root.find("extension[@point='kodi.vfs']")
    protocol = identity.replace(ADDON+'.', 'freebirdpreview').replace('.', '')
    require(extension is not None and extension.get('protocols') == protocol and
            extension.get('library_android') == FILES[1], 'Wrong VFS entry')
    require((protocol+'://').encode('ascii') in (folder/FILES[1]).read_bytes(),
            'Native library protocol does not match its manifest')
    with (folder/FILES[1]).open('rb') as handle:
        elf = ELFFile(handle)
        require((elf['e_machine'], elf.elfclass) == PLATFORMS[platform], 'ELF architecture mismatch')
        require(elf['e_type'] == 'ET_DYN' and elf.little_endian, 'Not a little-endian shared library')
        loads = [part for part in elf.iter_segments() if part['p_type'] == 'PT_LOAD']
        require(loads and all(part['p_align'] >= 16384 and
                (part['p_vaddr']-part['p_offset']) % 16384 == 0 for part in loads), 'Missing 16 KiB alignment')
        dynamic = elf.get_section_by_name('.dynamic')
        require(dynamic is not None, 'Missing dynamic section')
        tags = list(dynamic.iter_tags())
        needed = {tag.needed for tag in tags if tag.entry.d_tag == 'DT_NEEDED'}
        require(needed and needed <= {'libc.so', 'libdl.so', 'libm.so'}, 'Unexpected runtime dependencies')
        require(not any(tag.entry.d_tag == 'DT_TEXTREL' or
                (tag.entry.d_tag == 'DT_FLAGS' and tag.entry.d_val & 4) for tag in tags), 'Text relocations')
        symbols = elf.get_section_by_name('.dynsym')
        require(symbols is not None, 'Missing exported entry points')
        exported = {sym.name for sym in symbols.iter_symbols()
                    if sym['st_shndx'] != 'SHN_UNDEF' and sym['st_info']['bind'] in ('STB_GLOBAL', 'STB_WEAK')
                    and sym['st_other']['visibility'] in ('STV_DEFAULT', 'STV_PROTECTED')}
        require(exported == {'ADDON_Create', 'ADDON_GetTypeVersion', 'ADDON_GetTypeMinVersion'},
                'Unexpected exported symbols: '+repr(sorted(exported)))
    return platform


def package(folder, kodi, output):
    platform = validate(folder, kodi)
    output.mkdir(parents=True, exist_ok=True)
    identity = ADDON+'.'+kodi+'.'+platform.replace('android-', '')
    destination = output/(identity+'-0.1.1.zip')
    # Fixed ZIP timestamps and an explicit allowlist keep builds comparable and
    # exclude local build logs, source paths and unrelated files.
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in FILES:
            info = zipfile.ZipInfo(identity+'/'+name, (2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, (folder/name).read_bytes(), compresslevel=9)
    with zipfile.ZipFile(destination) as archive:
        require(archive.testzip() is None, 'ZIP CRC check failed')
    digest = hashlib.sha256(destination.read_bytes()).hexdigest()
    print('{}  {} ({} bytes)'.format(digest, destination, destination.stat().st_size))
    return destination


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', required=True, type=Path, help='Directory containing addon.xml')
    parser.add_argument('--kodi', required=True, choices=VERSIONS)
    parser.add_argument('--output', required=True, type=Path)
    arguments = parser.parse_args()
    package(arguments.package, arguments.kodi, arguments.output)
