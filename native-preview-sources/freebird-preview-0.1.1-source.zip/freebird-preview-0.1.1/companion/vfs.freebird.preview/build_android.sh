#!/usr/bin/env bash
set -euo pipefail
# Invoked inside the isolated android build image, with the source mounted read-only.
# /output is a task-owned writable build directory. Never installs to Kodi.
abi=${1:?armeabi-v7a or arm64-v8a}
kodi=${2:-omega}
case "$kodi" in
  omega) ;;
  piers)
    if [ ! -d /output/kodi-piers/.git ]; then
      git init /output/kodi-piers
      git -C /output/kodi-piers remote add origin https://github.com/xbmc/xbmc.git
      git -C /output/kodi-piers config core.sparseCheckout true
      printf 'xbmc/addons/kodi-dev-kit/\n' > /output/kodi-piers/.git/info/sparse-checkout
      git -C /output/kodi-piers fetch --depth 1 --filter=blob:none origin 60b9c6b0f7fe7bbb932f7140b4662627f94d7400
      git -C /output/kodi-piers checkout --detach FETCH_HEAD
    fi
    test "$(git -C /output/kodi-piers rev-parse HEAD)" = 60b9c6b0f7fe7bbb932f7140b4662627f94d7400
    KODI_HEADERS=/output/kodi-piers/xbmc/addons/kodi-dev-kit/include
    ;;
  *) exit 2 ;;
esac
case "$abi" in
  armeabi-v7a) arch=arm; triple=armv7a-linux-androideabi; cpu=armv7-a ;;
  arm64-v8a) arch=aarch64; triple=aarch64-linux-android; cpu=armv8-a ;;
  *) exit 2 ;;
esac
ndkbin="$ANDROID_NDK/toolchains/llvm/prebuilt/linux-x86_64/bin"
root="/output/$abi"
mkdir -p "$root"
# Pin the source commit for upstream release n9.0.2.
if [ ! -d /output/ffmpeg/.git ]; then
  git init /output/ffmpeg
  git -C /output/ffmpeg remote add origin https://github.com/FFmpeg/FFmpeg.git
  git -C /output/ffmpeg fetch --depth 1 origin 946fcce07b6dcd0331c8cc609192aeff5e1924f8
  git -C /output/ffmpeg checkout --detach FETCH_HEAD
fi
test "$(git -C /output/ffmpeg rev-parse HEAD)" = 946fcce07b6dcd0331c8cc609192aeff5e1924f8
mkdir -p "$root/ffmpeg-build"
cd "$root/ffmpeg-build"
if [ ! -f "$root/ffmpeg/lib/libavcodec.a" ]; then
  /output/ffmpeg/configure --prefix="$root/ffmpeg" \
    --target-os=android --arch="$arch" --cpu="$cpu" --enable-cross-compile \
    --cc="$ndkbin/${triple}21-clang" --cxx="$ndkbin/${triple}21-clang++" \
    --ar="$ndkbin/llvm-ar" --ranlib="$ndkbin/llvm-ranlib" --strip="$ndkbin/llvm-strip" \
    --disable-everything --disable-autodetect --disable-programs --disable-doc --disable-debug \
    --disable-shared --enable-static --enable-pic --enable-pthreads \
    --disable-avdevice --disable-avfilter --disable-swresample \
    --enable-avcodec --enable-avformat --enable-avutil --enable-swscale \
    --enable-decoder=h264,hevc --enable-parser=h264,hevc --enable-encoder=mjpeg \
    --enable-demuxer=matroska,mov --enable-protocol=http,tcp \
    --extra-cflags='-fvisibility=hidden -ffunction-sections -fdata-sections' \
    --extra-ldflags='-Wl,-z,max-page-size=16384' > configure.log
  make -j4 > build.log 2>&1
  make install > install.log
fi
cmake -S /work/companion/vfs.freebird.preview -B "$root/addon-$kodi" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI="$abi" -DANDROID_PLATFORM=android-21 -DANDROID_STL=c++_static \
  -DFFMPEG_PREFIX="$root/ffmpeg" -DKODI_HEADERS="$KODI_HEADERS"
cmake --build "$root/addon-$kodi" -j4
cmake --install "$root/addon-$kodi" --prefix "$root/package-$kodi"
cp /work/LICENSE "$root/package-$kodi/vfs.freebird.preview/LICENSE"
cp /output/ffmpeg/COPYING.LGPLv2.1 "$root/package-$kodi/vfs.freebird.preview/FFMPEG-LICENSE"
cp /work/companion/vfs.freebird.preview/NOTICE.txt "$root/package-$kodi/vfs.freebird.preview/NOTICE.txt"
"$ndkbin/llvm-strip" --strip-unneeded "$root/package-$kodi/vfs.freebird.preview/libvfs.freebird.preview.so"
"$ndkbin/llvm-readelf" --dyn-syms "$root/package-$kodi/vfs.freebird.preview/libvfs.freebird.preview.so" > "$root/exports-$kodi.txt"
"$ndkbin/llvm-readelf" -l -d "$root/package-$kodi/vfs.freebird.preview/libvfs.freebird.preview.so" > "$root/elf-$kodi.txt"
