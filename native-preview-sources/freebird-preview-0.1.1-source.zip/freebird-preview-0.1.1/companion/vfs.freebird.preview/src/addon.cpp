#include "preview.h"
#include <kodi/addon-instance/VFS.h>
#include <algorithm>
#include <cstring>
#include <memory>

namespace {
struct File { std::string bytes; size_t offset = 0; };
class VFS : public kodi::addon::CInstanceVFS {
 public:
  VFS(const kodi::addon::IInstanceInfo& instance, std::shared_ptr<preview::Service> service)
      : CInstanceVFS(instance), service_(std::move(service)) {}
  kodi::addon::VFSFileHandle Open(const kodi::addon::VFSUrl& url) override {
    try { return new File{service_->Request(url.GetURL())}; }
    catch (...) { return nullptr; }
  }
  bool Close(kodi::addon::VFSFileHandle context) override {
    delete static_cast<File*>(context); return true;
  }
  ssize_t Read(kodi::addon::VFSFileHandle context, uint8_t* output, size_t count) override {
    auto* file = static_cast<File*>(context);
    if (!file || (!output && count)) return -1;
    count = std::min(count, file->bytes.size()-file->offset);
    if (count) std::memcpy(output, file->bytes.data()+file->offset, count);
    file->offset += count;
    return count;
  }
  int64_t GetLength(kodi::addon::VFSFileHandle context) override {
    return context ? static_cast<File*>(context)->bytes.size() : 0;
  }
  int64_t GetPosition(kodi::addon::VFSFileHandle context) override {
    return context ? static_cast<File*>(context)->offset : 0;
  }
 private:
  std::shared_ptr<preview::Service> service_;
};
class Addon : public kodi::addon::CAddonBase {
 public:
  ADDON_STATUS CreateInstance(const kodi::addon::IInstanceInfo& instance,
                              KODI_ADDON_INSTANCE_HDL& handle) override {
    if (!instance.IsType(ADDON_INSTANCE_VFS)) return ADDON_STATUS_NOT_IMPLEMENTED;
    handle = new VFS(instance, service_);
    return ADDON_STATUS_OK;
  }
 private:
  std::shared_ptr<preview::Service> service_ = std::make_shared<preview::Service>();
};
}
ADDONCREATOR(Addon)
