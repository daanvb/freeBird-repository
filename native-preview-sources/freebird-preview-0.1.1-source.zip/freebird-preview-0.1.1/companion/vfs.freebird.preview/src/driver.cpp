// Test-only host implementing Kodi's C ABI, loading the actual addon .so.
// This verifies its exported entry points and VFS callbacks, not a Kodi GUI.
#include <kodi/c-api/addon_base.h>
#include <kodi/c-api/addon-instance/vfs.h>
#include <kodi/versions.h>
#include <dlfcn.h>
#include <filesystem>
#include <iostream>
#include <stdexcept>
void require(bool value) { if (!value) throw std::runtime_error("VFS ABI check failed"); }
int main(int argc, char** argv) {
  auto path = argc > 1 ? std::filesystem::path(argv[1]) :
      std::filesystem::path(argv[0]).parent_path()/"vfs.freebird.preview.so";
  void* library = dlopen(path.c_str(), RTLD_NOW | RTLD_LOCAL);
  if (!library) { std::cerr << dlerror() << '\n'; return 1; }
  auto create = reinterpret_cast<ADDON_STATUS(*)(KODI_HANDLE)>(dlsym(library, "ADDON_Create"));
  auto version = reinterpret_cast<const char*(*)(int)>(dlsym(library, "ADDON_GetTypeVersion"));
  auto minimum = reinterpret_cast<const char*(*)(int)>(dlsym(library, "ADDON_GetTypeMinVersion"));
  require(create && version && minimum);
  require(std::string(version(ADDON_GLOBAL_MAIN)) == ADDON_GLOBAL_VERSION_MAIN);
  require(std::string(minimum(ADDON_GLOBAL_MAIN)) == ADDON_GLOBAL_VERSION_MAIN_MIN);
  require(std::string(version(ADDON_INSTANCE_VFS)) == ADDON_INSTANCE_VERSION_VFS);
  require(std::string(minimum(ADDON_INSTANCE_VFS)) == ADDON_INSTANCE_VERSION_VFS_MIN);
  AddonGlobalInterface global{};
  KodiToAddonFuncTable_Addon functions{};
  AddonToKodiFuncTable_Addon callbacks{};
  callbacks.addon_log_msg = [](KODI_ADDON_BACKEND_HDL, int, const char*) {};
  global.toAddon = &functions; global.toKodi = &callbacks;
  require(create(&global) == ADDON_STATUS_OK);
  KODI_ADDON_INSTANCE_INFO info{};
  info.type = ADDON_INSTANCE_VFS; info.version = "3.0.1"; info.id = "test";
  KODI_ADDON_INSTANCE_STRUCT instance{};
  KODI_ADDON_INSTANCE_FUNC instanceFunctions{};
  AddonInstance_VFSEntry vfs{};
  KodiToAddonFuncTable_VFSEntry vfsFunctions{};
  instance.info = &info; instance.functions = &instanceFunctions; instance.vfs = &vfs;
  vfs.toAddon = &vfsFunctions;
  global.firstKodiInstance = &instance;
  require(functions.create_instance(global.addonBase, &instance) == ADDON_STATUS_OK);
  std::string line;
  while (std::getline(std::cin, line)) {
    VFSURL url{};
    url.url = line.c_str();
    auto file = vfsFunctions.open(&vfs, &url);
    require(file);
    auto length = vfsFunctions.get_length(&vfs, file);
    require(length >= 0 && length <= 524352);
    std::string response;
    uint8_t buffer[4093]; // deliberately exercise reads across nonaligned boundaries
    while (true) {
      auto read = vfsFunctions.read(&vfs, file, buffer, sizeof(buffer));
      require(read >= 0);
      if (!read) break;
      response.append(reinterpret_cast<char*>(buffer), read);
    }
    require(response.size() == size_t(length));
    require(vfsFunctions.get_position(&vfs, file) == length);
    require(vfsFunctions.close(&vfs, file));
    std::cout << response.size() << '\n';
    std::cout.write(response.data(), response.size());
    std::cout.flush();
  }
  functions.destroy_instance(global.addonBase, &instance);
  functions.destroy(global.addonBase);
  dlclose(library);
}
