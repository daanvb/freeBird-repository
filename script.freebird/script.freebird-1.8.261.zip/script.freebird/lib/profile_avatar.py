"""Portable bundled avatars; roster data never contains local paths or URLs."""
AVATARS = ('default', 'ocean', 'orchid', 'sunset', 'forest', 'rose')
LABELS = ('Classic', 'Ocean', 'Orchid', 'Sunset', 'Forest', 'Rose')
BASE = 'special://home/addons/script.freebird/resources/skins/Main/media/'


def clean(value):
    return value if isinstance(value, str) and value in AVATARS else 'default'


def texture(value):
    value = clean(value)
    return BASE + ('avatars-v3/profile-avatar.png' if value == 'default'
                   else 'avatars-v3/' + value + '.png')
