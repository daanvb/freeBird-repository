# freeBird — Codex working guidance

**Development home:** private repo `daanvb/freeBird-private`, active/default branch `firebird`. This is the application source, **not** the public update feed. Start with `STATUS.md` and the relevant section of `docs/PROJECT_HANDOVER.md`; consult other files only when needed. The root README/changelog and `docs/` contain extensive history, not required context for every task.

## Efficient task workflow
- One scoped feature/fix per branch or Codex conversation. Search the affected package/functions and tests rather than loading the entire repository or historical release docs.
- Preserve existing behaviour, settings migration, playback state, safe cancellation, player/remote handoffs, format selection and device-specific compatibility unless the task requires changing them.
- Use targeted offline regression tests while developing. Use `python3 tools/run-tests.py` for the broader suite when release instructions require it. Report actual passing/failed tests and what remains untested on real devices.
- At a substantial task boundary, update `STATUS.md` only when verified state materially changes. Add durable architecture/release decisions to an appropriate focused doc, not repeatedly to this file. Provide a compact handover; suggest a fresh conversation when the current one accumulates unrelated tasks. Never merge/release merely to tidy up.

## Source, publication and private sync
- `daanvb/freeBird-private` (`firebird`) = code, tests and source documentation. GitHub Actions run validation and public-source safety checks on pushes/PRs.
- `daanvb/freeBird-repository` (`main`, **public**) = generated Kodi repository index, installation website and downloadable addon/skin ZIPs. Treat as a **release output**, not the ordinary development branch. Inspect `docs/repository-layout.md` and release scripts before publishing; don't push directly without an authorised, validated release.
- `daanvb/freeBird-sync` (`main`, **private**) = live device sync and diagnostic data, not source or a development workspace. **Never** edit, remove, publish, enumerate or copy its JSON/log contents as part of ordinary work. Avoid putting tokens, streams, account details, private URLs or device diagnostics into source, fixtures, prompts or public ZIPs.
- Keep the source repository private; run the public-source safety audit for release work. Credentials and private device setup data must never enter the public feed.

## Find the right code
- Entry points: `default.py`, `plugin.py`, `service.py` and player modules. Main logic lives in `core/`, `lib/`, `resources/`; companion services in `companion/`.
- Focused tests: `tests/`; test entry: `tools/run-tests.py`; release tooling: `tools/build-freebird-addon.py`, `tools/build-player-skin.py`, `tools/verify-release.py`, `tools/audit-public-source.py`.
- `docs/repository-layout.md` explains publication and retention; `docs/device-setup.md`, `docs/diagnostic-exports.md`, and specialised CoreELEC/playback docs explain individual features.
- `STATUS.md` tracks verified repository state, open questions and current release; `docs/PROJECT_HANDOVER.md` provides a fresh-session checklist.

## Branding compatibility
- Display name: `freeBird`; canonical IDs are `script.freebird`, `skin.freebird`, `repository.freebird`. New installations use normal freeBird setup; do not reintroduce legacy app/profile import, a migration wizard or compatibility updater. Never delete existing profiles automatically.
- Keep saved preference keys, shared playback properties and internal data-format compatibility stable. Installation migration removal does not remove normal viewer setup, sync or cache/schema upgrades.

## Boundaries
- Do not reboot Kodi/CoreELEC, change home networking or publish/update addons without explicit permission.
- Simulated Kodi tests cannot certify actual Dolby Vision, FEL, HDR, HDMI handshakes, audio passthrough, CEC remote inputs or player rendering; identify device validation separately.
- For a release, follow the existing builder and `tools/verify-release.py`, run required checks and get explicit authorisation to publish.
