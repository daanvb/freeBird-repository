"""Local provider preferences, independent of Kodi and private transport URLs."""
import re
from addons_core import active_addons, descriptor_id

ROLES = ('metadata', 'artwork', 'ratings', 'search', 'streams', 'subtitles', 'catalogues')
RESOURCES = {'metadata': 'meta', 'artwork': 'meta', 'ratings': 'meta',
             'search': 'catalog', 'streams': 'stream', 'subtitles': 'subtitles', 'catalogues': 'catalog'}


def enabled(state, provider, role):
    """The parent addon always overrides the retained capability preference."""
    disabled = state.get('disabledProviderRoles') or {}
    return (provider.get('id') not in state.get('disabledAddons', [])
            and eligible(provider, role) and key(provider) not in disabled.get(role, []))


def capability_rows(state):
    labels = {'metadata': 'Title and episode details', 'artwork': 'Posters and artwork',
              'ratings': 'Metadata ratings', 'search': 'Search', 'streams': 'Streams',
              'subtitles': 'Subtitles', 'catalogues': 'Catalogue collections'}
    return [dict(kind='provider_toggle', id='provider_toggle:' + role + ':' + key(provider),
                 label=name(provider) + ' · ' + labels[role],
                 disabled=provider.get('id') in state.get('disabledAddons', []),
                 enabled=enabled(state, provider, role),
                 help='Enable this addon for ' + labels[role].lower() + '. '
                      'Disabling it in Stremio addons turns off all its capabilities. '
                      'Your capability choices are retained when the addon is re-enabled.')
            for provider in state.get('addons', []) for role in ROLES if eligible(provider, role)]


def key(provider):
    return descriptor_id(str(provider.get('transportUrl') or ''))


def name(provider):
    """Display names only; never display a configured URL as a fallback."""
    value = str((provider.get('manifest') or {}).get('name') or 'Unnamed add-on')
    value = re.sub(r'https?://\S+', '[link hidden]', value)
    return ' '.join(value.split())[:80]


def eligible(provider, role):
    manifest = provider.get('manifest') or {}
    resources = {r if isinstance(r, str) else r.get('name')
                 for r in manifest.get('resources', []) if isinstance(r, (str, dict))}
    if RESOURCES.get(role) not in resources:
        return False
    if role in ('metadata', 'artwork', 'ratings'):
        # Event/channel metadata is not a supplier for movie or series details.
        # Resource-scoped types override the manifest-wide types.
        return any(isinstance(spec, dict)
                   and set(spec.get('types', manifest.get('types', [])) or []).intersection({'movie', 'series'})
                   for resource in manifest.get('resources', [])
                   for spec in [manifest if resource == 'meta' else
                                resource if isinstance(resource, dict) and resource.get('name') == 'meta' else None])
    if role == 'search':
        label = re.sub(r'\W', '', name(provider)).casefold()
        if any(value in label for value in ('morecontentlikethis', 'contentdeepdive')):
            return False
        return any(isinstance(c, dict) and c.get('type') in ('movie', 'series')
                   and c.get('id') and any(isinstance(e, dict) and e.get('name') == 'search'
                                          for e in c.get('extra', []))
                   and not (set(c.get('extraRequired') or []) |
                            {e.get('name') for e in c.get('extra', [])
                             if isinstance(e, dict) and e.get('isRequired')}) - {'search'}
                   for c in manifest.get('catalogs', []))
    return True


def preference(state, role):
    preferences = state.get('providerPreferences')
    return preferences.get(role, '') if isinstance(preferences, dict) else ''


def selected(state, role):
    return next((p for p in active_addons(state)
                 if enabled(state, p, role) and key(p) == preference(state, role)), None)


def is_aiometadata(provider):
    manifest = provider.get('manifest') or {}
    return any('aiometadata' in re.sub(r'\W', '', str(value)).casefold()
               for value in (manifest.get('name'), manifest.get('id')))


def ordered(state, role):
    """Metadata/search use ordered fallbacks; stream/subtitle choices restrict suppliers."""
    providers = [p for p in active_addons(state) if enabled(state, p, role)]
    primary = selected(state, role)
    if primary:
        providers = ([primary] if role in ('streams', 'subtitles') else
                     [primary] + [p for p in providers if key(p) != key(primary)])
    if role in ('metadata', 'artwork') or (role == 'search' and not primary):
        providers.sort(key=lambda p: not is_aiometadata(p))
    return providers


def artwork_providers(state):
    aio = [p for p in ordered(state, 'artwork') if is_aiometadata(p)]
    if aio:
        return aio
    primary = selected(state, 'artwork')
    if primary:
        return [primary]  # Keep original catalogue art when this supplier has no poster.
    return [p for p in ordered(state, 'artwork')
            if 'aiometadata' in re.sub(r'\W', '', name(p)).casefold()]


def choices(state, role):
    providers = [p for p in active_addons(state) if enabled(state, p, role)]
    automatic = 'All enabled add-ons' if role in ('streams', 'subtitles') else 'Automatic'
    labels, values = [automatic], ['']
    counts = {}
    for p in providers:
        label = name(p)
        counts[label] = counts.get(label, 0) + 1
        labels.append(label + (' ({})'.format(counts[label]) if counts[label] > 1 else ''))
        values.append(key(p))
    value = preference(state, role)
    return labels, values, values.index(value) if value in values else 0


def save_preference(state, role, value):
    if role not in ROLES or value not in choices(state, role)[1]:
        raise ValueError('Choose an enabled provider for this role.')
    state['providerPreferences'] = dict(state.get('providerPreferences') or {}, **{role: value})


def overlaps(state):
    """Describe real overlaps, without treating complementary add-ons as conflicts."""
    rows = []
    for role in ROLES:
        providers = [p for p in active_addons(state) if enabled(state, p, role)]
        if len(providers) > 1:
            primary = selected(state, role)
            rows.append((role, ', '.join(name(p) for p in providers),
                         name(primary) if primary else 'Automatic'))
    return rows
