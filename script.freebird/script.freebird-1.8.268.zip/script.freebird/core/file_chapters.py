"""Bounded container metadata reads; never decode, play, or scan media payloads."""
import base64
import math
import re
import time
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import parse_qsl, unquote, urljoin, urlsplit, urlunsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener, url2pathname

MAX_BYTES = 2 * 1024 * 1024
MAX_ELEMENT = 512 * 1024
MAX_REQUESTS = 12
BLOCK = 64 * 1024


class Unavailable(ValueError):
    pass


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):return None


class Reader:
    def __init__(self, source, alive=lambda:True, clock=time.monotonic, opener=None):
        self.clock, self.alive = clock, alive
        self.deadline = clock() + 8
        self.bytes = self.requests = 0
        self.total = None
        self.validator = None
        self.blocks = []
        self.opener = opener or build_opener(NoRedirect()).open
        self.url, _, options = source.partition('|')
        self.headers = {'User-Agent':'Strem4Kodi-Chapters/1','Accept-Encoding':'identity'}
        allowed = {'user-agent','referer','origin','authorization','cookie'}
        for key, value in parse_qsl(options, keep_blank_values=True):
            if key.lower() in allowed and not any(c in key+value for c in '\r\n'):
                self.headers[key.title()] = value
        parsed = urlsplit(self.url)
        self.local = None
        if parsed.scheme in ('http','https'):
            if not parsed.hostname:raise Unavailable('Invalid media address')
            if parsed.username is not None:
                credentials = unquote(parsed.username)+':'+unquote(parsed.password or '')
                self.headers.setdefault('Authorization','Basic '+base64.b64encode(credentials.encode()).decode())
                self.url = urlunsplit((parsed.scheme,parsed.netloc.rsplit('@',1)[-1],parsed.path,parsed.query,''))
        elif parsed.scheme == 'file':
            if parsed.netloc not in ('','localhost'):raise Unavailable('Remote file scheme')
            self.local = Path(url2pathname(parsed.path))
        elif not parsed.scheme or len(parsed.scheme)==1 and len(self.url)>2 and self.url[1]==':':
            if self.url.startswith(('\\\\','//')):raise Unavailable('Network filesystem path')
            self.local = Path(self.url)
        else:raise Unavailable('Unsupported media scheme')
        if self.local is not None:self.total = self.local.stat().st_size

    def check(self):
        if not self.alive() or self.clock() >= self.deadline:raise Unavailable('Metadata read cancelled')

    def read(self, offset, length):
        self.check()
        if offset < 0 or length < 0 or length > MAX_ELEMENT:raise Unavailable('Invalid metadata span')
        if not length:return b''
        if self.total is not None and offset+length > self.total:raise Unavailable('Truncated metadata')
        for start, data in self.blocks:
            if start <= offset and offset+length <= start+len(data):return data[offset-start:offset-start+length]
        if self.requests >= MAX_REQUESTS:raise Unavailable('Metadata request budget')
        wanted = max(BLOCK,length)
        if self.total is not None:wanted = min(wanted,self.total-offset)
        if self.bytes+wanted > MAX_BYTES:raise Unavailable('Metadata byte budget')
        self.requests += 1
        if self.local is not None:
            with self.local.open('rb') as handle:
                handle.seek(offset);data = handle.read(wanted)
        else:data = self.remote(offset,wanted)
        self.bytes += len(data)
        if len(data)<length:raise Unavailable('Truncated metadata')
        self.blocks.append((offset,data))
        return data[:length]

    def remote(self, offset, wanted):
        for redirects in range(4):
            self.check()
            headers = dict(self.headers,Range='bytes={}-{}'.format(offset,offset+wanted-1))
            if self.validator:headers['If-Range'] = self.validator
            try:
                response = self.opener(Request(self.url,headers=headers),timeout=max(.05,min(2,self.deadline-self.clock())))
            except HTTPError as error:
                location = error.headers.get('Location') if error.code in (301,302,303,307,308) else None
                error.close()
                if not location or redirects==3:raise Unavailable('Media metadata request declined') from None
                self.requests += 1
                if self.requests >= MAX_REQUESTS:raise Unavailable('Metadata request budget')
                target = urljoin(self.url,location)
                old, new = urlsplit(self.url),urlsplit(target)
                if new.scheme not in ('http','https') or not new.hostname or new.username is not None:
                    raise Unavailable('Unsupported media redirect')
                if (old.scheme,old.hostname,old.port)!=(new.scheme,new.hostname,new.port):
                    self.headers = {k:v for k,v in self.headers.items() if k.lower() not in ('authorization','cookie','origin','referer')}
                self.url = target
                continue
            try:
                # Do not read a byte of a server's whole-file 200 response.
                match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)',response.headers.get('Content-Range',''))
                if response.status != 206 or not match or response.headers.get('Content-Encoding','identity') != 'identity':
                    raise Unavailable('Byte ranges unavailable')
                start,end,total = map(int,match.groups())
                if start!=offset or end!=min(offset+wanted,total)-1 or end<start:
                    raise Unavailable('Inconsistent metadata range')
                validator = response.headers.get('ETag') or response.headers.get('Last-Modified')
                if self.total not in (None,total) or self.validator is not None and validator!=self.validator:
                    raise Unavailable('Media changed during metadata read')
                self.total = total
                if validator and not validator.startswith('W/'):self.validator = validator
                remaining = end-start+1
                chunks = []
                read = getattr(response,'read1',response.read)
                while remaining:
                    self.check()
                    # Refresh the socket deadline between chunks as well as
                    # requests; a trickle response must not prolong the budget.
                    sock=getattr(getattr(getattr(response,'fp',None),'raw',None),'_sock',None)
                    if sock is not None:sock.settimeout(max(.05,min(2,self.deadline-self.clock())))
                    chunk = read(min(BLOCK,remaining))
                    if not chunk or len(chunk)>remaining:raise Unavailable('Incomplete metadata range')
                    chunks.append(chunk);remaining -= len(chunk)
                return b''.join(chunks)
            finally:response.close()
        raise Unavailable('Too many media redirects')


def vint(data, offset=0, identifier=False):
    if offset>=len(data) or not data[offset]:raise Unavailable('Invalid EBML integer')
    first = data[offset]
    width = 1
    while not first & (0x80 >> (width-1)):width += 1
    if width>(4 if identifier else 8) or offset+width>len(data):raise Unavailable('Invalid EBML integer')
    value = int.from_bytes(data[offset:offset+width],'big')
    if not identifier:
        value &= (1 << (7*width))-1
        if value==(1 << (7*width))-1:value = None
    return value,width


def element(reader, offset, end):
    data = reader.read(offset,min(12,end-offset))
    identity,width = vint(data,identifier=True)
    size,extra = vint(data,width)
    start = offset+width+extra
    if start>end or size is not None and start+size>end:raise Unavailable('Invalid EBML element')
    return identity,start,size


def fields(data):
    offset = 0
    for _ in range(4096):
        if offset==len(data):return
        identity,width = vint(data,offset,True)
        size,extra = vint(data,offset+width)
        start = offset+width+extra
        if size is None or start+size>len(data):raise Unavailable('Invalid chapter element')
        yield identity,data[start:start+size]
        offset = start+size
    raise Unavailable('Too many chapter elements')


def uint(data):
    if not 1<=len(data)<=8:raise Unavailable('Invalid chapter integer')
    return int.from_bytes(data,'big')


def chapter_names(data):
    editions = []
    for identity, edition in fields(data):
        if identity!=0x45B9:continue
        values = list(fields(edition))
        if any(key in (0x45DD,0x45BD) and uint(value) for key,value in values):continue
        default = any(key==0x45DB and uint(value) for key,value in values)
        rows = []
        for key,atom in values:
            if key!=0xB6:continue
            if len(rows)>=300:raise Unavailable('Too many chapters')
            parts = list(fields(atom))
            # Linked/ordered and hierarchical editions need separate playback
            # semantics. Never flatten them into potentially incorrect jumps.
            if any(k in (0xB6,0x6E67,0x6EBC) for k,_ in parts):raise Unavailable('Linked chapter edition')
            if any(k==0x98 and uint(v) or k==0x4598 and not uint(v) for k,v in parts):continue
            starts = [uint(v)/1e9 for k,v in parts if k==0x91]
            if len(starts)!=1:raise Unavailable('Missing chapter start')
            names = []
            for k,display in parts:
                if k!=0x80:continue
                text, languages = '',[]
                for tag,value in fields(display):
                    if tag==0x85:text=value.decode('utf-8',errors='replace').strip()
                    elif tag in (0x437C,0x437D):languages.append(value.decode('ascii',errors='ignore').lower())
                if text:names.append((0 if not languages or any(s in ('eng','en') or s.startswith('en-') for s in languages) else 1,text))
            rows.append({'time':starts[0],'name':min(names,key=lambda pair:pair[0])[1] if names else ''})
        if rows:editions.append((default,rows))
    defaults = [rows for preferred,rows in editions if preferred]
    if len(defaults)==1:return defaults[0]
    return editions[0][1] if len(editions)==1 else []


def matroska(reader):
    identity,start,size = element(reader,0,reader.total)
    if identity!=0x1A45DFA3 or size is None or size>BLOCK:raise Unavailable('Invalid Matroska header')
    if not any(k==0x4282 and v in (b'matroska',b'webm') for k,v in fields(reader.read(start,size))):
        return []
    offset = start+size
    for _ in range(32):
        identity,start,size = element(reader,offset,reader.total)
        if identity==0x18538067:break
        if size is None:raise Unavailable('Invalid Matroska segment')
        offset = start+size
    else:return []
    segment = start
    end = segment+size if size is not None else reader.total
    pending,visited = [segment],set()
    for _ in range(256):
        if not pending:return []
        offset = pending.pop(0)
        if offset in visited or offset>=end:continue
        visited.add(offset)
        identity,start,size = element(reader,offset,end)
        if size is None:return []
        if identity==0x1043A770:return chapter_names(reader.read(start,size))
        if identity==0x114D9B74:
            for key,seek in fields(reader.read(start,size)):
                if key!=0x4DBB:continue
                entries = dict(fields(seek))
                target = entries.get(0x53AB,b'')
                if target in (bytes.fromhex('1043a770'),bytes.fromhex('114d9b74')) and 0x53AC in entries:
                    pending.insert(0,segment+uint(entries[0x53AC]))
        # Skip the media payload by its element length, never read through it.
        if start+size<end:pending.append(start+size)
    return []


def atoms(reader, start, end):
    for _ in range(4096):
        if start==end:return
        if end-start<8:raise Unavailable('Truncated MP4 atom')
        raw = reader.read(start,8)
        size,kind = int.from_bytes(raw[:4],'big'),raw[4:]
        header = 8
        if size==1:
            size = int.from_bytes(reader.read(start+8,8),'big');header = 16
        elif size==0:size=end-start
        if size<header or start+size>end:raise Unavailable('Invalid MP4 atom')
        yield kind,start+header,size-header
        start += size
    raise Unavailable('Too many MP4 atoms')


def mp4(reader):
    for kind,start,size in atoms(reader,0,reader.total):
        if kind!=b'moov':continue
        for child,offset,length in atoms(reader,start,start+size):
            if child!=b'udta':continue
            for tag,position,count in atoms(reader,offset,offset+length):
                if tag!=b'chpl':continue
                data = reader.read(position,count)
                if len(data)<5 or data[0] not in (0,1):return []
                index = 8 if data[0] else 4
                if index>=len(data):return []
                entries = data[index];index += 1
                rows = []
                for _ in range(entries):
                    if index+9>len(data):raise Unavailable('Truncated MP4 chapter')
                    time_ns = int.from_bytes(data[index:index+8],'big');length=data[index+8];index += 9
                    if index+length>len(data):raise Unavailable('Truncated MP4 chapter name')
                    rows.append({'time':time_ns/1e7,'name':data[index:index+length].decode('utf-8',errors='replace')})
                    index += length
                return rows
    return []


def extract(source, duration, alive=lambda:True, **options):
    """Return only a validated, flat chapter table for this exact file."""
    try:
        if not isinstance(source,str) or not math.isfinite(duration) or duration<=0:return []
        reader = Reader(source,alive=alive,**options)
        signature = reader.read(0,16)
        rows = matroska(reader) if signature[:4]==bytes.fromhex('1a45dfa3') else mp4(reader) if signature[4:8] in (b'ftyp',b'moov',b'free',b'mdat') else []
        previous = -1
        for row in rows:
            if not math.isfinite(row['time']) or not 0<=row['time']<duration or row['time']<=previous:return []
            previous = row['time']
            row['name'] = re.sub(r'[\x00-\x1f\x7f]', ' ',row['name'])[:180].strip()
        reader.check()
        return rows if len(rows)<=300 else []
    except Exception:
        # HTTP errors may contain signed URLs. They are never printed or saved.
        return []
