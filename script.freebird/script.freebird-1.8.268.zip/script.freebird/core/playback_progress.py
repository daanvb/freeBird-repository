"""Stremio library watch-progress updates driven by Kodi playback.

Pure state helpers live here so they can be regression-tested without Kodi.
Remote writes use the existing official Stremio datastore endpoints.
"""
import base64
import hashlib
from copy import deepcopy
from datetime import datetime, timezone
import zlib
from lib.progress_values import integer

WATCHED_THRESHOLD = 0.85
CREDITS_THRESHOLD = 0.90

_STATE_DEFAULTS = {
    'timeWatched': 0, 'timeOffset': 0, 'overallTimeWatched': 0,
    'timesWatched': 0, 'flaggedWatched': 0, 'duration': 0,
    'video_id': None, 'watched': None, 'noNotif': False,
}


def _now_iso(now=None):
    value = now or datetime.now(timezone.utc)
    return value.isoformat(timespec='milliseconds').replace('+00:00', 'Z')


def _released(value):
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        return parsed.replace(tzinfo=timezone.utc) if parsed.tzinfo is None else parsed
    except (TypeError, ValueError):
        return None
def _video_sort_key(video):
    def number(value):
        try:
            return int(value)
        except (TypeError, ValueError, OverflowError):
            return -1
    return (
        number(video.get('season')),
        number(video.get('episode') if video.get('episode') is not None else video.get('number')),
        str(video.get('released') or video.get('firstAired') or ''),
    )


def _video_ids(videos):
    return [str(v.get('id')) for v in sorted(
        (v for v in videos if isinstance(v, dict) and v.get('id')),
        key=_video_sort_key)]


def _watched_bits(serialized, video_ids):
    bits = [False] * len(video_ids)
    if not serialized or not video_ids:
        return bits
    try:
        anchor, length, encoded = str(serialized).rsplit(':', 2)
        anchor_length = int(length)
        if len(str(serialized)) > 100000 or not 0 < anchor_length <= 1000000:
            return bits
        inflater = zlib.decompressobj()
        values = inflater.decompress(base64.b64decode(encoded, validate=True), 125001)
        if (not inflater.eof or inflater.unused_data or len(values) > 125000
                or anchor_length > len(values) * 8):
            return bits
        anchor_index = video_ids.index(anchor)
        offset = anchor_length - anchor_index - 1
        for index in range(len(video_ids)):
            previous = index + offset
            if previous >= 0 and previous // 8 < len(values):
                bits[index] = bool((values[previous // 8] >> (previous % 8)) & 1)
    except (ValueError, TypeError, zlib.error):
        pass
    return bits
def _encode_watched(bits, video_ids):
    if not video_ids:
        return None
    values = bytearray((len(video_ids) + 7) // 8)
    for index, watched in enumerate(bits[:len(video_ids)]):
        if watched:
            values[index // 8] |= 1 << (index % 8)
    watched_indexes = [i for i, value in enumerate(bits[:len(video_ids)]) if value]
    last = watched_indexes[-1] if watched_indexes else 0
    anchor = video_ids[last] if video_ids else 'undefined'
    encoded = base64.b64encode(zlib.compress(bytes(values), 6)).decode('ascii')
    return '{}:{}:{}'.format(anchor, last + 1, encoded)


def _mark_video_watched(state, videos, video_id):
    ids = _video_ids(videos)
    if video_id not in ids:
        return
    bits = _watched_bits(state.get('watched'), ids)
    bits[ids.index(video_id)] = True
    state['watched'] = _encode_watched(bits, ids)


def _next_video(videos, current_id, now=None):
    rows = [v for v in videos if isinstance(v, dict) and v.get('id')]
    index = next((i for i, row in enumerate(rows) if str(row.get('id')) == current_id), None)
    if index is None or index + 1 >= len(rows):
        return None
    current, candidate = rows[index], rows[index + 1]
    current_season = current.get('season') if isinstance(current.get('season'), int) else 0
    next_season = candidate.get('season') if isinstance(candidate.get('season'), int) else 0
    if next_season == 0 and current_season != 0:
        return None
    released = _released(candidate.get('released') or candidate.get('firstAired'))
    instant = now or datetime.now(timezone.utc)
    if released is not None:
        if released.tzinfo is None:
            released = released.replace(tzinfo=timezone.utc)
        if released > instant:
            return None
    return candidate


def playback_context(meta, kind, video_id):
    """Return privacy-bounded playback metadata; never include the stream URL."""
    title_id = meta.get('_stremio_meta_id')
    if not title_id:
        title_id = str(video_id).split(':', 1)[0] if kind == 'series' else meta.get('id')
    return {
        'meta_id': str(title_id or ''),
        'video_id': str(video_id or ''),
        'kind': kind,
        'name': str(meta.get('tvshowtitle') or meta.get('name') or meta.get('title') or ''),
        'poster': meta.get('poster'),
        'posterShape': meta.get('posterShape') or 'poster',
        'behaviorHints': deepcopy(meta.get('behaviorHints') or {}),
        'videos': deepcopy(meta.get('videos') or []),
    }


def _new_item(context, now):
    return {
        '_id': context['meta_id'], 'type': context['kind'],
        'name': context.get('name') or context['meta_id'],
        'poster': context.get('poster'), 'posterShape': context.get('posterShape') or 'poster',
        'removed': True, 'temp': True, '_ctime': now, '_mtime': now,
        'behaviorHints': deepcopy(context.get('behaviorHints') or {}),
        'state': deepcopy(_STATE_DEFAULTS),
    }
def apply_progress(entries, context, position_ms, duration_ms, watched_delta_ms,
                   ended=False, now=None, checkpoint=False, credits_watched=False):
    """Apply one finished Kodi playback session using Stremio Core thresholds."""
    if context.get('kind') not in ('movie', 'series') or not context.get('meta_id'):
        raise ValueError('Unsupported playback identity')
    watched_delta = integer(watched_delta_ms)
    stamp = _now_iso(now)

    old = next((row for row in entries if isinstance(row, dict)
                and row.get('_id') == context['meta_id']
                and row.get('type') == context['kind']), None)
    item = deepcopy(old) if old else _new_item(context, stamp)
    state = item.setdefault('state', {})
    for key, value in _STATE_DEFAULTS.items():
        state.setdefault(key, deepcopy(value))

    video_id = context['video_id']
    same_video = state.get('video_id') == video_id
    position = integer(position_ms, integer(state.get('timeOffset')) if same_video else 0)
    duration = integer(duration_ms, integer(state.get('duration')) if same_video else 0)
    if state.get('video_id') != video_id:
        state['overallTimeWatched'] = integer(state.get('overallTimeWatched'))
        state['timeWatched'] = 0
        state['flaggedWatched'] = 0
    state['video_id'] = video_id
    state['timeWatched'] = integer(state.get('timeWatched')) + watched_delta
    state['overallTimeWatched'] = integer(state.get('overallTimeWatched')) + watched_delta
    state['timeOffset'] = position
    state['duration'] = duration
    state['lastWatched'] = stamp
    credits_watched = bool(credits_watched and context['kind'] == 'series')
    threshold = WATCHED_THRESHOLD if context['kind'] == 'series' else 0.70
    if (duration > 0 and not integer(state.get('flaggedWatched'))
            and (credits_watched or state['timeWatched'] >= duration * threshold)):
        state['flaggedWatched'] = 1
        state['timesWatched'] = integer(state.get('timesWatched')) + 1
        if context['kind'] == 'series':
            _mark_video_watched(state, context.get('videos') or [], video_id)

    if item.get('temp') and not integer(state.get('timesWatched')):
        item['removed'] = True
    if item.get('removed'):
        item['temp'] = True

    completed = not checkpoint and bool(credits_watched or ended or (duration > 0 and position > duration * CREDITS_THRESHOLD))
    if completed:
        state['timeOffset'] = 0
        if context['kind'] == 'series':
            nxt = _next_video(context.get('videos') or [], video_id, now)
            if nxt is not None:
                state['video_id'] = str(nxt['id'])
                state['timeWatched'] = 0
                state['flaggedWatched'] = 0
                state['timeOffset'] = 1

    item['_mtime'] = stamp
    return item


def sync_progress(store, context, position_ms, duration_ms, watched_delta_ms,
                  ended=False, request_func=None, pull_func=None, checkpoint=False,
                  captured_at=None, prepared_item=None, prepare_func=None, credits_watched=False,
                  expected_owner=None, observed_item=None, observed_known=False):
    """Pull latest library, write one item, then verify and refresh local account state."""
    from account import AccountError, request, pull_library
    from lib.viewer_profiles import library_transport, ViewerAccount
    if isinstance(store, ViewerAccount):store = store.freeze()
    transport=library_transport(store)
    if transport:request_func,pull_func=transport
    request_func = request_func or request
    pull_func = pull_func or pull_library
    local = store.load()
    token = local.get('token')
    if not token:
        return None
    # A queued event belongs to the account that captured it. The account may
    # change after the outbox selects the event but before this worker starts.
    if expected_owner is not None and hashlib.sha256(str(token).encode()).hexdigest()!=expected_owner:
        raise AccountError('Account changed during sync.')
    latest = pull_func(token)
    current=next((r for r in latest if r.get('_id')==context['meta_id'] and r.get('type')==context['kind']),None)
    stamp=_released(captured_at) if captured_at else None
    existing_stamp=_released((current or {}).get('_mtime'))
    # A durable retry must not replay an old offset over newer device activity.
    # Equal timestamps can belong to distinct checkpoints captured in the same
    # millisecond. Only a matching durable snapshot acknowledges our own write.
    acknowledged = (prepared_item is not None and current is not None
                    and current.get('state') == prepared_item.get('state'))
    if transport and observed_known and not acknowledged:
        from lib.viewer_sync import clean_library,record_progress_conflict,same_progress
        observed=clean_library([observed_item])
        actual=clean_library([current])
        unchanged=(observed==actual or bool(observed and actual and same_progress(observed[0],actual[0])))
        if not unchanged and current is not None:
            candidate=prepared_item or apply_progress([observed_item] if observed_item else [],context,
                position_ms,duration_ms,watched_delta_ms,ended=ended,now=stamp,
                checkpoint=checkpoint,credits_watched=credits_watched)
            if not record_progress_conflict(store.directory,local.viewer_id,candidate,current):
                raise AccountError('Viewer progress changed; retrying without discarding the checkpoint.')
            return current
    if not (transport and observed_known) and stamp and existing_stamp and (existing_stamp > stamp or
                                    existing_stamp == stamp and acknowledged):
        fresh=store.load()
        if fresh.get('token')!=token:raise AccountError('Account changed during sync.')
        fresh['library']=latest;store.save(fresh);return current
    if acknowledged:
        fresh=store.load()
        if fresh.get('token')!=token:raise AccountError('Account changed during sync.')
        fresh['library']=latest
        store.save(fresh)
        return current
    item = prepared_item or apply_progress(latest, context, position_ms, duration_ms,
                          watched_delta_ms, ended=ended, now=stamp, checkpoint=checkpoint, credits_watched=credits_watched)
    if prepare_func and prepared_item is None:prepare_func(item)
    if store.load().get('token')!=token:raise AccountError('Account changed during sync.')
    response = request_func('https://api.strem.io/api/datastorePut', {
        'authKey': token, 'collection': 'libraryItem', 'changes': [item]})
    if not isinstance(response, dict) or response.get('error'):
        raise AccountError('Stremio rejected the watch-progress update.')
    verified = pull_func(token)
    remote = next((row for row in verified if isinstance(row, dict)
                   and row.get('_id') == item['_id'] and row.get('type') == item['type']), None)
    if remote is None:
        raise AccountError('Stremio did not confirm the watch-progress update.')
    remote_stamp = _released(remote.get('_mtime'))
    item_stamp = _released(item.get('_mtime'))
    # Datastore reads can lag a successful write. Existence alone does not
    # acknowledge this event; keep the prepared write durable until it appears.
    if remote != item and not (remote_stamp and item_stamp and remote_stamp > item_stamp):
        if not (remote_stamp == item_stamp and remote.get('state') == item.get('state')):
            raise AccountError('Stremio did not confirm the watch-progress update.')
    local=store.load()
    if local.get('token')!=token:raise AccountError('Account changed during sync.')
    local['library'] = verified
    store.save(local)
    return remote
