"""Small HTTP adapter; independent of Kodi and without account credentials."""
import json
import socket
import ssl
import time
from urllib.error import URLError
from urllib.parse import quote, urlencode, urlsplit
from urllib.request import Request, urlopen


def base_url(manifest):
    parsed = urlsplit(manifest)
    if (parsed.scheme not in ('https', 'http') or not parsed.netloc
            or not parsed.path.endswith('/manifest.json')
            or parsed.query or parsed.fragment or parsed.username or parsed.password):
        raise ValueError('Use an HTTP(S) URL ending in /manifest.json')
    return manifest[:-len('/manifest.json')]


def resource_url(manifest, resource, kind, identity, extras=None):
    if resource not in ('catalog', 'meta', 'stream', 'subtitles'):
        raise ValueError('Unsupported resource')
    url = base_url(manifest) + '/' + '/'.join(
        quote(str(part), safe='') for part in (resource, kind, identity))
    if extras:
        url += '/' + urlencode(extras, quote_via=quote)
    return url + '.json'


def _browse_cache(url):
    # Configurable browsing data only, never account or playback credentials.
    try:
        from lib.cache_policy import resource_category, read_policy, open_cache
        group = resource_category(url)
        if group is None:
            return None, 0
        policy = read_policy()
        cache = open_cache(group, policy)
        return (cache, policy[group]) if cache is not None else (None, 0)
    except Exception:
        return None, 0


def fetch(url, timeout=15, use_cache=True, cache_info=None, refresh=False, cache_scope=None):
    # Metadata callers may request a fresh response and receive its original
    # deadline for derived artwork caches. Other resource caches are unchanged.
    started = time.monotonic()
    try:
        result, cached = _fetch(url, timeout, use_cache, cache_info, refresh, cache_scope)
    except Exception as error:
        _record(url, started, 'failed', getattr(error, 'code', None), failure_reason(error), timeout=timeout)
        raise
    _record(url, started, 'failed' if result.get('error') else ('cached' if cached else 'refreshed'),
            reason='Addon returned an error' if result.get('error') else None, timeout=timeout)
    return result


class ResponseError(ValueError):
    """A response validation failure with a fixed, safe diagnostic label."""


def failure_reason(error):
    """Classify by exception type only; exception text can contain private URLs."""
    cause = error.reason if isinstance(error, URLError) else error
    if isinstance(cause, (TimeoutError, socket.timeout)):
        return 'Request timed out'
    if isinstance(cause, socket.gaierror):
        return 'Server address could not be resolved'
    if isinstance(cause, ssl.SSLCertVerificationError):
        return 'Server certificate could not be verified'
    if isinstance(cause, ssl.SSLError):
        return 'Secure connection failed'
    if isinstance(cause, ConnectionError):
        return 'Connection to server failed'
    if isinstance(cause, (json.JSONDecodeError, UnicodeDecodeError)):
        return 'Addon returned invalid JSON'
    if isinstance(cause, ResponseError):
        return str(cause)
    return 'Request failed'


def _record(url, started, status, http=None, reason=None, timeout=None):
    try:
        from lib.provider_diagnostics import record
        record(url, started, status, http, reason, timeout=timeout)
    except Exception:
        pass  # Diagnostic storage can never break playback or browsing.


def _fetch(url, timeout, use_cache, cache_info=None, refresh=False, cache_scope=None):
    cache, ttl = _browse_cache(url) if use_cache else (None, 0)
    if cache_info is not None:cache_info['expires'] = 0
    if cache is not None:
        from lib.cache_policy import resource_category
        if resource_category(url) == 'metadata':
            from lib.metadata_response import fetch as shared_metadata
            return shared_metadata(cache, url, ttl, lambda: _fetch(url, timeout, False)[0],
                                   timeout, cache_info, refresh, cache_scope)
    memory = None
    memory_key = (getattr(cache, 'path', None), getattr(cache, 'category', None),
                  getattr(cache, 'max_bytes', None), ttl,
                  getattr(cache, 'generation', ()), url)
    if cache is not None and getattr(cache, 'current', lambda: True)():
        try:
            from lib import memory_cache as memory
            hot = memory.get(memory_key)
            if isinstance(hot, dict):
                return hot, True
        except Exception:
            memory = None
    if cache is not None:
        try:
            entry = cache.get_with_expiry(url)
            if entry is not None:
                cached, expires = entry
                if not isinstance(cached, dict):
                    raise ValueError('Invalid cached response')
                if memory is not None:
                    memory.put_until(memory_key, cached, expires)
                return cached, True
        except Exception:
            pass

    request = Request(url, headers={'Accept': 'application/json', 'User-Agent': 'Strem4Kodi/1'})
    with urlopen(request, timeout=timeout) as response:
        data = response.read(8 * 1024 * 1024 + 1)
    if len(data) > 8 * 1024 * 1024:
        raise ResponseError('Addon response is too large')
    result = json.loads(data)
    if not isinstance(result, dict):
        raise ResponseError('Addon returned an invalid response')
    if cache is not None and not result.get('error') and (result.get('meta') or result.get('metas')):
        try:
            expires = None if ttl is None else time.time() + ttl
            cache.put(url, result, ttl)
            if memory is not None and getattr(cache, 'current', lambda: True)():
                memory.put_until(memory_key, result, expires)
        except Exception:
            pass
    return result, False


def catalogs(manifest):
    """Only catalogs usable without mandatory search/genre filters."""
    return [c for c in manifest.get('catalogs', [])
            if c.get('id') and c.get('type')
            and not any(e.get('isRequired') for e in c.get('extra', []))]
