
"""Stremio-native metadata aggregation for the skin.

No Kodi helper addons are required. Installed providers supply presentation;
Cinemeta supplies the independent IMDb episode reference and protocol fallback.
"""
import re
import threading
import time
from copy import deepcopy
from concurrent.futures import ThreadPoolExecutor

from protocol import fetch, resource_url
from sources import supports

HOME_MANIFEST = 'https://v3-cinemeta.strem.io/manifest.json'
_reference_cache = {}
_reference_loading = {}
_reference_lock = threading.Lock()


def _episode_reference(identity, fetcher):
    """One bounded details lookup, reused by availability/details for an hour.

    Protocol caching also persists the response across interpreter restarts.
    Negative results retry after a minute. Never run from startup alone.
    """
    if not re.fullmatch(r'tt\d+', str(identity)):
        return {}
    key = (fetcher, identity)
    with _reference_lock:
        cached = _reference_cache.get(key)
        if cached and cached[0] > time.monotonic():return deepcopy(cached[1])
        pending = _reference_loading.get(key)
        owner = pending is None
        if owner:
            pending = _reference_loading[key] = threading.Event()
    if not owner:
        pending.wait(5.5)
        with _reference_lock:
            cached = _reference_cache.get(key)
            return deepcopy(cached[1]) if cached else {}
    result = {}
    try:
        url = resource_url(HOME_MANIFEST, 'meta', 'series', identity)
        payload = fetch(url, timeout=5) if fetcher is fetch else fetcher(url)
        meta = payload.get('meta') if isinstance(payload, dict) else None
        if (isinstance(meta, dict) and meta.get('id', identity) == identity
                and meta.get('type', 'series') == 'series'):
            result = normalize(meta, 'series', identity)
            from episode_identity import coordinates, conflict
            result['videos'] = [v for v in result['videos'] if coordinates(v) is not None
                                and not conflict(v, identity)
                                and v.get('id') == '{}:{}:{}'.format(identity, *coordinates(v))]
            result['_metadata_provider'] = 'Cinemeta'
    except Exception:
        pass
    with _reference_lock:
        if len(_reference_cache) >= 32:_reference_cache.clear()
        _reference_cache[key] = (time.monotonic() + (3600 if result.get('videos') else 60), result)
        _reference_loading.pop(key, None)
        pending.set()
    return deepcopy(result)
MERGE_FIELDS = (
    'name', 'description', 'tagline', 'poster', 'background', 'landscape', 'logo',
    'releaseInfo', 'released', 'year', 'runtime', 'imdbRating', 'country',
    'awards', 'status', 'imdb_id', 'moviedb_id', 'tvdb_id', 'behaviorHints',
    'languages', 'language', 'spokenLanguages', 'audioLanguages', 'ratings',
    'quality', 'resolution', 'height', 'audio', 'audioCodec', 'hdr', 'bitDepth',
    'availableFormats', 'videoFormats', 'audioFormats',
)


def _list(value):
    if isinstance(value, list):
        return [item for item in value if item not in (None, '')]
    if isinstance(value, str) and value.strip():
        return [value.strip()]
    return []


def _dedupe(values):
    out = []
    for value in values:
        if value not in out:
            out.append(value)
    return out


def _person_image(value, *, tmdb_relative=False):
    if not isinstance(value, str):
        return ''
    value = value.strip()
    if tmdb_relative and re.fullmatch(r'/[A-Za-z0-9._/-]+', value):
        return 'https://image.tmdb.org/t/p/w342' + value
    return value if re.match(r'^https?://', value, re.I) else ''


def _person_rows(value, default_job):
    rows = []
    for entry in ([value] if isinstance(value, dict) else _list(value)):
        if isinstance(entry, dict):
            nested = entry.get('person') if isinstance(entry.get('person'), dict) else entry
            name = str(nested.get('name') or nested.get('title') or entry.get('name') or '').strip()
            image = ''
            for field in ('photo', 'image', 'profile', 'profile_path', 'poster', 'thumbnail'):
                candidate = nested.get(field)
                if field == 'image' and isinstance(candidate, dict):
                    image = (_person_image(candidate.get('original')) or _person_image(candidate.get('medium'))
                             or _person_image(candidate.get('url')))
                else:
                    image = _person_image(candidate, tmdb_relative=(field == 'profile_path'))
                if image:
                    break
            specific = entry.get('character') or entry.get('job') or entry.get('role') or nested.get('character') or nested.get('job')
            job = ('as ' + str(specific).strip()) if entry.get('character') and str(specific).strip() else str(specific or default_job).strip()
        else:
            name, image, job = str(entry).strip(), '', default_job
        if name:
            row = {'name': name, 'job': job or default_job, 'poster': image}
            if isinstance(entry, dict):
                person_id = str(nested.get('tmdb_person_id') or entry.get('tmdb_person_id') or '')
                if re.fullmatch(r'[1-9]\d*', person_id):
                    row['tmdb_person_id'] = person_id
            rows.append(row)
    return rows


def _merge_people(rows):
    merged, order = {}, []
    generic = {'Cast', 'Director', 'Writer'}
    rows = [row for row in rows or [] if isinstance(row, dict)]
    ids_by_name = {}
    for row in rows:
        if row.get('tmdb_person_id'):
            name = str(row.get('name') or '').strip().casefold()
            ids_by_name.setdefault(name, set()).add(str(row['tmdb_person_id']))
    for row in rows:
        name = str(row.get('name') or '').strip()
        if not name:
            continue
        folded = name.casefold()
        # Name-only supplier credits can join an unambiguous TMDB match.
        # Distinct people with the same name must retain separate profiles.
        key = (folded, str(row.get('tmdb_person_id') or '') if len(ids_by_name.get(folded, ())) > 1 else '')
        if key not in merged:
            merged[key] = {'name': name, 'job': str(row.get('job') or '').strip(),
                           'poster': _person_image(row.get('poster'))}
            order.append(key)
            if row.get('tmdb_person_id'):
                merged[key]['tmdb_person_id'] = row['tmdb_person_id']
            continue
        current = merged[key]
        if not current.get('tmdb_person_id') and row.get('tmdb_person_id'):
            current['tmdb_person_id'] = row['tmdb_person_id']
        if not current.get('poster') and row.get('poster'):
            current['poster'] = _person_image(row.get('poster'))
        old_job, new_job = current.get('job') or '', str(row.get('job') or '').strip()
        if new_job and new_job != old_job:
            if old_job in generic and new_job not in generic:
                current['job'] = new_job
            elif new_job in generic and old_job not in generic:
                pass
            elif new_job not in old_job.split(' / '):
                current['job'] = ' / '.join(v for v in (old_job, new_job) if v)
    return [merged[key] for key in order]


def languages(meta):
    """Return provider-supplied spoken/audio languages as label/code rows.

    Metadata addons do not agree on one field name or value shape, so this is
    deliberately tolerant.  It never guesses from a production country.
    """
    meta = meta if isinstance(meta, dict) else {}
    source = (meta.get('languages') or meta.get('spokenLanguages')
              or meta.get('audioLanguages') or meta.get('language') or [])
    rows = []
    for value in _list(source):
        if isinstance(value, dict):
            code = str(value.get('code') or value.get('iso_639_1')
                       or value.get('iso639_1') or '').strip().lower()
            label = str(value.get('name') or value.get('english_name')
                        or value.get('label') or code).strip()
        else:
            label = str(value).strip()
            code = label.lower() if len(label) in (2, 3) else ''
        if not label:
            continue
        row = {'label': label, 'code': code.upper()}
        if row not in rows:
            rows.append(row)
    return rows
def normalize(meta, kind='', identity=''):
    meta = dict(meta) if isinstance(meta, dict) else {}
    if identity:
        meta.setdefault('id', identity)
    if kind:
        meta.setdefault('type', kind)
    if not meta.get('landscape') and isinstance(meta.get('landscapePoster'), str):
        meta['landscape'] = meta['landscapePoster']
    genres = _list(meta.get('genres') or meta.get('genre'))
    meta['genres'] = _dedupe([str(v) for v in genres])
    cast_people = _merge_people(_person_rows(meta.get('castPeople'), 'Cast') + _person_rows(meta.get('cast'), 'Cast'))
    director_people = _merge_people(_person_rows(meta.get('directorPeople'), 'Director') + _person_rows(meta.get('director'), 'Director'))
    writer_people = _merge_people(_person_rows(meta.get('writerPeople'), 'Writer') + _person_rows(meta.get('writer'), 'Writer'))
    meta['castPeople'], meta['directorPeople'], meta['writerPeople'] = cast_people, director_people, writer_people
    meta['cast'] = [row['name'] for row in cast_people]
    meta['director'] = [row['name'] for row in director_people]
    meta['writer'] = [row['name'] for row in writer_people]
    videos = meta.get('videos')
    meta['videos'] = [v for v in videos if isinstance(v, dict)] if isinstance(videos, list) else []
    links = meta.get('links')
    meta['links'] = [v for v in links if isinstance(v, dict)] if isinstance(links, list) else []
    return meta


def _home_descriptor(fetcher=fetch):
    manifest = fetcher(HOME_MANIFEST)
    return {'transportUrl': HOME_MANIFEST, 'manifest': manifest, 'fallback': True}


def candidates(providers, kind, identity, fetcher=fetch):
    rows, seen = [], set()
    for provider in providers or []:
        url = provider.get('transportUrl') if isinstance(provider, dict) else None
        manifest = provider.get('manifest', {}) if isinstance(provider, dict) else {}
        if url and url not in seen and supports(manifest, kind, identity, 'meta'):
            seen.add(url)
            rows.append(provider)
    if HOME_MANIFEST not in seen:
        try:
            rows.append(_home_descriptor(fetcher))
        except Exception:
            pass
    return rows
def merged_meta(kind, identity, providers=(), fetcher=fetch):
    from provider_roles import is_aiometadata, key as provider_key
    # Do not even fetch the fallback manifest until AIOmetadata has answered.
    primary = [p for p in providers if is_aiometadata(p)
               and supports(p.get('manifest') or {}, kind, identity, 'meta')]
    def one(provider):
        try:
            payload = fetcher(resource_url(provider['transportUrl'], 'meta', kind, identity))
            meta = payload.get('meta') if isinstance(payload, dict) else None
            if (not isinstance(meta, dict) or str(meta.get('id', identity)) != str(identity)
                    or meta.get('type', kind) != kind):
                return {}
            result = normalize(meta, kind, identity)
            for role, fields in (('artwork', ('poster', 'background', 'landscape', 'logo', 'thumbnail')),
                                 ('ratings', ('rating', 'imdbRating', 'tmdbRating', 'ratings'))):
                if role in provider.get('_disabled_roles', []):
                    for field in fields:result.pop(field, None)
                    result['videos'] = [{k: v for k, v in video.items() if k not in fields}
                                        for video in result.get('videos', [])]
            result['_preferred_roles'] = provider.get('_preferred_roles') or []
            if is_aiometadata(provider):
                result['_preferred_roles'] = list(set(result['_preferred_roles']) | {'artwork'})
            result['_metadata_provider'] = (provider.get('manifest') or {}).get('name') or 'Cinemeta'
            result['_artwork_source'] = provider_key(provider)
            result['videos'] = [dict(v, _thumbnail_provider=result['_metadata_provider']) if v.get('thumbnail') else dict(v)
                                for v in result.get('videos', [])]
            if result.get('poster'):
                manifest = provider.get('manifest') or {}
                result['_poster_provider'] = manifest.get('name') or manifest.get('id') or ''
            return result
        except Exception:
            return {}

    results = []
    for provider in primary:
        result = one(provider)
        if result:
            results.append(result)
            break
    required = ('name', 'description', 'poster', 'background', 'landscape', 'logo', 'genres', 'runtime')
    complete = bool(results) and all(results[0].get(field) for field in required)
    if kind == 'series':
        complete = complete and bool(results[0].get('videos'))
        if complete:
            videos = sorted(results[0]['videos'], key=lambda v: repr(_episode_key(v)))
            titles = [str(v.get('title') or v.get('name') or '').strip().casefold() for v in videos]
            complete = not any(a and a == b for a, b in zip(titles, titles[1:]))
    rating_needed = any('ratings' in p.get('_preferred_roles', []) and p not in primary
                        for p in providers)
    if not complete or rating_needed:
        rows = ([p for p in providers if supports(p.get('manifest') or {}, kind, identity, 'meta')]
                if kind == 'series' and re.fullmatch(r'tt\d+', str(identity))
                else candidates(providers, kind, identity, fetcher))
        rows = [p for p in rows if p not in primary]
        if kind == 'series' and re.fullmatch(r'tt\d+', str(identity)):
            rows = [p for p in rows if p.get('transportUrl') != HOME_MANIFEST]
        with ThreadPoolExecutor(max_workers=min(4, max(1, len(rows)))) as pool:
            results += list(pool.map(one, rows)) if rows else []

    reference = _episode_reference(identity, fetcher) if kind == 'series' else {}
    if reference:results.append(reference)

    merged = {'id': identity, 'type': kind, 'genres': [], 'cast': [],
              'director': [], 'writer': [], 'castPeople': [], 'directorPeople': [], 'writerPeople': [], 'videos': [], 'links': []}
    for field, role in (('poster', 'artwork'), ('background', 'artwork'), ('landscape', 'artwork'),
                        ('logo', 'artwork'), ('imdbRating', 'ratings'), ('ratings', 'ratings')):
        for meta in sorted(results, key=lambda m: role not in m.get('_preferred_roles', [])):
            if meta.get(field) not in (None, '', [], {}):
                merged[field] = meta[field]
                merged['_poster_provider' if field == 'poster' else
                       ('_artwork_provider' if role == 'artwork' else '_ratings_provider')] = meta.get('_metadata_provider', '')
                if field == 'poster':
                    merged['_artwork_source'] = meta.get('_artwork_source')
                if field == 'poster' and 'artwork' in meta.get('_preferred_roles', []):
                    merged['_poster_preferred'] = True
                break
    # Episode artwork and scores can have separate suppliers without another request.
    video_groups = [(meta.get('videos') or []) for meta in results if meta]
    for group in video_groups:
        merged['videos'] = _merge_videos(merged['videos'], group)
    _correct_repeated_episode_titles(merged['videos'], video_groups)
    if kind == 'series':
        from episode_identity import reconcile, VERSION
        merged['videos'] = reconcile(merged['videos'], reference.get('videos') or [], identity)
        merged['_episode_identity_version'] = VERSION
    for role, fields in (('artwork', ('thumbnail',)),
                         ('ratings', ('rating', 'imdbRating', 'tmdbRating', 'ratings'))):
        priority = next((m for m in results if role in m.get('_preferred_roles', [])), None)
        if priority:
            by_episode = {_episode_key(v): v for v in priority.get('videos', [])
                          if _episode_key(v) != ('id', '')}
            # Copy only this role's fields: artwork preference must not decide ratings.
            for episode in merged['videos']:
                episode_key = _episode_key(episode)
                match = by_episode.get(episode_key)
                if match:
                    for field in fields:
                        if match.get(field) not in (None, '', [], {}):
                            episode[field] = match[field]
                            if field == 'thumbnail':
                                episode['_thumbnail_provider'] = priority.get('_metadata_provider', '')
    for meta in results:
        if not meta:
            continue
        if not merged.get('_metadata_provider'):
            merged['_metadata_provider'] = meta.get('_metadata_provider', '')
        for field in MERGE_FIELDS:
            value = meta.get(field)
            if value not in (None, '', [], {}) and merged.get(field) in (None, '', [], {}):
                merged[field] = value
                if field == 'poster':
                    merged['_poster_provider'] = meta.get('_poster_provider', '')
        for field in ('genres', 'cast', 'director', 'writer', 'links'):
            merged[field] = _dedupe(merged.get(field, []) + meta.get(field, []))
        for field in ('castPeople', 'directorPeople', 'writerPeople'):
            merged[field] = _merge_people(merged.get(field, []) + meta.get(field, []))
        if not merged.get('trailers') and meta.get('trailers'):
            merged['trailers'] = meta.get('trailers')
        if not merged.get('trailerStreams') and meta.get('trailerStreams'):
            merged['trailerStreams'] = meta.get('trailerStreams')
    merged['_metadata_checked'] = True
    return normalize(merged, kind, identity)


def _episode_key(row):
    try:
        number = row.get('episode', row.get('number'))
        if row.get('season') is not None and number is not None:
            return ('episode', int(row['season']), int(number))
    except (TypeError, ValueError, OverflowError):
        pass
    return ('id', str(row.get('id') or ''))


def _merge_videos(current, incoming):
    """Keep primary-provider episode artwork while filling fallback gaps."""
    result = [dict(row) for row in current]
    key = _episode_key
    by_key = {key(row): row for row in result if key(row) != ('id', '')}
    for row in incoming:
        identity = key(row)
        previous = by_key.get(identity)
        if previous is None:
            copy = dict(row)
            result.append(copy)
            if identity != ('id', ''):
                by_key[identity] = copy
        else:
            for field, value in row.items():
                if previous.get(field) in (None, '', [], {}) and value not in (None, '', [], {}):
                    previous[field] = value
    return result


def _correct_repeated_episode_titles(videos, groups):
    """Repair a shifted title only when another provider confirms both rows."""
    by_key = {_episode_key(row): row for row in videos}
    alternatives_by_group = [{_episode_key(item): item for item in group} for group in groups]
    for key, row in by_key.items():
        if len(key) != 3 or key[0] != 'episode' or key[2] <= 1:
            continue
        previous_key = ('episode', key[1], key[2] - 1)
        previous = by_key.get(previous_key)
        title = str(row.get('title') or row.get('name') or '').strip()
        if not previous or not title or title.casefold() != str(previous.get('title') or previous.get('name') or '').strip().casefold():
            continue
        for alternatives in alternatives_by_group:
            earlier = alternatives.get(previous_key, {})
            later = alternatives.get(key, {})
            earlier_title = str(earlier.get('title') or earlier.get('name') or '').strip()
            later_title = str(later.get('title') or later.get('name') or '').strip()
            if earlier_title.casefold() == title.casefold() and later_title and later_title.casefold() != title.casefold():
                row['title'] = later_title
                row['name'] = later_title
                break
def resolve_identity(kind, identity='', query='', fetcher=fetch):
    identity = str(identity or '').strip()
    if identity:
        return identity, {}
    query = str(query or '').strip()
    if not query:
        return '', {}
    try:
        payload = fetcher(resource_url(HOME_MANIFEST, 'catalog', kind, 'top', {'search': query}))
        rows = [normalize(v, kind) for v in payload.get('metas', []) if isinstance(v, dict)]
    except Exception:
        return '', {}
    if not rows:
        return '', {}
    key = re.sub(r'\W+', '', query).casefold()
    best = next((row for row in rows
                 if re.sub(r'\W+', '', str(row.get('name', ''))).casefold() == key), rows[0])
    return str(best.get('id', '')), best


def availability_episodes(kind, identity, providers=(), fetcher=fetch):
    """Resolve an episode list without waiting for a full metadata merge."""
    if kind != 'series' or not identity:
        return {}
    reference = _episode_reference(identity, fetcher)
    if reference.get('videos'):
        return reference
    urls = []
    for provider in providers or []:
        url = provider.get('transportUrl') if isinstance(provider, dict) else None
        if url and url not in urls and supports(provider.get('manifest') or {}, kind, identity, 'meta'):
            urls.append(url)
    if HOME_MANIFEST not in urls and re.fullmatch(r'tt\d+', str(identity)):
        urls.append(HOME_MANIFEST)
    for url in urls:
        try:
            payload = fetcher(resource_url(url, 'meta', kind, identity))
            meta = payload.get('meta') if isinstance(payload, dict) else None
            if (not isinstance(meta, dict) or str(meta.get('id', identity)) != str(identity)
                    or meta.get('type', kind) != kind):
                continue
            result = normalize(meta, kind, identity)
            for video in result.get('videos', []):
                try:
                    if video.get('id') and int(video.get('season') or 0) > 0 and int(video.get('episode', video.get('number')) or 0) > 0:
                        return result
                except (TypeError, ValueError, OverflowError):
                    continue
        except Exception:
            continue
    return {}


def details(kind, identity='', query='', providers=(), fetcher=fetch):
    resolved, preview = resolve_identity(kind, identity, query, fetcher)
    if not resolved:
        return normalize(preview, kind)
    meta = merged_meta(kind, resolved, providers, fetcher)
    for key, value in preview.items():
        if meta.get(key) in (None, '', [], {}):
            meta[key] = value
    return normalize(meta, kind, resolved)


def people(meta, role='cast'):
    if role == 'crew':
        rows = list(meta.get('directorPeople') or _person_rows(meta.get('director'), 'Director'))
        rows += list(meta.get('writerPeople') or _person_rows(meta.get('writer'), 'Writer'))
    else:
        rows = list(meta.get('castPeople') or _person_rows(meta.get('cast'), 'Cast'))
    return _merge_people(rows)

def cast_menu(meta, lookup=people):
    """Director cards lead the Cast menu; acting credits retain their own roles."""
    declared = people({'directorPeople': meta.get('directorPeople'), 'director': meta.get('director')}, 'crew')
    crew = lookup(meta, 'crew')
    credited = declared + [row for row in crew
                           if 'director' in [job.strip().casefold() for job in row['job'].split('/')]]
    keys = {(row['name'].casefold(), str(row.get('tmdb_person_id') or '')) for row in credited}
    merged = _merge_people(declared + crew)
    # A name-only director can inherit a unique crew match. If there are
    # namesakes, only include the specifically credited person.
    counts = {}
    for row in merged:
        name = row['name'].casefold()
        counts[name] = counts.get(name, 0) + 1
    directors = []
    for row in merged:
        name = row['name'].casefold()
        if ((name, str(row.get('tmdb_person_id') or '')) in keys
                or (counts[name] == 1 and (name, '') in keys)):
            directors.append(dict(row, job='Director', filmography_role='crew'))
    return directors + lookup(meta, 'cast')


def trailer_rows(meta):
    rows, seen = [], set()
    for row in meta.get('trailerStreams') or []:
        if not isinstance(row, dict):
            continue
        yt = str(row.get('ytId', ''))
        if re.fullmatch(r'[A-Za-z0-9_-]{11}', yt) and yt not in seen:
            seen.add(yt)
            rows.append({'id': yt, 'name': row.get('title') or 'Trailer'})
    for row in meta.get('trailers') or []:
        if not isinstance(row, dict):
            continue
        yt = str(row.get('source', ''))
        if re.fullmatch(r'[A-Za-z0-9_-]{11}', yt) and yt not in seen:
            seen.add(yt)
            rows.append({'id': yt, 'name': row.get('type') or 'Trailer'})
    return rows


def seasons(meta):
    counts = {}
    for video in meta.get('videos', []):
        try:
            season = int(video.get('season', 0))
        except (TypeError, ValueError, OverflowError):
            continue
        counts[season] = counts.get(season, 0) + 1
    return [{'season': season, 'count': counts[season]} for season in sorted(counts)]


def episodes(meta, season):
    try:
        season = int(season)
    except (TypeError, ValueError, OverflowError):
        return []
    rows = []
    for video in meta.get('videos', []):
        try:
            current = int(video.get('season', 0))
        except (TypeError, ValueError, OverflowError):
            continue
        if current == season and video.get('id'):
            rows.append(dict(video))
    return sorted(rows, key=lambda row: int(row.get('episode') or row.get('number') or 0))
def _catalogs_for(provider, kind):
    manifest = provider.get('manifest', {})
    for catalog in manifest.get('catalogs', []):
        if not isinstance(catalog, dict) or catalog.get('type') != kind or not catalog.get('id'):
            continue
        extras = {str(e.get('name')) for e in catalog.get('extra', []) if isinstance(e, dict)}
        yield catalog, extras


def search(query, providers=(), kinds=('movie', 'series'), limit=60, fetcher=fetch,
           provider_first=False, fallback_only=False):
    from search_match import normalized, query_variants, search_artwork, searchable_title, title_relevance, title_identity
    query = str(query or '').strip()
    if not normalized(query):
        return []
    try:
        home = None if fallback_only and providers else _home_descriptor(fetcher)
    except Exception:
        home = None

    pool, seen_urls = [], set()
    supplied = list(providers or [])
    ordered = supplied + ([home] if home else []) if provider_first else ([home] if home else []) + supplied
    for provider in ordered:
        if not provider:
            continue
        url = provider.get('transportUrl')
        if not url or url in seen_urls:
            continue
        seen_urls.add(url)
        pool.append(provider)

    requests = []
    for provider in pool:
        manifest = provider.get('manifest', {})
        provider_name = re.sub(r'[^a-z0-9]', '', str(manifest.get('name', '')).lower())
        if any(name in provider_name for name in ('morecontentlikethis', 'contentdeepdive')):
            continue
        for kind in kinds:
            for catalog, extras in _catalogs_for(provider, kind):
                required = {str(e.get('name')) for e in catalog.get('extra', []) if isinstance(e, dict) and e.get('isRequired')}
                if 'search' in extras and not required - {'search'}:
                    requests.append((provider['transportUrl'], kind, catalog['id']))

    def request(descriptor):
        url, kind, catalog_id = descriptor
        for term in query_variants(query)[:2]:
            try:
                payload = fetcher(resource_url(url, 'catalog', kind, catalog_id, {'search': term}))
            except Exception:
                # Do not multiply requests to an unavailable provider.
                return []
            if not isinstance(payload, dict) or not isinstance(payload.get('metas', []), list):
                return []
            rows = []
            for row in payload.get('metas', [])[:max(limit, 100)]:
                if not searchable_title(row, kind) or row.get('type', kind) != kind:
                    continue
                if title_relevance(query, row) is not None:
                    owner = next((p for p in pool if p.get('transportUrl') == url), {})
                    from provider_roles import key as provider_key
                    rows.append(normalize(dict(row, poster=search_artwork(row),
                                               _artwork_source=provider_key(owner),
                                               _poster_provider=(owner.get('manifest') or {}).get('name', '')), kind, row['id']))
            if rows:
                return rows
            # A non-empty unrelated response is not a punctuation failure.
            if payload.get('metas'):
                return []
        return []

    if not requests:
        return search(query, kinds=kinds, limit=limit, fetcher=fetcher) if fallback_only and supplied else []
    with ThreadPoolExecutor(max_workers=4) as executor:
        if fallback_only and supplied:
            primary = [r for r in requests if r[0] == supplied[0].get('transportUrl')]
            batches = list(executor.map(request, primary))
            if not any(batches):
                return search(query, supplied[1:], kinds=kinds, limit=limit, fetcher=fetcher,
                              provider_first=True, fallback_only=bool(supplied[1:]))
        else:
            batches = list(executor.map(request, requests))
    output, seen_ids = [], set()
    for rows in batches:
        for row in rows:
            key = title_identity(row)
            if key not in seen_ids:
                seen_ids.add(key)
                output.append(row)
    return sorted(output, key=lambda row: title_relevance(query, row))[:limit]


def recommendations(meta, providers=(), limit=24, fetcher=fetch):
    kind, identity = meta.get('type'), meta.get('id')
    if kind not in ('movie', 'series') or not identity:
        return []
    try:
        home = _home_descriptor(fetcher)
    except Exception:
        home = None
    pool, seen_urls = [], set()
    for provider in list(providers or []) + ([home] if home else []):
        if not provider:
            continue
        url = provider.get('transportUrl')
        if not url or url in seen_urls:
            continue
        seen_urls.add(url)
        pool.append(provider)

    genres = {str(g).casefold() for g in meta.get('genres', []) if isinstance(g, str)}
    if not genres:
        return []
    genre = next((g for g in meta.get('genres', []) if str(g).casefold() == 'animation'), meta['genres'][0])
    output, seen_ids, calls = [], {identity}, 0
    for provider in pool[:4]:
        for catalog, extras in _catalogs_for(provider, kind):
            required = {str(e.get('name')) for e in catalog.get('extra', []) if isinstance(e, dict) and e.get('isRequired')}
            if 'genre' not in extras or required - {'genre'}:
                continue
            calls += 1
            if calls > 8:
                break
            try:
                payload = fetcher(resource_url(provider['transportUrl'], 'catalog', kind, catalog['id'], {'genre': genre}))
            except Exception:
                continue
            for row in payload.get('metas', []):
                if not isinstance(row, dict) or row.get('type', kind) != kind:
                    continue
                rid = str(row.get('id', ''))
                matching = {str(g).casefold() for g in row.get('genres', []) if isinstance(g, str)} & genres
                if not rid or rid in seen_ids or not matching:
                    continue
                if 'animation' in genres and 'animation' not in matching:
                    continue
                seen_ids.add(rid)
                candidate = normalize(row, kind, rid)
                candidate['recommendation_source'] = 'Matching genres'
                output.append((len(matching), candidate))
    return [row for _, row in sorted(output, key=lambda r: -r[0])[:limit]]


def runtime_seconds(value):
    match = re.search(r'(\d+)\s*min', str(value or ''), re.I)
    return int(match.group(1)) * 60 if match else 0
