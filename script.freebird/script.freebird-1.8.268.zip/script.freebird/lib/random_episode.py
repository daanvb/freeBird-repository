"""Random regular aired episodes; mode travels only with owned playback requests."""
from datetime import datetime, timezone
import random


def choose(videos, current_id=None, previous_id=None, now=None):
    now = now or datetime.now(timezone.utc)
    rows = []
    seen = set()
    for row in videos or []:
        try:
            identity = row.get('id')
            if not identity or identity == current_id or identity in seen:
                continue
            if int(row.get('season')) <= 0 or int(row.get('episode', row.get('number'))) <= 0:
                continue
            released = row.get('released') or row.get('firstAired')
            date = datetime.fromisoformat(str(released).replace('Z', '+00:00'))
            if date.tzinfo is None:
                date = date.replace(tzinfo=timezone.utc)
            if date > now:
                continue
            seen.add(identity)
            rows.append(row)
        except (TypeError, ValueError, AttributeError):
            continue
    preferred = [row for row in rows if row['id'] != previous_id]
    return dict(random.choice(preferred or rows)) if rows else None
