"""Persistent response cache with per-category expiry and an optional size cap.

Cache keys are hashes, never provider URLs. NULL expiry means unlimited lifetime;
max_bytes=None means no payload-size cap; zero disables reads/writes.
"""
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import sqlite3
import time

_STORED = object()
_SCHEMA_VERSION = 3


class DiskCache:
    def __init__(self, directory, max_bytes=64 * 1024 * 1024,
                 category='legacy', ttl=_STORED, legacy_ttl=None):
        Path(directory).mkdir(parents=True, exist_ok=True)
        self.path = str(Path(directory) / 'browse.sqlite')
        self.max_bytes = max_bytes
        self.category = category
        self.ttl = ttl
        self.legacy_ttl = legacy_ttl
        with self.connect() as db:
            # Normal opens skip schema writes; only an actual migration takes a
            # writer lock. Old addon processes can still use the same tables.
            if db.execute('PRAGMA user_version').fetchone()[0] < _SCHEMA_VERSION:
                self._migrate(db)
            self.generation = self._generation(db)

    @staticmethod
    def _migrate(db):
        db.execute('BEGIN IMMEDIATE')
        # Another interpreter may have migrated while this one waited.
        if db.execute('PRAGMA user_version').fetchone()[0] >= _SCHEMA_VERSION:
            return
        db.execute('CREATE TABLE IF NOT EXISTS responses '
                   '(key TEXT PRIMARY KEY, expires REAL, used REAL, value TEXT)')
        columns = {row[1] for row in db.execute('PRAGMA table_info(responses)')}
        if 'created' not in columns:
            db.execute('ALTER TABLE responses ADD COLUMN created REAL')
        if 'category' not in columns:
            db.execute("ALTER TABLE responses ADD COLUMN category TEXT NOT NULL DEFAULT 'legacy'")
        db.execute('CREATE TABLE IF NOT EXISTS cache_epochs (category TEXT PRIMARY KEY, value INTEGER NOT NULL)')
        db.execute('CREATE TABLE IF NOT EXISTS artwork_urls (url TEXT PRIMARY KEY)')
        if 'seen' not in {r[1] for r in db.execute('PRAGMA table_info(artwork_urls)')}:
            db.execute('ALTER TABLE artwork_urls ADD COLUMN seen REAL NOT NULL DEFAULT 0')
            db.execute('UPDATE artwork_urls SET seen=?', (time.time(),))
        db.execute('CREATE INDEX IF NOT EXISTS artwork_seen ON artwork_urls(seen,url)')
        db.execute('CREATE INDEX IF NOT EXISTS artwork_size ON artwork_urls(LENGTH(CAST(url AS BLOB)))')
        # Size checks read integer index entries rather than every JSON payload.
        # SQLite maintains both indexes for writes from older addon processes too.
        db.execute('CREATE INDEX IF NOT EXISTS responses_size ON responses(LENGTH(CAST(value AS BLOB)))')
        db.execute('CREATE INDEX IF NOT EXISTS responses_expiry ON responses(expires)')
        # Exact payload accounting makes warm reads independent of cache size.
        # The shadow sizes also handle INSERT OR REPLACE from older processes,
        # whose connections may not enable recursive delete triggers.
        db.execute('CREATE TABLE IF NOT EXISTS response_sizes (key TEXT PRIMARY KEY, bytes INTEGER NOT NULL)')
        db.execute('CREATE TABLE IF NOT EXISTS response_size_total '
                   '(singleton INTEGER PRIMARY KEY CHECK(singleton=1), bytes INTEGER NOT NULL)')
        db.execute('INSERT OR REPLACE INTO response_sizes SELECT key,COALESCE(LENGTH(CAST(value AS BLOB)),0) FROM responses')
        db.execute('INSERT OR REPLACE INTO response_size_total VALUES '
                   '(1,(SELECT COALESCE(SUM(bytes),0) FROM response_sizes))')
        add_size = (
            'UPDATE response_size_total SET bytes=bytes+COALESCE(LENGTH(CAST(NEW.value AS BLOB)),0)'
            '-COALESCE((SELECT bytes FROM response_sizes WHERE key=NEW.key),0) WHERE singleton=1; '
            'INSERT OR REPLACE INTO response_sizes VALUES(NEW.key,COALESCE(LENGTH(CAST(NEW.value AS BLOB)),0)); ')
        remove_size = (
            'UPDATE response_size_total SET bytes=bytes'
            '-COALESCE((SELECT bytes FROM response_sizes WHERE key=OLD.key),0) WHERE singleton=1; '
            'DELETE FROM response_sizes WHERE key=OLD.key; ')
        db.execute('CREATE TRIGGER IF NOT EXISTS responses_size_insert AFTER INSERT ON responses BEGIN '
                   + add_size + 'END')
        db.execute('CREATE TRIGGER IF NOT EXISTS responses_size_delete AFTER DELETE ON responses BEGIN '
                   + remove_size + 'END')
        db.execute('CREATE TRIGGER IF NOT EXISTS responses_size_update AFTER UPDATE OF key,value ON responses BEGIN '
                   + remove_size + add_size + 'END')
        db.execute('PRAGMA user_version={}'.format(_SCHEMA_VERSION))

    def _generation(self, db):
        return tuple(db.execute('SELECT category,value FROM cache_epochs WHERE category IN (?,?) ORDER BY category',
                                ('*', self.category)).fetchall())

    def current(self):
        with self.connect() as db:
            return self.generation == self._generation(db)

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=2)
        try:
            try:
                db.execute('PRAGMA journal_mode=WAL')
                db.execute('PRAGMA synchronous=NORMAL')
                db.execute('PRAGMA temp_store=MEMORY')
            except sqlite3.Error:
                pass
            with db:
                yield db
        finally:
            db.close()

    def _trim(self, db, now):
        # A clean cache read must not take SQLite's writer lock.
        if db.execute('SELECT 1 FROM responses WHERE expires IS NOT NULL AND expires<=? LIMIT 1', (now,)).fetchone():
            db.execute('DELETE FROM responses WHERE expires IS NOT NULL AND expires<=?', (now,))
        if self.max_bytes is None:
            return
        total = db.execute('SELECT bytes FROM response_size_total WHERE singleton=1').fetchone()[0]
        if total <= self.max_bytes:
            return
        for key, length in db.execute('SELECT key,LENGTH(CAST(value AS BLOB)) FROM responses ORDER BY used,key').fetchall():
            if total <= self.max_bytes:
                break
            db.execute('DELETE FROM responses WHERE key=?', (key,))
            total -= length

    def get(self, url):
        return self.get_many([url]).get(url)

    def get_with_expiry(self, url):
        """Return the response and its absolute deadline for safe memory reuse."""
        return self._get_many([url], with_expiry=True).get(url)

    def get_many(self, urls):
        """Read a page of responses with one SQLite connection and one trim."""
        return self._get_many(urls)

    def _get_many(self, urls, with_expiry=False):
        if self.max_bytes == 0 or self.ttl == 0:
            return {}
        now = time.time()
        result = {}
        with self.connect() as db:
            if self.generation != self._generation(db):
                return {}
            self._trim(db, now)
            for url in dict.fromkeys(urls):
                key = hashlib.sha256(url.encode()).hexdigest()
                row = db.execute('SELECT expires,value,created,category,used FROM responses WHERE key=?', (key,)).fetchone()
                if not row:
                    continue
                expires, raw, created, category, used = row
                stored_policy = (expires, created, category)
                if self.ttl is not _STORED:
                    if created is None:
                        created = expires - self.legacy_ttl if expires is not None and self.legacy_ttl else now
                    expires = None if self.ttl is None else created + self.ttl
                    if expires is not None and expires <= now:
                        db.execute('DELETE FROM responses WHERE key=?', (key,))
                        continue
                    category = self.category if self.category != 'legacy' else category
                    if (expires, created, category) != stored_policy:
                        db.execute('UPDATE responses SET expires=?,created=?,category=? WHERE key=?',
                                   (expires, created, category, key))
                try:
                    value = json.loads(raw)
                    if not isinstance(value, dict):
                        raise ValueError('Invalid cached response')
                except (ValueError, TypeError):
                    db.execute('DELETE FROM responses WHERE key=?', (key,))
                    continue
                # Minute-granularity LRU avoids a write for every poster/cache hit.
                if used is None or now - used >= 60 or now < used:
                    db.execute('UPDATE responses SET used=? WHERE key=?', (now, key))
                result[url] = (value, expires) if with_expiry else value
        return result

    def put(self, url, value, ttl):
        if self.max_bytes == 0:
            return
        key = hashlib.sha256(url.encode()).hexdigest()
        if ttl is not None and ttl <= 0:
            with self.connect() as db:
                db.execute('DELETE FROM responses WHERE key=?', (key,))
            return
        raw = json.dumps(value, separators=(',', ':'), ensure_ascii=False)
        if self.max_bytes is not None and len(raw.encode('utf-8')) > self.max_bytes:
            return
        now = time.time()
        expires = None if ttl is None else now + ttl
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if self.generation != self._generation(db):
                return
            db.execute('INSERT OR REPLACE INTO responses (key,expires,used,value,created,category) VALUES (?,?,?,?,?,?)',
                       (key, expires, now, raw, now, self.category))
            from lib.artwork_cache import record_urls
            record_urls(db, value, now)
            self._trim(db, now)

    def apply_policy(self, lifetimes):
        """Apply new lifetimes to known categories without touching account data."""
        now = time.time()
        with self.connect() as db:
            # Do not resurrect entries which were already expired.
            db.execute('DELETE FROM responses WHERE expires IS NOT NULL AND expires<=?', (now,))
            for category, ttl in lifetimes.items():
                if ttl == 0:
                    db.execute('DELETE FROM responses WHERE category=?', (category,))
                elif ttl is None:
                    db.execute('UPDATE responses SET expires=NULL WHERE category=? AND created IS NOT NULL', (category,))
                else:
                    db.execute('UPDATE responses SET expires=created+? WHERE category=? AND created IS NOT NULL', (ttl, category))
                db.execute('INSERT INTO cache_epochs (category,value) VALUES (?,1) '
                           'ON CONFLICT(category) DO UPDATE SET value=value+1', (category,))
            self._trim(db, now)
            self.generation = self._generation(db)

    def clear(self, category=None):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute('INSERT INTO cache_epochs (category,value) VALUES (?,1) '
                       'ON CONFLICT(category) DO UPDATE SET value=value+1', (category or '*',))
            if category is None:
                db.execute('DELETE FROM responses')
            else:
                db.execute('DELETE FROM responses WHERE category=?', (category,))
            self.generation = self._generation(db)
        # Return free pages to disk when possible; a busy reader may defer VACUUM.
        try:
            db = sqlite3.connect(self.path, timeout=1)
            try:
                db.execute('VACUUM')
            finally:
                db.close()
        except sqlite3.Error:
            pass

    def stats(self):
        with self.connect() as db:
            rows = db.execute('SELECT category,COUNT(*),COALESCE(SUM(LENGTH(CAST(value AS BLOB))),0) '
                              'FROM responses GROUP BY category').fetchall()
        return {'count': sum(row[1] for row in rows), 'bytes': sum(row[2] for row in rows),
                'categories': {row[0]: {'count': row[1], 'bytes': row[2]} for row in rows},
                'database_bytes': Path(self.path).stat().st_size}
