"""Account-scoped Home records. Only title identities and display cards are shared."""
import hashlib
import json
import math
import re
import sqlite3
import time
from contextlib import closing
from pathlib import Path


def clean(data):
    out = {}
    if not isinstance(data, dict):
        return out
    for key, record in data.items():
        if not isinstance(record, dict):
            continue
        stamp = record.get('updated')
        if type(stamp) not in (int, float) or not math.isfinite(stamp) or stamp < 0:
            continue
        if isinstance(key, str) and re.fullmatch(r'removed:(movie|series):[A-Za-z0-9_.:-]{1,200}', key):
            watch = record.get('lastWatched')
            if isinstance(watch, str) and len(watch) <= 64:
                out[key] = {'updated': stamp, 'lastWatched': watch}
        elif key == 'recommendations' and isinstance(record.get('signature'), str):
            cards = []
            items = record.get('items')
            for row in (items if isinstance(items, list) else [])[:10]:
                if not isinstance(row, dict) or row.get('type') not in ('movie', 'series') or not re.fullmatch(r'tt\d+', str(row.get('id') or '')):
                    continue
                card = {name: str(row[name])[:limit] for name, limit in
                        (('id', 64), ('imdb_id', 64), ('moviedb_id', 64), ('type', 10),
                         ('name', 200), ('released', 32), ('year', 4), ('description', 1600))
                        if isinstance(row.get(name), str)}
                # Share only the known public artwork origin, never arbitrary URLs.
                if str(row.get('poster') or '').startswith('https://image.tmdb.org/t/p/'):
                    card['poster'] = str(row['poster'])[:500]
                cards.append(card)
            out[key] = {'updated': stamp, 'signature': record['signature'][:128], 'items': cards}
    return out


def merge(left, right):
    out = clean(left)
    for key, value in clean(right).items():
        old = out.get(key)
        if key.startswith('removed:') and old:
            # Watch watermarks take precedence over clock skew on the removal device.
            from lib.continue_index import _newer_watch
            if _newer_watch(old['lastWatched'], value['lastWatched']):
                continue
            if _newer_watch(value['lastWatched'], old['lastWatched']):
                out[key] = value
                continue
        if old is None or (value['updated'], json.dumps(value, sort_keys=True)) > (old['updated'], json.dumps(old, sort_keys=True)):
            out[key] = value
    return out


class HomeState:
    def __init__(self, profile, token, viewer_id=None):
        from lib.viewer_profiles import directory as viewer_directory
        profile = viewer_directory(profile,viewer_id)
        self.scope = hashlib.sha256(str(token or '').encode()).hexdigest()
        directory = Path(profile) / 'home-state' / self.scope
        directory.mkdir(parents=True, exist_ok=True)
        self.path = directory / 'records.sqlite'
        with closing(self.connect()) as db, db:
            db.execute('CREATE TABLE IF NOT EXISTS records (key TEXT PRIMARY KEY, value TEXT NOT NULL)')

    def connect(self):
        return sqlite3.connect(str(self.path), timeout=5)

    def _snapshot(self, db):
        return clean({key: json.loads(value) for key, value in db.execute('SELECT key,value FROM records')})

    def snapshot(self):
        with closing(self.connect()) as db:
            return self._snapshot(db)

    def merge(self, data):
        with closing(self.connect()) as db, db:
            db.execute('BEGIN IMMEDIATE')
            result = merge(self._snapshot(db), data)
            db.executemany('INSERT OR REPLACE INTO records VALUES (?,?)', [(key, json.dumps(row, sort_keys=True)) for key, row in result.items()])
            return result

    def suppress(self, item):
        key = 'removed:' + str(item.get('type')) + ':' + str(item.get('_id') or item.get('id'))
        self.merge({key: {'updated': time.time(), 'lastWatched': str((item.get('state') or {}).get('lastWatched') or '')}})

    def recommendations(self, signature, items):
        self.merge({'recommendations': {'updated': time.time(), 'signature': signature, 'items': items}})
