"""Invalidate add-on artwork, without deleting Kodi's global texture database."""
import json
import threading
import time
from pathlib import Path
from urllib.parse import unquote

FIELDS = {'poster', 'background', 'landscape', 'landscapePoster', 'logo', 'thumbnail',
          'photo', 'profile', 'fanart', 'thumb', '_original_poster'}
_SEEN = {}
_LOCK = threading.Lock()
LEDGER_DAYS = 90
LEDGER_ROWS = 8192
LEDGER_BYTES = 8 * 1024 * 1024


def record_urls(db, value, now):
    found = urls(value)
    if not found:return
    db.executemany('INSERT OR REPLACE INTO artwork_urls(url,seen) VALUES (?,?)',
                   [(v, now) for v in found if len(v.encode('utf-8')) <= 8192])
    db.execute('DELETE FROM artwork_urls WHERE seen<?', (now-LEDGER_DAYS*86400,))
    db.execute('DELETE FROM artwork_urls WHERE url IN (SELECT url FROM artwork_urls '
               'ORDER BY seen DESC,url LIMIT -1 OFFSET ?)', (LEDGER_ROWS,))
    total = db.execute('SELECT COALESCE(SUM(LENGTH(CAST(url AS BLOB))),0) '
                       'FROM artwork_urls INDEXED BY artwork_size').fetchone()[0]
    if total > LEDGER_BYTES:
        for url, size in db.execute('SELECT url,LENGTH(CAST(url AS BLOB)) FROM artwork_urls ORDER BY seen,url').fetchall():
            if total <= LEDGER_BYTES:break
            db.execute('DELETE FROM artwork_urls WHERE url=?', (url,))
            total -= size


def remember(value):
    """Keep a local URL ledger even when response caching is disabled."""
    found = urls(value)
    if not found:return
    try:
        import xbmcvfs
        from addon_state import get_addon
        from lib.disk_cache import DiskCache
        directory = Path(xbmcvfs.translatePath(get_addon().getAddonInfo('profile'))) / 'cache'
        now = time.time()
        with _LOCK:
            found = {v for v in found if (str(directory),v) not in _SEEN
                     or now-_SEEN[(str(directory),v)] >= 3600}
        if not found:return
        with DiskCache(directory, max_bytes=0).connect() as db:
            record_urls(db, [{'poster':v} for v in found], now)
        with _LOCK:
            if len(_SEEN) + len(found) > 4096:_SEEN.clear()
            _SEEN.update({(str(directory),v):now for v in found})
    except Exception:
        pass  # Optional tracking cannot interrupt browsing.


def urls(value):
    found = set()
    if isinstance(value, dict):
        for key, item in value.items():
            if key in FIELDS and isinstance(item, str) and item.startswith(('https://', 'http://')):
                found.add(item)
            elif isinstance(item, (dict, list)):
                found.update(urls(item))
    elif isinstance(value, list):
        for item in value:
            found.update(urls(item))
    return found


def _raw(url):
    # Kodi can record a resize wrapper instead of the original image URL.
    if url.startswith('image://'):
        return unquote(url[8:].split('/')[0])
    return url


def remove_textures(known, execute):
    def rpc(method, params):
        reply = json.loads(execute(json.dumps({'jsonrpc': '2.0', 'id': 1,
                                              'method': method, 'params': params})))
        if 'error' in reply or 'result' not in reply:
            raise RuntimeError('Kodi artwork cache could not be cleared')
        return reply['result']
    if not known:
        return 0
    textures = rpc('Textures.GetTextures', {'properties': ['url']}).get('textures', [])
    count = 0
    for texture in textures:
        # Exact URLs only: never remove another add-on's unrelated images.
        if _raw(str(texture.get('url') or '')) in known:
            if rpc('Textures.RemoveTexture', {'textureid': texture['textureid']}) != 'OK':
                raise RuntimeError('Kodi artwork cache could not be cleared')
            count += 1
    return count


def clear(cache, profile, execute, category=None):
    """Response clear plus artwork reset for artwork-bearing categories."""
    from account import Store
    from lib.provider_config import refresh_artwork
    from lib import memory_cache
    artwork = category in (None, 'metadata', 'catalog', 'search', 'legacy')
    known = set()
    if artwork:
        with cache.connect() as db:
            known.update(row[0] for row in db.execute('SELECT url FROM artwork_urls'))
            # Include pre-upgrade cache entries that predate the URL ledger.
            for row in db.execute('SELECT value FROM responses'):
                try:known.update(urls(json.loads(row[0])))
                except (ValueError, TypeError):pass
        for folder in ('', 'home-snapshot', 'saved-lists'):
            try:known.update(urls(Store(Path(profile) / folder).load()))
            except Exception:pass
        refresh_artwork(profile)
        Store(Path(profile) / 'home-snapshot').forget()
    cache.clear(category)
    memory_cache.clear()
    if not artwork:
        return 0
    removed = remove_textures(known, execute)
    # Retain the small URL ledger: another live Kodi script may still own an
    # image with the same URL. It must be removable on the next clear too.
    return removed
