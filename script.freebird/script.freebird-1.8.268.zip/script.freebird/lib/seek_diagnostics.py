"""Bounded numeric seek/buffer evidence; no URLs, titles or playback identities."""
import math
import re
import threading
import time
import uuid
from pathlib import Path
from lib.playback_buffer import QUEUE_LABELS, queues as read_queues

KEEP = 4
SAMPLES = 24
INTERVAL = 2.0
_LOCK = threading.RLock()
_OUTCOMES = {'observing', 'buffer-cleared', 'paused', 'unobserved', 'replaced',
             'cancelled', 'stopped', 'playback-error', 'caching-stall',
             'provider-error-video', 'http-unavailable', 'startup-timeout',
             'playback-stopped', 'premature-end', 'unknown'}
_BOOLEANS = ('caching', 'seeking', 'paused', 'resume_pending', 'cache_available')
_LIMITS = {'elapsed_ms': (0, 1800000), 'idle_ms': (0, 1800000),
           'position_delta_ms': (-86400000, 86400000),
           'cache_pct': (0, 100), 'cache_high_water_pct': (0, 100),
           'video_queue_pct': (0, 100), 'audio_queue_pct': (0, 100),
           'video_queue_data_pct': (0, 100), 'audio_queue_data_pct': (0, 100),
           'aml_fps_1': (0, 1000), 'aml_fps_2': (0, 1000),
           'aml_fps_3': (0, 1000), 'aml_drop': (0, 1000000000)}
_LIMITS.update({key.replace('_pct','_high_water_pct'):(0,100) for key in QUEUE_LABELS})
_PROGRESS = set(QUEUE_LABELS) | {'cache_pct'}


def number(value, low, high):
    if type(value) not in (int, float, str):return None
    try:
        result = float(value)
        return round(result, 3) if math.isfinite(result) and low <= result <= high else None
    except (ValueError, OverflowError):return None


def fields(row):
    if not isinstance(row, dict):return {}
    result = {key: row[key] for key in _BOOLEANS if type(row.get(key)) is bool}
    if isinstance(row.get('progress_source'),str) and row['progress_source'] in _PROGRESS:
        result['progress_source']=row['progress_source']
    for key, bounds in _LIMITS.items():
        # Revalidate stored JSON; arbitrary strings never pass into exports.
        if type(row.get(key)) in (int, float):
            value = number(row[key], *bounds)
            if value is not None:result[key] = value
    return result


def clean(rows):
    result = []
    for row in rows[-KEEP:] if isinstance(rows, list) else []:
        if not isinstance(row, dict):continue
        trace = row.get('trace')
        if not isinstance(trace, str) or not re.fullmatch(r'[0-9a-f]{32}', trace):continue
        if row.get('outcome') not in _OUTCOMES:continue
        entry = dict(trace=trace, outcome=row['outcome'])
        for key in ('started_at', 'updated_at'):
            if type(row.get(key)) is int and 0 <= row[key] <= 2100000000:entry[key] = row[key]
        samples = row.get('samples')
        entry['samples'] = [fields(s) for s in samples[-SAMPLES:] if isinstance(s, dict)] if isinstance(samples, list) else []
        entry['decision'] = fields(row.get('decision'))
        result.append(entry)
    return result


def load(profile):
    from account import Store
    try:return clean(Store(Path(profile)/'diagnostic-seek').load().get('episodes'))
    except Exception:return []


class BufferTrace:
    def __init__(self, profile, clock=time.monotonic):
        self.profile = Path(profile)
        self.clock = clock
        self.row = None
        self.last_sample = None
        self.last_position = None

    def _save(self):
        from account import Store
        self.row['updated_at'] = int(time.time())
        with _LOCK:
            rows = [r for r in load(self.profile) if r['trace'] != self.row['trace']]
            Store(self.profile/'diagnostic-seek').save({'episodes': clean(rows+[self.row])})

    def observe(self, pending, kodi, player, caching, cache_level, queue_levels=None):
        def visible(name):
            try:
                value = kodi.getCondVisibility(name)
                return value if type(value) is bool else None
            except Exception:return None
        seeking = visible('Player.Seeking')
        paused = visible('Player.Paused')
        resume = bool(pending.get('resume_target'))
        if paused is True:
            self.finish('paused', pending)
            return
        if not (caching or seeking is True or resume):
            self.finish('buffer-cleared' if seeking is False else 'unobserved', pending)
            return
        now = self.clock()
        if self.row is None:
            self.row = dict(trace=uuid.uuid4().hex, started_at=int(time.time()),
                            outcome='observing', samples=[], decision={})
            self.started = now
            self.last_sample = self.last_position = None
        # Sample only the active owned episode; no healthy-playback label reads
        # or disk writes. finish() saves the exact decision counters separately.
        idle = max(0, now-pending.get('caching_since', now))
        if self.last_sample is not None and now-self.last_sample < INTERVAL:return
        sample = dict(elapsed_ms=min(1800000, int((now-self.started)*1000)),
                      idle_ms=min(1800000, int(idle*1000)), caching=bool(caching),
                      resume_pending=resume)
        for key, value in (('seeking', seeking), ('paused', paused)):
            if value is not None:sample[key] = value
        if not caching:
            try:cache_level = kodi.getInfoLabel('Player.CacheLevel')
            except Exception:cache_level = None
        level = number(cache_level, 0, 100)
        sample['cache_available'] = level is not None
        if level is not None:sample['cache_pct'] = level
        high = number(pending.get('cache_high_water'), 0, 100)
        if high is not None:sample['cache_high_water_pct'] = high
        sample.update(progress_fields(pending))
        def label(name):
            try:return kodi.getInfoLabel('Player.Process('+name+')')
            except Exception:return None
        # Reuse the watchdog's exact queue readings; only query independently
        # during a non-buffering seek. Unknown labels remain omitted.
        values = read_queues(kodi) if queue_levels is None else queue_levels
        sample.update({key:value for key,value in fields(values).items() if key in QUEUE_LABELS})
        raw = label('amlogic.video.fps.info')
        fps = re.fullmatch(r'\s*([0-9]{1,3}(?:\.[0-9]{1,3})?)\s*-\s*([0-9]{1,3}(?:\.[0-9]{1,3})?)\s*-\s*([0-9]{1,3}(?:\.[0-9]{1,3})?)\s*', raw) if isinstance(raw,str) else None
        if fps:
            for index, value in enumerate(fps.groups(),1):sample['aml_fps_'+str(index)] = float(value)
        dropped = number(label('amlogic.video.fps.drop'),0,1000000000)
        if dropped is not None:sample['aml_drop'] = dropped
        try:position = number(player.getTime(), 0, 86400)
        except Exception:position = None
        if position is not None and self.last_position is not None:
            sample['position_delta_ms'] = round((position-self.last_position)*1000)
        self.last_position = position
        self.last_sample = now
        self.row['samples'] = (self.row['samples']+[sample])[-SAMPLES:]
        self._save()

    def finish(self, outcome, pending):
        if self.row is None:return
        self.row['outcome'] = outcome if outcome in _OUTCOMES else 'unknown'
        now = self.clock()
        self.row['decision'] = fields(dict(
            elapsed_ms=min(1800000, max(0, int((now-self.started)*1000))),
            idle_ms=min(1800000, max(0, int((now-pending.get('caching_since', now))*1000))),
            cache_high_water_pct=pending.get('cache_high_water')))
        self.row['decision'].update(progress_fields(pending))
        try:self._save()
        finally:self.row = None


def progress_fields(pending):
    high=pending.get('queue_high_water',{})
    result={key.replace('_pct','_high_water_pct'):value for key,value in high.items()
            if key in QUEUE_LABELS} if isinstance(high,dict) else {}
    result['progress_source']=pending.get('buffer_progress_source')
    return fields(result)


def observe(tracker, profile, attempt, kodi, player, caching, cache_level, queue_levels=None):
    """Optional evidence must never change recovery decisions or raise to Kodi."""
    try:
        if not isinstance(profile, (str, Path)) or not Path(profile).is_absolute():return
        with tracker.lock:
            pending = tracker.pending
            if not pending or pending['attempt'] != attempt:return
            trace = getattr(tracker, '_buffer_trace', None)
            if trace is None:
                trace = tracker._buffer_trace = BufferTrace(profile, tracker.clock)
                # Follow test clocks and any runtime replacement of the clock.
                trace.clock = lambda: tracker.clock()
            trace.observe(pending, kodi, player, caching, cache_level, queue_levels)
    except Exception:pass


def finish(tracker, outcome):
    try:
        trace = getattr(tracker, '_buffer_trace', None)
        if trace is not None:trace.finish(outcome, tracker.pending or {})
    except Exception:pass
