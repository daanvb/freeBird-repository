"""Numeric Kodi queue observations shared by recovery and diagnostics."""
import math

QUEUE_LABELS = {
    'video_queue_pct': ('video.queue.level', 'videoqueuelevel'),
    'audio_queue_pct': ('audio.queue.level', 'audioqueuelevel'),
    'video_queue_data_pct': ('video.queue.data.level', 'videoqueuedatalevel'),
    'audio_queue_data_pct': ('audio.queue.data.level', 'audioqueuedatalevel'),
}


def percentage(value):
    if type(value) not in (str, int, float):return None
    if isinstance(value, str):
        value = value.strip()
        if value.endswith('%'):value = value[:-1]
    try:
        result = float(value)
        return result if math.isfinite(result) and 0 <= result <= 100 else None
    except (ValueError, OverflowError):return None


def queues(kodi):
    result = {}
    for key, names in QUEUE_LABELS.items():
        for name in names:
            try:value = percentage(kodi.getInfoLabel('Player.Process('+name+')'))
            except Exception:value = None
            if value is not None:
                result[key] = value
                break
    return result
