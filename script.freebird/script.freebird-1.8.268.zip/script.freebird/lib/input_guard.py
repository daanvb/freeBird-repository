"""Bounded selection-repeat guards; directional navigation and Back stay immediate."""
import time
import threading
from contextlib import contextmanager

QUIET = 0.25
_STATE_LOCK = threading.RLock()


def ready(window, clock=time.monotonic, quiet=QUIET):
    with _STATE_LOCK:
        deadline = getattr(window, '_input_ready_at', 0)
        window._input_ready_at = max(deadline if type(deadline) in (int, float) else 0,
                                     clock() + quiet)


def note_input(window,clock=None):
    window._last_input_at=(clock or time.monotonic)()


def idle(window,clock=None):
    if type(getattr(window,'_input_owner',None)) is int:return False
    last=getattr(window,'_last_input_at',None)
    return type(last) not in (int,float) or (clock or time.monotonic)()-last>=.65


@contextmanager
def operation(window,clock=None,allow_nested=False):
    """Drain queued activations after slow work without delaying navigation."""
    clock=clock or time.monotonic
    started=clock();owner=threading.get_ident()
    with _STATE_LOCK:
        previous=getattr(window,'_input_owner',None)
        deadline=getattr(window,'_input_ready_at',0)
        nested=previous==owner and allow_nested
        blocked=(getattr(window,'closed',False) is True or getattr(window,'_ui_initializing',False) is True
                 or (type(previous) is int and not nested)
                 # Trusted internal navigation must complete even during the
                 # repeat-draining interval. Busy/closed/init checks still hold.
                 or (not allow_nested and type(deadline) in (int,float) and started<deadline))
        if not blocked and not nested:window._input_owner=owner
    if blocked:
        note_input(window,clock)
        yield False
        return
    if nested:
        yield True  # Only an explicit internal action may bypass the busy guard.
        return
    note_input(window,clock)
    try:
        window.setProperty('input_busy','true')
        yield True
    finally:
        with _STATE_LOCK:
            if clock()-started>=.12:ready(window,clock,quiet=.5)
            window._input_owner=None
        try:window.clearProperty('input_busy')
        except (RuntimeError,AttributeError):pass  # Native window may have retired.


def accept(window, token, clock=time.monotonic):
    now = clock()
    deadline = getattr(window, '_input_ready_at', 0)
    if isinstance(deadline, (int, float)) and now < deadline:
        return False
    previous = getattr(window, '_last_activation', None)
    if isinstance(previous, tuple) and previous[0] == token and now - previous[1] < QUIET:
        return False
    window._last_activation = (token, now)
    return True
