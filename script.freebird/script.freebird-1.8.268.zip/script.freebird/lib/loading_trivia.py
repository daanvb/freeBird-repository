"""Live title facts, fetched off the playback path, with a curated offline fallback."""
from collections import OrderedDict
from functools import lru_cache
import json
from pathlib import Path
import random
import re
import threading
import time
import unicodedata
from lib.stream_presenter import line
from lib.trivia_filter import SPOILER

_previous = OrderedDict()
_lock = threading.Lock()
_expanded = {}


@lru_cache(maxsize=1)
def _load_expanded():
    """Worker-only: publish the larger bundled catalogue after one local read."""
    global _expanded
    try:
        path = Path(__file__).resolve().parents[1] / 'resources/trivia-expanded.json'
        rows = json.loads(path.read_text(encoding='utf-8'))
        if isinstance(rows, dict):
            _expanded = {key: _sourced(value[:22]) for key, value in rows.items()
                         if isinstance(value, list)}
    except (OSError, ValueError):pass
    return _expanded


def _load_live(key):
    """Runs only on the optional worker, including all SQLite and HTTP work."""
    from lib.cache_policy import open_cache, read_policy
    from lib.wiki_trivia import fetch
    policy = read_policy()
    ttl = min(policy['metadata'] or 86400, 7 * 86400)
    cache = open_cache('metadata', policy)
    cache_key = 'title-trivia-v1:' + key
    try:
        stored = cache.get(cache_key) if cache else None
    except Exception:
        stored = None
    if (isinstance(stored, dict) and stored.get('identity') == key and isinstance(stored.get('rows'), list)
            and isinstance(stored.get('expires'), (int, float)) and stored['expires'] > time.time()):
        return stored['rows'], min(ttl, stored['expires'] - time.time())
    rows = fetch(key.split(':', 1)[1])
    ttl = ttl if rows else min(ttl, 6 * 3600)
    if cache:
        try:cache.put(cache_key, {'identity': key, 'rows': rows, 'expires': time.time() + ttl}, ttl)
        except Exception:pass
    return rows, ttl


class LiveTrivia:
    """One daemon worker, coalesced requests, bounded queue and memory cache."""
    def __init__(self, loader=_load_live, clock=time.time):
        self.loader = loader; self.clock = clock; self.lock = threading.Lock()
        self.memory = OrderedDict(); self.jobs = OrderedDict(); self.active = None
        self.worker = None; self.blocked_until = 0

    def cached(self, key):
        with self.lock:
            value = self.memory.get(key)
            if value and value[0] > self.clock():
                self.memory.move_to_end(key)
                return value[1]
        return []

    def request(self, meta, callback=None):
        key = identity(meta)
        if not key:return
        with self.lock:
            if key in self.jobs:
                if callback and len(self.jobs[key]) < 8:self.jobs[key].append(callback)
                return
            # Never accumulate work for every poster passed while browsing.
            if len(self.jobs) >= 4:return
            self.jobs[key] = [callback] if callback else []
            if self.worker is None:
                self.worker = threading.Thread(target=self._run, daemon=True)
                try:self.worker.start()
                except RuntimeError:
                    self.worker = None; self.jobs.pop(key, None)

    def _run(self):
        while True:
            with self.lock:
                if not self.jobs:
                    self.worker = None; self.active = None
                    return
                key = next(iter(self.jobs)); self.active = key
                value = self.memory.get(key)
                early_callbacks = list(self.jobs[key])
            # Deliver bundled enrichment before any network/cache database wait.
            bundled = _load_expanded().get(key, [])
            if bundled and not (value and value[0] > self.clock() and value[1]):
                for callback in early_callbacks:
                    try:callback(bundled)
                    except Exception:pass
            ttl = 600
            try:
                if value and value[0] > self.clock():
                    rows, ttl = value[1], value[0] - self.clock()
                elif self.clock() < self.blocked_until:
                    rows, ttl = [], self.blocked_until - self.clock()
                else:
                    rows, ttl = self.loader(key)
            except Exception as error:
                rows = []
                if getattr(error, 'code', None) in (429, 503):
                    try:retry = int(error.headers.get('Retry-After', '600'))
                    except (AttributeError, ValueError, TypeError):retry = 600
                    self.blocked_until = self.clock() + max(60, min(retry, 3600))
            rows = _sourced(rows)[:10] if isinstance(rows, list) else []
            with self.lock:
                self.memory[key] = (self.clock() + max(1, ttl), rows)
                self.memory.move_to_end(key)
                while len(self.memory) > 128:self.memory.popitem(last=False)
                callbacks = self.jobs.pop(key, [])
            for callback in callbacks:
                try:callback(rows)
                except Exception:pass  # Optional enrichment cannot stop the worker.


live = LiveTrivia()


@lru_cache(maxsize=1)
def catalogue():
    try:
        rows = json.loads((Path(__file__).resolve().parents[1] / 'resources/trivia.json').read_text(encoding='utf-8'))
        return rows if isinstance(rows, dict) else {}
    except (OSError, ValueError):return {}


def identity(meta):
    kind = meta.get('type')
    imdb = str(meta.get('imdb_id') or meta.get('id') or '').split(':')[0]
    if kind not in ('movie', 'series') or not re.fullmatch(r'tt\d+', imdb):return ''
    return kind + ':' + imdb


def _sourced(rows):
    return [row for row in rows if isinstance(row,dict) and isinstance(row.get('text'),str)
            and isinstance(row.get('source'),str) and row['source'].startswith('https://')
            and not row.get('spoiler') and not row.get('is_spoiler')
            and 0 < len(row['text'].strip()) <= 190 and not SPOILER.search(row['text'])]


def _signature(text):
    tokens = re.findall(r'\w+', unicodedata.normalize('NFKC', text).casefold())
    return set(tokens), {token for token in tokens if any(c.isdigit() for c in token)}


_TOPIC_CUES = {
    'P915': re.compile(r'\b(film(?:ed|ing)|shot|locations?)\b', re.I),
    'P144': re.compile(r'\b(based on|adapt(?:ed|ation)|source material)\b', re.I),
    'P166': re.compile(r'\b(awards?|oscars?|emmys?)\b', re.I),
    'P3803': re.compile(r'\b(film(?:ed|ing)?|shot|formats?)\b', re.I),
    'P2061': re.compile(r'\b(aspect|ratios?)\b', re.I),
}


def _topic_duplicate(row, accepted):
    """Catch reworded live facts about the same named location/source/format."""
    if row.get('origin') != 'wikipedia':return False
    words, _ = _signature(row['text'])
    for old in accepted:
        cue = _TOPIC_CUES.get(old.get('topic'))
        if not cue or not cue.search(row['text']):continue
        for term in old.get('terms', [])[:3]:
            target, _ = _signature(term)
            if target and target <= words:return True
    return False


def combined(meta, rows=None):
    """Bounded local merge. Keep the winning record's attribution with its text.

    Curated facts take precedence over close copies from live results. This is
    deliberately lexical: different numbers are not treated as interchangeable.
    No HTTP, cache database access or waiting for the optional worker here.
    """
    key = identity(meta)
    curated = (catalogue().get(key, []) + _expanded.get(key, []))[:22]
    remote = (live.cached(key) if rows is None else rows)[:10]
    result = []; signatures = []
    for row in _sourced(curated + remote):
        if _topic_duplicate(row, result):continue
        text = line(row['text'], 190)
        words, numbers = _signature(text)
        if not words:continue
        if any(numbers == old_numbers and
               len(words & old_words) / len(words | old_words) >= .8
               for old_words, old_numbers in signatures):continue
        result.append(dict(row, text=text)); signatures.append((words, numbers))
    return result


def facts(meta):
    rows=combined(meta)
    if rows:return 'Did you know?',list(dict.fromkeys(line(row['text'],190) for row in rows))
    return 'Did you know?',[]


def choose(meta, rows=None):
    """Avoid consecutive repeats during this app session, with bounded history."""
    records = combined(meta, rows)
    rows = list(dict.fromkeys(line(row['text'], 190) for row in records))
    if not rows:return {}
    label = 'Did you know?'
    labels = {line(row['text'], 190): label + ' · Wikipedia · CC BY-SA 4.0'
              if row.get('origin') == 'wikipedia' else label for row in records}
    key = identity(meta) or (str(meta.get('type')), str(meta.get('id')))
    with _lock:
        previous = _previous.pop(key, '')
        selected = random.choice([row for row in rows if row != previous] or rows)
        _previous[key] = selected
        while len(_previous) > 512:_previous.popitem(last=False)
    choices = [(labels[row], row) for row in rows]
    sources = {line(row['text'], 190): row['source'] for row in records}
    return {'trivia_label': labels[selected], 'trivia': selected, 'trivia_choices': choices,
            'trivia_sources': sources}


def prefetch(meta, callback=None):
    live.request(dict(meta), callback)
