"""Materialize only verified tiny Kodi artwork, never an unverified image URL."""
import hashlib
import os
from pathlib import Path
import struct
import tempfile


def dimensions(data):
    if data.startswith(b'\x89PNG\r\n\x1a\n') and len(data) >= 24:
        return struct.unpack('>II', data[16:24])
    if data.startswith(b'\xff\xd8'):
        offset = 2
        while offset + 4 <= len(data):
            if data[offset] != 255:
                return None
            marker = data[offset + 1]
            if marker == 255:
                offset += 1
                continue
            size = int.from_bytes(data[offset + 2:offset + 4], 'big')
            if size < 2 or offset + 2 + size > len(data):
                return None
            if marker in (0xC0, 0xC1, 0xC2) and size >= 8:
                height, width = struct.unpack('>HH', data[offset + 5:offset + 9])
                return width, height
            offset += 2 + size
    return None


def prepare(texture):
    """Copy the resized bytes to an owned path, bypassing Kodi's GPU URL cache.

    A decoder/cache may return the original image despite transform options.
    Reject that result rather than ever painting sharp artwork over a menu.
    Runtime uses only the standard library and Kodi VFS, including on Android.
    """
    import xbmcvfs
    from addon_state import get_addon
    directory = Path(xbmcvfs.translatePath(get_addon().getAddonInfo('profile'))) / 'verified-frost-v1'
    directory.mkdir(parents=True, exist_ok=True)
    identity = hashlib.sha256(texture.encode()).hexdigest()
    for suffix in ('.png', '.jpg'):
        path = directory / (identity + suffix)
        if path.is_file():
            return str(path)
    stream = xbmcvfs.File(texture)
    try:
        data = bytes(stream.readBytes(65537))
    finally:
        stream.close()
    size = dimensions(data)
    if len(data) > 65536 or not size or not (0 < size[0] <= 32 and 0 < size[1] <= 32):
        return ''
    path = directory / (identity + ('.png' if data.startswith(b'\x89PNG') else '.jpg'))
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=directory, suffix='.tmp', delete=False) as output:
            temporary = output.name
            output.write(data)
        os.replace(temporary, path)
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)
    # Bound this disposable cache independently of Kodi's texture cache.
    for old in sorted((p for p in directory.iterdir() if p.suffix in ('.png', '.jpg')), key=lambda p: p.stat().st_mtime, reverse=True)[32:]:
        try:
            old.unlink()
        except OSError:
            pass
    return str(path)
