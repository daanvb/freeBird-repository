"""One recap at the initial saved-progress handoff, never a later seek."""
from continue_playback import resume_seconds

SECONDS = (0, 3, 5, 10, 15, 20, 30, 60)


def prepare(meta, stream, resume_ms, addon):
    original = int(resume_seconds(resume_ms) * 1000)
    result = {'resume_ms': original}
    if (not original or meta.get('type') not in ('movie', 'series')
            or stream.get('isLive') or stream.get('_live_sports')):
        return result
    try:
        choice = int(addon.getSetting('resume_rewind_seconds'))
        seconds = SECONDS[choice] if 0 <= choice < len(SECONDS) else 0
    except (AttributeError, RuntimeError, TypeError, ValueError):
        seconds = 0
    if seconds:
        # Retain the original solely in this request. The account's saved
        # progress and recovery picker's retry position are not mutated.
        result['_resume_original_ms'] = original
        result['resume_ms'] = max(0, original - seconds * 1000)
    return result


def start_seconds(stream):
    if not isinstance(stream, dict):
        return None
    target = resume_seconds(stream.get('resume_ms'))
    if target or resume_seconds(stream.get('_resume_original_ms')):
        # Explicit zero prevents Kodi reusing a cached native resume point
        # when the recap reaches the beginning of the file.
        return target
    return None
