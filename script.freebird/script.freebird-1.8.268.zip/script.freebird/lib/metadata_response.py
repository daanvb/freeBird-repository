"""Share full provider metadata, scoped to cache policy and artwork revision."""
from copy import deepcopy
from pathlib import Path
import threading
import time

from lib import memory_cache

_lock = threading.Lock()
_flights = {}


def scope(cache):
    from lib.poster_enhancement import ARTWORK_GENERATION
    from lib.provider_config import _load
    config = _load(Path(cache.path).parent.parent)
    return ARTWORK_GENERATION, config.get('artworkRevision', 0)


def fetch(cache, url, ttl, loader, timeout, info=None, refresh=False, context=None):
    context = scope(cache) if context is None else context
    key = 'shared-meta-v1:' + repr(context) + ':' + url
    hot_key = (cache.path, cache.generation, cache.max_bytes, ttl, key)

    def read():
        if not cache.current():return None
        entry = memory_cache.get(hot_key)
        disk_hit = entry is None
        if disk_hit:
            stored = cache.get_with_expiry(key)
            if stored is None:return None
            entry, policy_expires = stored
            expires = entry.get('expires')
            if policy_expires is not None:
                expires = policy_expires if expires is None else min(expires, policy_expires)
            entry = dict(entry, expires=expires)
        expires = entry.get('expires')
        if (expires is not None and expires <= time.time()) or not isinstance(entry.get('response'), dict):
            return None
        if disk_hit:memory_cache.put_until(hot_key, entry, expires)
        return entry

    def deliver(entry, cached):
        if info is not None:info['expires'] = entry['expires']
        return deepcopy(entry['response']), cached

    if not refresh:
        try:
            entry = read()
            if entry is not None:return deliver(entry, True)
        except Exception:
            pass  # Optional storage failures must not prevent a network request.
    with _lock:
        flight = _flights.get(hot_key)
        owner = flight is None
        if owner:
            flight = {'done': threading.Event()}
            _flights[hot_key] = flight
    if not owner:
        if not flight['done'].wait(timeout):raise TimeoutError()
        if 'error' in flight:raise flight['error']
        return deliver(flight['entry'], False)
    try:
        # Another owner may have completed between our first read and this lock.
        if not refresh:
            try:
                entry = read()
            except Exception:
                entry = None
            if entry is not None:
                flight['entry'] = entry
                return deliver(entry, True)
        response = loader()
        expires = None if ttl is None else time.time() + ttl
        entry = {'response': response, 'expires': expires}
        flight['entry'] = entry
        if not response.get('error') and isinstance(response.get('meta'), dict) and response['meta']:
            try:
                if cache.current():
                    cache.put(key, entry, ttl)
                    if cache.current():memory_cache.put_until(hot_key, entry, expires)
            except Exception:
                pass
        return deliver(entry, False)
    except Exception as error:
        flight['error'] = error
        raise
    finally:
        with _lock:
            _flights.pop(hot_key, None)
            flight['done'].set()
