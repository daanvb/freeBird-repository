"""Compact addon-owned popup geometry; text size and navigation stay unchanged."""
import xml.etree.ElementTree as ET

# Old panel left/width and compact width. Timelines, full-screen pages and
# rich people profiles are not popup option menus.
PANELS = {
    'script-stremio-dialog-select.xml': (535, 850, 600),
    'script-stremio-dialog-message.xml': (520, 880, 720),
    'script-stremio-dialog-confirm.xml': (520, 880, 720),
    'script-stremio-dialog-text.xml': (340, 1240, 1040),
    'script-stremio-dialog-progress.xml': (640, 640, 520),
    'script-stremio-dialog-progress-bg.xml': (1256, 600, 480),
    'script-stremio-dialog-toast.xml': (1356, 500, 440),
    'script-stremio-media-actions.xml': (640, 640, 560),
    'script-freebird-player-audio.xml': (520, 880, 680),
}


def apply(tree, filename):
    if filename not in PANELS:return
    old_left, old_width, width = PANELS[filename]
    left = old_left + old_width - width if filename.endswith(('-toast.xml', '-progress-bg.xml')) else (1920-width)//2
    scale = width/old_width

    def adjust(parent, root=False):
        for control in parent.findall('control'):
            x, w = control.find('left'), control.find('width')
            # Keep the full-screen backdrop untouched.
            if root and x is not None and w is not None and x.text == '0' and w.text == '1920':continue
            if x is not None:
                try:x.text = str(round(left+(float(x.text)-old_left)*scale if root else float(x.text)*scale))
                except (ValueError, TypeError):pass
            if w is not None:
                try:
                    if float(w.text)>80:w.text = str(round(float(w.text)*scale))
                except (ValueError, TypeError):pass
            if control.get('type') == 'label':
                scroll=control.find('scroll')
                if scroll is None:scroll=ET.SubElement(control,'scroll')
                scroll.text='true'
            adjust(control)
            for tag in ('itemlayout','focusedlayout'):
                for layout in control.findall(tag):
                    layout.set('width',str(round(float(layout.get('width'))*scale)))
                    adjust(layout)
    adjust(tree.getroot().find('controls'), True)

    if filename == 'script-stremio-media-actions.xml':
        listing = tree.find('.//control[@id="600"]')
        listing.find('left').text = str(left+14)
        listing.find('width').text = str(width-28)
