"""Group account catalogues without changing their provider configuration."""
import re
from concurrent.futures import ThreadPoolExecutor


def item_key(row):
    from lib.catalogue_identity import identity
    return identity(row) or (row.get('type'), row.get('id'))


def clean_label(value):
    value = re.sub(r'(?i)\b(?:aiometadata|aiostreams|elfhosted|trakt|simkl|tmdb|thetvdb|tvdb|imdb|mdblist|cinemeta)\b\s*[-|:]?\s*', '', value)
    value = re.sub(r'(?i)\s*\((?:movies?|shows?|series)\)\s*$', '', value)
    return value.strip(' -|:')


def category(spec):
    # User-visible list names determine categories; opaque provider IDs don't.
    if spec.get('_genre_label'):
        return spec['_genre_label']
    display_label = clean_label(spec['label']) or spec['label']
    text = re.sub(r'[^a-z0-9]+', ' ', display_label.lower())
    if re.search(r'\bapple\s*tv\b', text):
        return display_label
    if franchise(spec) or re.search(r'\b(collection|franchise|universe|saga)\b', text):
        # Chronological, release-order and other curated franchise lists must
        # stay separate. Their title is a list identity, not a chart category.
        brand = franchise(spec)
        if text.strip() in ('all', 'catalog', 'catalogue') and brand:
            return brand + ' Universe'
        if brand and not franchise(dict(spec, kind='', _request_kind='')):
            return brand + ' ' + display_label
        return display_label
    for label, pattern in (
        ('Star Wars', r'\bstar\s*wars\b'), ('Marvel', r'\bmarvel\b'),
        ('DC', r'\bdc\b'), ('Trending', r'\btrending\b'),
        ('Popular', r'\bpopular\b'),
        ('All-time Greats', r'\b(all time|top rated|highest rated|best rated|greatest|top 250)\b'),
        ('New Releases', r'\b(new releases|recently released|latest releases)\b'),
        ('Hidden Gems', r'\bhidden gems\b'), ('Most Watched', r'\bmost watched\b'),
        ('Binge-Worthy', r'\bbinge worthy\b'), ('Quick Watches', r'\bquick watches\b'),
        ('Box Office Hits', r'\bbox office\b'), ('Recommendations', r'\brecommendations?\b'),
        ('Most Anticipated', r'\banticipated\b'), ('Community Favourites', r'\bmost (favorited|favourited|favorites|favourites)\b'),
        ('My Favourites', r'\b(favorites|favourites)\b'), ('Watchlist', r'\bwatchlist\b'),
        ('Watch History', r'\b(history|watched history)\b'), ('Genres', r'\bgenres\b')):
        if re.search(pattern, text):
            return label
    # Preserve custom lists rather than guessing their meaning.
    return display_label


def franchise(spec):
    kind = re.sub(r'[^a-z0-9]+', '', str(spec.get('_request_kind') or spec.get('kind') or '').casefold())
    names = {'marvel': 'Marvel', 'dc': 'DC', 'starwars': 'Star Wars', 'doctorwho': 'Doctor Who'}
    if kind in names:
        return names[kind]
    text = re.sub(r'[^a-z0-9]+', ' ', clean_label(spec['label']).casefold())
    for name, pattern in (('Star Wars', r'\bstar\s*wars\b'), ('Marvel', r'\b(marvel|mcu|x men)\b'),
                          ('DC', r'\b(dc|dcu|dceu|batman|superman)\b'), ('Doctor Who', r'\bdoctor who\b')):
        if re.search(pattern, text):
            return name
    return ''


def collection_name(spec):
    if spec.get('collection'):
        return spec['collection']
    brand = franchise(spec)
    return brand + ' Universe' if brand else category(spec)


def collection_list_label(spec):
    label = clean_label(spec['label'])
    brand = franchise(spec)
    if brand:
        label = re.sub(r'^' + re.escape(brand) + r'\s*(?:Universe\s*)?', '', label, flags=re.I).strip(' -|:')
    label = re.sub(r'(?i)chronologically(?: order)?', 'Chronological Order', label)
    return label or 'All titles'



def genre_label(value):
    text = re.sub(r'[^a-z0-9]+', ' ', str(value).casefold()).strip()
    aliases = {'sci fi': 'Sci-Fi', 'science fiction': 'Sci-Fi', 'reality tv': 'Reality',
               'tv movie': 'TV Movie', 'film noir': 'Film-Noir'}
    if text in aliases:
        return aliases[text]
    names = ('action', 'adventure', 'animation', 'biography', 'children', 'comedy', 'crime',
             'documentary', 'drama', 'family', 'fantasy', 'history', 'holiday', 'horror',
             'kids', 'music', 'musical', 'mystery', 'news', 'reality', 'romance', 'short',
             'soap', 'sport', 'superhero', 'suspense', 'thriller', 'war', 'western',
             'action adventure', 'sci fi fantasy', 'war politics', 'game show', 'talk show')
    return text.title() if text in names else ''


def family(spec):
    if re.search(r'(?i)\bapple\s*tv\b', clean_label(spec['label'])):
        return 'Streaming services'
    if franchise(spec) or re.search(r'(?i)\b(collection|franchise|universe|saga)\b', spec['label']):
        return 'Collections'
    label = category(spec)
    if spec.get('_genre_label') or label == 'Genres' or genre_label(label):
        return 'By genre'
    if label in ('Netflix', 'Netflix Kids', 'HBO Max', 'Disney+', 'Prime Video', 'Apple TV',
                 'BBC iPlayer', 'Channel 4', 'Discovery+', 'ITVX', 'Paramount Plus'):
        return 'Streaming services'
    if label in ('My Favourites', 'Watchlist', 'Watch History', 'Recommendations'):
        return 'My lists'
    if label in ('Popular', 'Trending', 'All-time Greats', 'New Releases', 'Hidden Gems',
                 'Most Watched', 'Binge-Worthy', 'Quick Watches', 'Box Office Hits',
                 'Most Anticipated', 'Community Favourites'):
        return 'Highlights'
    if label in ('Star Wars', 'Marvel', 'DC'):
        return 'Collections'
    return 'Other lists'


def genre_catalogues(specs):
    """Turn advertised genre options into one list choice per genre.

    Original provider values stay in member defaults; only the display label is
    normalised. Generic charts retain their optional filters under Options.
    """
    for spec in specs:
        label = category(spec)
        options = next((e.get('options') or [] for e in spec['extras'] if e['name'] == 'genre'), [])
        if not spec.get('_genre_label') and label == 'Genres' and options:
            for value in options:
                if not isinstance(value, str) or not value.strip() or value.strip().casefold() in ('none', 'all', 'all genres'):
                    continue
                yield dict(spec, _genre_label=genre_label(value) or value.strip(),
                           defaults=dict(spec['defaults'], genre=value),
                           extras=[e for e in spec['extras'] if e['name'] != 'genre'])
        else:
            canonical = genre_label(label)
            yield dict(spec, _genre_label=canonical, extras=[e for e in spec['extras'] if e['name'] != 'genre']) if canonical else spec


SPORTS_LEAGUES = ('Premier League', 'La Liga', 'Serie A', 'Ligue 1')


def sports_league(value):
    text = re.sub(r'[^a-z0-9]+', ' ', str(value).casefold()).strip()
    aliases = {'premier league': 'Premier League', 'english premier league': 'Premier League',
               'epl': 'Premier League', 'la liga': 'La Liga', 'laliga': 'La Liga',
               'serie a': 'Serie A', 'ligue 1': 'Ligue 1'}
    return aliases.get(text, '')


def sports_catalogues(specs):
    """Expose advertised league filters without inventing provider endpoints."""
    for spec in specs:
        yield spec
        if spec.get('kind') not in ('sport', 'sports') and not re.search(r'\bsports?\b', spec.get('addon', ''), re.I):
            continue
        if sports_league(spec.get('label')):
            continue
        for extra in spec.get('extras', []):
            if extra.get('name') not in ('league', 'competition', 'genre'):
                continue
            for value in extra.get('options') or []:
                label = sports_league(value)
                if label:
                    yield dict(spec, label=label, defaults=dict(spec.get('defaults') or {}, **{extra['name']: value}),
                               extras=[e for e in spec['extras'] if e['name'] != extra['name']])


def groups(specs, sports=False):
    buckets = {}
    for spec in genre_catalogues(sports_catalogues(specs) if sports else specs):
        kind = str(spec['kind']).lower()
        is_sport = kind in ('sport', 'sports') or bool(re.search(r'\bsports?\b', spec.get('addon', '').lower()))
        if is_sport != sports:
            continue
        if sports:
            section = 'sport'
        elif kind in ('movie', 'series'):
            section = kind
        elif kind in ('all', 'marvel', 'dc', 'starwars', 'star wars', 'doctorwho', 'doctor who'):
            # Mixed lists must be requested with their original type. Each
            # Discover section then filters the returned movie/series records.
            for section in ('movie', 'series'):
                projected = dict(spec, kind=section, _request_kind=spec['kind'])
                # Feed the projected descriptor through normal grouping below.
                for group in groups([projected]):
                    key = (group['kind'], group['family'], group['label'].casefold())
                    buckets.setdefault(key, dict(group, members=[], extras=[]))['members'].extend(group['members'])
            continue
        else:
            continue
        label = category(spec)
        sports_role = ''
        if not sports and label in ('My Favourites', 'Watchlist', 'Watch History', 'Recommendations'):
            continue
        if sports:
            from lib.sports_epg import catalogue_role
            sports_role = catalogue_role(spec)
            label = sports_league(label) or label
            if sports_role == '24hr':
                label = '24hr Feeds'
        key = (section, family(spec), label.casefold())
        buckets.setdefault(key, {'label': label, 'kind': section, 'id': 'group:' + section + ':' + family(spec) + ':' + label.casefold(),
                                 'members': [], 'defaults': {}, 'extras': [], 'family': family(spec),
                                 '_sports_role': sports_role})['members'].append(spec)
    order = {'Popular': 0, 'Trending': 1, 'All-time Greats': 2, 'New Releases': 3}
    result = list(buckets.values())
    for group in result:
        if group.get('family') == 'Collections':
            group['collection'] = collection_name(group['members'][0])
            group['collection_list'] = collection_list_label(group)
        members = group['members']
        if any(any(e['name'] == 'skip' for e in m['extras']) for m in members):
            group['extras'].append({'name': 'skip'})
        # Only offer genres understood by every merged supplier.
        genres = [next((e.get('options', []) for e in m['extras'] if e['name'] == 'genre'), []) for m in members]
        common = [g for g in genres[0] if all(g in values for values in genres)] if genres else []
        if common:
            group['extras'].append({'name': 'genre', 'options': common})
        if not sports and group.get('family') == 'Streaming services':
            # Service catalogues may advertise filters beyond genre. Expose
            # only choices every supplier understands, preserving raw values.
            for extra in members[0]['extras']:
                name = extra['name']
                if name in ('skip', 'search', 'genre') or not extra.get('options'):
                    continue
                supplied = [next((e.get('options') or [] for e in m['extras'] if e['name'] == name), [])
                            for m in members]
                common = [value for value in supplied[0] if all(value in values for values in supplied)]
                if common:
                    group['extras'].append({'name': name, 'options': common})
    if sports:
        return sorted(result, key=lambda g: (0 if g.get('_sports_role') == 'live-now' else
                                              1 if g.get('_sports_role') == '24hr' else
                                              2 if g['label'].casefold() == 'football' else
                                              3 if g['label'] in SPORTS_LEAGUES else 4,
                                              SPORTS_LEAGUES.index(g['label']) if g['label'] in SPORTS_LEAGUES else 0,
                                              g['label'].casefold()))
    families = {'Highlights': 0, 'Streaming services': 1, 'By genre': 2, 'Collections': 3, 'Other lists': 4}
    return sorted(result, key=lambda g: (0 if g['kind'] == 'series' else 1, families.get(g.get('family'), 5), order.get(g['label'], 10), g['label'].casefold()))


def merge_pages(group, fetch_page, extras=None):
    values = dict(extras or {})
    cursors = values.pop('_source_cursors', {})
    values.pop('skip', None)
    def load(pair):
        index, member = pair
        page_values = dict(member.get('defaults') or {})
        page_values.update(values)
        cursor = cursors.get(str(index), 0)
        pageable = any(e['name'] == 'skip' for e in member['extras'])
        if cursors and not pageable:
            return [], cursor, False
        if cursor:
            page_values['skip'] = str(cursor)
        try:
            request = dict(member, kind=member.get('_request_kind', member['kind']))
            raw = fetch_page(request, page_values)
            rows = [row for row in raw if row.get('type') == group['kind']] if member.get('_request_kind') else raw
            return rows, cursor + len(raw), False
        except Exception:
            return [], cursor, True
    with ThreadPoolExecutor(max_workers=min(4, max(1, len(group['members'])))) as pool:
        pages = list(pool.map(load, enumerate(group['members'])))
    group['_next_cursors'] = {str(i): cursor for i, (_, cursor, _) in enumerate(pages)}
    # Mixed pages may contain only the other media type. Advance by the raw
    # supplier count so the grid can still reach matching items on later pages.
    group['_page_size'] = sum(cursor - cursors.get(str(i), 0) for i, (_, cursor, _) in enumerate(pages))
    if group['kind'] in ('sport', 'sports') and any(failed for _, _, failed in pages):
        # A provider outage is not proof of an empty/exhausted sports list.
        # Keep cursors retryable; callers publish only successfully loaded pages.
        group['_failed_sources'] = sum(failed for _, _, failed in pages)
        if not any(rows for rows, _, _ in pages):
            raise RuntimeError('Sports catalogue providers unavailable')
    else:
        group.pop('_failed_sources', None)
    result = []
    # Interleave supplier rankings so one provider cannot crowd out the rest.
    for index in range(max((len(rows) for rows, _, _ in pages), default=0)):
        for rows, _, _ in pages:
            if index >= len(rows):
                continue
            row = rows[index]
            result.append(row)
    from lib.catalogue_identity import combine
    return combine(result)


OVERVIEW_ROWS = 6


def overview_choices(choices, current):
    matching = [c for c in choices if c['kind'] == current['kind'] and c.get('family') == current.get('family')]
    if current.get('family') == 'Collections':
        matching = [c for c in matching if collection_name(c) == collection_name(current)]
    return matching


def overview_genres(choices, current):
    values = {}
    for catalog in overview_choices(choices, current):
        for extra in catalog.get('extras', []):
            if extra.get('name') == 'genre':
                for value in extra.get('options') or []:
                    if not isinstance(value, str) or value.strip().casefold() in ('', 'all', 'none', 'all genres'):
                        continue
                    label = genre_label(value) or value.strip()
                    values.setdefault(label.casefold(), label)
    return sorted(values.values(), key=str.casefold)


def overview(choices, current, fetch_page, offset=0, extras=None):
    """Bounded overview; a genre includes only catalogues supporting it."""
    matching = overview_choices(choices, current)
    genre = (extras or {}).get('genre')
    def genre_value(spec):
        return next((v for e in spec.get('extras', []) if e.get('name') == 'genre'
                     for v in e.get('options') or [] if isinstance(v, str) and
                     (genre_label(v) or v.strip()).casefold() == str(genre).casefold()), None)
    if genre:
        matching = [c for c in matching if genre_value(c) is not None]
    offset = max(0, int(offset))
    if offset >= len(matching):
        offset = 0
    selected = matching[offset:offset + OVERVIEW_ROWS]
    def load(spec):
        spec = dict(spec)
        if spec.get('collection'):
            spec['label'] = spec.get('collection_list') or spec['label']
        try:
            items = fetch_page(spec, {'genre': genre_value(spec)} if genre else {}) or []
            return dict(spec, items=items, _page_size=len(items), failed=False)
        except Exception:
            return dict(spec, items=[], _page_size=0, failed=True)
    with ThreadPoolExecutor(max_workers=2) as pool:
        sections = list(pool.map(load, selected))
    next_offset = offset + len(selected)
    if next_offset < len(matching):
        sections.append({'label': 'More lists', 'id': 'discover:more', 'kind': current['kind'],
                         'items': [{'id': 'discover:more', 'type': 'collection', 'name': 'More lists',
                                    'description': 'Show the next lists in ' + str(current.get('family') or 'Discover') + '.',
                                    '_discover_more': next_offset}]})
    return sections


def default_catalogue(choices, kind=None):
    """Anticipated is the landing list when supplied, with a stable fallback."""
    matching = [c for c in choices if kind is None or c['kind'] == kind]
    if not matching:
        return None
    # Retain the existing Series-first type order on initial entry.
    target = kind or matching[0]['kind']
    same_type = [c for c in matching if c['kind'] == target]
    return next((c for c in same_type if c.get('label') == 'Most Anticipated'), same_type[0])
