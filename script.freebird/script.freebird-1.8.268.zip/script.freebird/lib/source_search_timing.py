"""Numeric-only timing for one source-search generation; no source data retained."""
import math
import threading
import time
from contextlib import contextmanager

KEYS = ('worker_start_ms', 'worker_done_ms', 'worker_ms', 'cache_ms',
        'queue_ms', 'result_ms', 'render_ms', 'rank_ms', 'items_ms', 'speed_wait_ms', 'total_ms',
        'render_calls', 'cache_lookup_ms', 'item_prepare_ms', 'item_create_ms',
        'native_update_ms', 'items_created', 'items_reused', 'list_resets',
        'list_appends', 'list_unchanged', 'item_construct_ms', 'item_properties_ms',
        'item_property_values', 'item_create_cpu_ms', 'item_create_wait_ms', 'item_cpu_samples')
_lock = threading.RLock()
_current = {}


def sanitize(values):
    return {key: max(0, min(1800000, int(value)))
            for key, value in (values.items() if isinstance(values, dict) else [])
            if key in KEYS and type(value) in (int, float) and (type(value) is int or math.isfinite(value))}


class SearchTiming:
    def __init__(self, profile):
        self.profile = str(profile)
        self.started = time.monotonic()
        self.values = {}
        self.queued = {}
        self.done = False
        self.lock = threading.RLock()
        with _lock:
            _current[self.profile] = self

    def add(self, key, milliseconds):
        with self.lock:
            if not self.done and key in KEYS:
                self.values[key] = self.values.get(key, 0) + milliseconds

    def mark(self, key):
        self.add(key, (time.monotonic() - self.started) * 1000)

    @contextmanager
    def measure(self, key):
        started = time.monotonic()
        try:
            yield
        finally:
            self.add(key, (time.monotonic() - started) * 1000)

    def enqueue(self, kind):
        with self.lock:
            self.queued[kind] = time.monotonic()

    def dequeue(self, kinds):
        now = time.monotonic()
        with self.lock:
            stamps = [self.queued.pop(kind) for kind in kinds if kind in self.queued]
            if stamps:
                # One pump batch, not once for each coalesced event.
                self.add('queue_ms', (now - min(stamps)) * 1000)

    def finish(self):
        with self.lock:
            if self.done:return
            self.mark('total_ms')
            self.done = True
            values = sanitize(self.values)
        def save():
            try:
                with _lock:
                    if _current.get(self.profile) is not self:return
                    from lib.perf_report import record_stream_search
                    record_stream_search(self.profile, values)
            except Exception:
                pass  # Optional diagnostics never interrupt search or playback.
        try:
            threading.Thread(target=save, daemon=True).start()
        except RuntimeError:
            pass
