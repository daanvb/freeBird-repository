"""File-specific chapter discovery, off startup/input threads and shared with menus."""
import hashlib
import json
import math
import re
import threading
import time
from pathlib import Path
from functools import lru_cache

PROPERTY = 'strem4kodi.player.file_chapters'
EPOCH = 'strem4kodi.player.file_chapters_epoch'


def digest(file):return hashlib.sha256(file.encode()).hexdigest()


def rows_for(entry, file, duration, epoch=''):
    return _rows_for(entry,digest(file),duration,epoch)


def _rows_for(entry, key, duration, epoch):
    try:
        if (not isinstance(entry,dict) or entry.get('file')!=key or entry.get('epoch','')!=epoch
                or not math.isfinite(duration) or duration<=0
                or not math.isfinite(float(entry['duration']))
                or abs(float(entry['duration'])-duration)>max(1,duration*.001)
                or not isinstance(entry.get('rows'),list) or len(entry['rows'])>300):
            return []
        from lib.player_chapter_timeline import valid
        return valid([{'time':row['start'],'name':row['name']} for row in entry['rows']],duration)
    except (TypeError,ValueError,KeyError,AttributeError):return []


@lru_cache(maxsize=4)
def _decode(raw, key, duration, epoch):
    return _rows_for(json.loads(raw or '{}'),key,duration,epoch)


def cached(file, duration, window=None):
    if not isinstance(file,str) or not file:return []
    try:
        if window is None:
            import xbmcgui
            window=xbmcgui.Window(10000)
        return _decode(window.getProperty(PROPERTY),digest(file),duration,window.getProperty(EPOCH))
    except (ImportError,AttributeError,RuntimeError,TypeError,ValueError):return []


def enrich(rows, file, duration, window=None):
    names=cached(file,duration,window)
    if not names:return rows
    if not rows:return names
    # The exact file owns the table. Also cross-check Kodi's markers so a
    # complex/alternate edition cannot acquire a different edition's names.
    if len(rows)!=len(names) or any(abs(a['start']-b['start'])>max(1.5,duration*.0001)
                                  for a,b in zip(rows,names)):return rows
    return [dict(row,name=named['name'] if not re.fullmatch(r'Chapter \d+',named['name']) else row['name'])
            for row,named in zip(rows,names)]


def clear(profile, window=None):
    import uuid
    if window is None:
        import xbmcgui
        window=xbmcgui.Window(10000)
    window.setProperty(EPOCH,uuid.uuid4().hex)
    window.clearProperty(PROPERTY)
    from account import Store
    store=Store(Path(profile)/'file-chapters')
    existed=store.path.exists()
    store.save({})
    return int(existed)


class Watcher:
    def __init__(self, profile, player, kodi, window, rpc, clock=time.monotonic,
                 wall=time.time, extract=None, thread_factory=threading.Thread):
        from core.file_chapters import extract as read_file
        self.profile,self.player,self.kodi,self.window,self.rpc=profile,player,kodi,window,rpc
        self.clock,self.wall,self.extract=clock,wall,extract or read_file
        self.thread_factory=thread_factory
        self.identity=None;self.requested=None;self.since=0
        self.worker=None;self.cancel=threading.Event();self.pending=None
        self.lock=threading.Lock()
        self.epoch=window.getProperty(EPOCH)

    def close(self):
        self.cancel.set()
        self.identity=self.requested=None
        with self.lock:self.pending=None
        self.window.clearProperty(PROPERTY)

    def owns(self, identity, cancel, epoch):
        try:
            return (not cancel.is_set() and self.identity==identity and self.window.getProperty(EPOCH)==epoch
                    and self.player.isPlayingVideo() and self.player.getPlayingFile()==identity[0]
                    and getattr(self.player,'_track_session',None)==identity[1])
        except Exception:return False

    def tick(self):
        epoch=self.window.getProperty(EPOCH)
        if epoch!=self.epoch:
            self.close();self.epoch=epoch
        file=getattr(self.player,'_playing_file',None)
        context=getattr(self.player,'_context',None)
        if (not isinstance(file,str) or not file or not isinstance(context,dict)
                or context.get('kind') not in ('movie','series') or context.get('live_sports')
                or isinstance(getattr(self.player,'_live_file',None),str) and self.player._live_file
                or not self.player.isPlayingVideo() or self.player.getPlayingFile()!=file):
            self.close();return
        identity=(file,getattr(self.player,'_track_session',None))
        if identity!=self.identity:
            self.close();self.identity=identity;self.since=self.clock()
        with self.lock:
            pending=self.pending;self.pending=None
        if pending and pending[0]==identity:
            self.window.setProperty(PROPERTY,json.dumps(pending[1],ensure_ascii=True))
        if self.requested==identity or self.clock()-self.since<5:return
        if self.worker is not None and self.worker.is_alive():return
        if (getattr(self.player,'_resume_target_ms',0) or getattr(self.player,'_resume_rewind_pending',False) or
                self.kodi.getCondVisibility('Player.Caching | Player.Paused | Player.Seeking')):return
        # No file connection for streams without embedded chapters, live TV,
        # pre-rolls or sources still opening. This is one optional job/session.
        try:
            count=int(self.kodi.getInfoLabel('Player.ChapterCount') or 0)
            duration=float(self.player.getTotalTime())
            if not 1<=count<=300 or not math.isfinite(duration) or duration<=0:return
        except (TypeError,ValueError,RuntimeError):return
        self.requested=identity;self.cancel=threading.Event()
        try:
            self.worker=self.thread_factory(target=self.read,args=(identity,duration,self.cancel,epoch),daemon=True)
            self.worker.start()
        except RuntimeError:
            self.cancel.set()
            self.worker=None
            self.requested=None
            raise

    def read(self, identity, duration, cancel, epoch):
        from account import Store
        file=identity[0];key=digest(file)
        alive=lambda:self.owns(identity,cancel,epoch)
        try:
            store=Store(Path(self.profile)/'file-chapters')
            entries={}
            try:
                saved=store.load().get('entries') or {}
                for saved_key,value in list(saved.items())[:256]:
                    try:
                        if isinstance(saved_key,str) and len(saved_key)==64 and isinstance(value,dict) and math.isfinite(float(value.get('checked'))):
                            entries[saved_key]=value
                    except (TypeError,ValueError):pass
            except Exception:pass
            entry=entries.get(key)
            if isinstance(entry,dict):
                try:
                    ttl=86400 if entry.get('rows') else 300
                    age=self.wall()-float(entry.get('checked') or 0)
                    fresh=(0<=age<ttl and entry.get('epoch','')==epoch
                           and abs(float(entry.get('duration') or 0)-duration)<=max(1,duration*.001))
                    if fresh and (not entry.get('rows') or rows_for(entry,file,duration,epoch)):
                        if alive():
                            with self.lock:self.pending=(identity,entry)
                        return
                except (TypeError,ValueError):pass
            if not alive():return
            from lib.player_chapter_timeline import valid
            # Prefer a supported full native API, but do not probe the file
            # merely to discover that a newer Kodi already provides the names.
            try:rows=valid(self.rpc('Player.GetChapters',{'playerid':1}).get('chapters'),duration)
            except Exception:rows=[]
            if not rows and alive():rows=valid(self.extract(file,duration,alive=alive),duration)
            if not alive():return
            entry={'file':key,'duration':duration,'checked':self.wall(),'epoch':epoch,'rows':rows}
            entries[key]=entry
            entries=dict(sorted(entries.items(),key=lambda pair:float(pair[1].get('checked') or 0),reverse=True)[:48])
            try:store.save({'entries':entries})
            except Exception:pass  # An unavailable disk cache must not hide a valid table.
            if alive():
                with self.lock:self.pending=(identity,entry)
        except Exception:
            pass  # Signed media addresses and native exception text never enter logs.
