"""Keep optional Home refreshes behind first paint and within one worker budget."""
from functools import wraps
import threading
import time

_slot = threading.BoundedSemaphore(1)
PROPERTY = 'strem4kodi.browse.starting'


def request_scope(profile):
    """Reject late account/provider/viewer results without exporting identity."""
    import hashlib
    from account import Store
    from lib.provider_config import state
    from lib.viewer_profiles import current, _configuration
    try:account = _configuration(profile)
    except OSError:account = Store(profile).load()
    config = state(profile, account)
    values = (current(profile), config.get('token'), config.get('addons'),
              config.get('disabledAddons'), config.get('providerPreferences'),
              config.get('artworkRevision'))
    return hashlib.sha256(repr(values).encode()).hexdigest()


def starting(session):
    try:session.setProperty(PROPERTY, str(time.time() + 10))
    except RuntimeError:pass


def ready(session):
    try:session.clearProperty(PROPERTY)
    except RuntimeError:pass


def pending(session):
    try:return 0 < float(session.getProperty(PROPERTY) or 0) - time.time() <= 10
    except (TypeError, ValueError, RuntimeError):return False


def budgeted(work):
    @wraps(work)
    def run():
        with _slot:
            return work()
    return run
