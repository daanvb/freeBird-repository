"""Shared conservative spoiler screening without importing network providers."""
import re

SPOILER = re.compile(r'\b(spoilers?|endings?|dies|killed|deaths?|final scenes?|finale|climax|'
                     r'twists?|reveal(?:ed|s)?|murderer|turns? out|secret identity|'
                     r'betray(?:s|ed|al)?|survives?|resurrect\w*)\b', re.I)
