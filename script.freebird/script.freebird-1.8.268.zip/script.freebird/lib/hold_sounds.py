"""Suppress edge-hold repeat clicks briefly; never change saved sound settings."""
import threading
import time


class QuietHold:
    def __init__(self,toggle,clock=time.monotonic,thread_factory=threading.Thread):
        self.toggle=toggle;self.clock=clock;self.thread_factory=thread_factory
        self.lock=threading.RLock();self.wake=threading.Event()
        self.deadline=0;self.active=False;self.token=None

    def touch(self):
        with self.lock:
            self.deadline=self.clock()+.85
            if self.active:
                self.wake.set()
                return
            self.active=True;token=self.token=object()
            try:
                self.toggle(False)
                self.thread_factory(target=self.watch,args=(token,),daemon=True).start()
            except (RuntimeError,AttributeError):self.release()

    def watch(self,token):
        while True:
            with self.lock:
                if token is not self.token:return
                remaining=self.deadline-self.clock()
                if remaining<=0:
                    self.release()
                    return
                self.wake.clear()
            self.wake.wait(remaining)

    def release(self):
        with self.lock:
            if not self.active:return
            self.active=False;self.token=None;self.wake.set()
            try:self.toggle(True)
            except (RuntimeError,AttributeError):pass


def touch(window,kodi):
    guard=getattr(window,'_hold_sounds',None)
    if not isinstance(guard,QuietHold):
        toggle=getattr(kodi,'enableNavSounds',None)
        if not callable(toggle):return
        guard=window._hold_sounds=QuietHold(toggle)
    guard.touch()


def release(window):
    guard=getattr(window,'_hold_sounds',None)
    if isinstance(guard,QuietHold):guard.release()
