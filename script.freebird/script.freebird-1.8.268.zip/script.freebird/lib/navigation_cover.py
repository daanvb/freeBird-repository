"""Keep the native Kodi launcher covered while retiring a full browse window."""


class Cover:
    def __init__(self):
        self.window=None
        self.closed=False
        self.visible=False
        self.cancelled=False
        self.on_ready=None

    def show(self,title,on_ready,factory=None):
        self.on_ready=on_ready
        try:
            self.window=(factory or make_window)(self,title)
            self.window.show()
        except Exception:
            self.on_ready=None
            self.finish()
            raise

    def ready(self):
        if self.closed:return
        self.visible=True
        callback,self.on_ready=self.on_ready,None
        # Release the bound Home reference before the shell destroys its native
        # window. Retaining it would defeat the sole-full-window handoff.
        if callback:
            try:callback()
            except Exception:
                self.finish()
                raise

    def finish(self):
        if self.closed:return
        self.closed=True
        self.on_ready=None
        if self.window is not None:
            try:self.window.close()
            except RuntimeError:pass
            path=getattr(self.window,'_theme_layout_path',None)
            if path:
                try:path.unlink()
                except OSError:pass


def make_window(owner,title):
    # WindowXMLDialog is ALWAYS modal in Kodi, even when opened with show().
    # It prevents WindowXML activation and onInit never gets a chance to remove
    # it. Use Kodi's genuinely modeless carrier, with our own local controls.
    from lib.ui_dialogs import TransitionSurface
    return TransitionSurface(owner,title)


def startup():
    """Optional decoration must never prevent a launch if a skin rejects it."""
    cover=Cover()
    try:cover.show('Loading Home…',None)
    except Exception:
        import xbmc
        xbmc.log('Strem4Kodi: startup cover unavailable',xbmc.LOGWARNING)
    return cover
