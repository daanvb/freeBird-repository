"""Dispatch an ordinary video-addon launch without importing provider code."""


def launch_root(argv):
    if len(argv)<3:return False
    from urllib.parse import parse_qsl
    if dict(parse_qsl(argv[2].lstrip('?'))).get('action'):return False
    import xbmc
    import xbmcplugin
    xbmcplugin.endOfDirectory(int(argv[1]),cacheToDisc=False)
    xbmc.executebuiltin('RunScript(script.freebird)')
    return True
