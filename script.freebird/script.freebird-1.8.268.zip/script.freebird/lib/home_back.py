"""Confirm a return to Home from a browsing page."""
import time


def confirmed(window, page, gui):
    now = time.monotonic()
    previous = window.__dict__.get('_home_back_press')
    if previous and previous[0] == page and now - previous[1] <= 3:
        window._home_back_press = None
        return True
    window._home_back_press = (page, now)
    gui.Dialog().notification('freeBird', 'Press Back again to return to Home',
                              time=3000, sound=False)
    return False
