"""Vertical-only Discover grid with the same artwork size as Home."""
import xml.etree.ElementTree as ET
from lib.cinematic_cards import posters, POSTER_CELL_WIDTH
from lib.discover_service_filters import PILL_LEFT, PILL_MAX_WIDTH

ROW_IDS = (9500,)
GRID_COLUMNS = 7


def split(items, capacity=1):
    return [items] if items else []


def build(tree):
    controls = tree.getroot().find('controls')
    visible = 'String.IsEqual(Window.Property(page),Discover) + !String.IsEmpty(Window.Property(discover_service_filter))'
    button = ET.SubElement(controls, 'control', type='button', id='9204')
    for tag, value in dict(left=str(PILL_LEFT), top='595', width=str(PILL_MAX_WIDTH), height='60', font='font10',
                           label='$INFO[Window.Property(discover_service_filter)]',
                           textcolor='FFE5E5E7', focusedcolor='FF15161D', textoffsetx='20',
                           align='left', visible=visible, onleft='9202', onright='9204',
                           onup='9204', ondown='9500').items():
        ET.SubElement(button, tag).text = value
    for tag, color in (('texturefocus', 'FFF0F0F2'), ('texturenofocus', 'FF30313B')):
        ET.SubElement(button, tag, border='30,0,30,0', colordiffuse=color).text = (
            'special://home/addons/script.freebird/resources/skins/Main/media/controls/local-pill-h60-v1.png')
    rows = tree.find('.//control[@id="2000"]')
    ET.SubElement(rows, 'visible').text = '!String.IsEqual(Window.Property(discover_grid),true)'
    listing = ET.SubElement(controls, 'control', type='panel', id='9500')
    for tag, value in {'left':38, 'top':660, 'width':GRID_COLUMNS * POSTER_CELL_WIDTH, 'height':420,
                       'orientation':'vertical', 'scrolltime':180, 'pagecontrol':9564,
                       'onleft':'SetFocus(9500)', 'onright':'SetFocus(9500)', 'ondown':'SetFocus(9500)',
                       'visible':'String.IsEqual(Window.Property(discover_grid),true)'}.items():
        ET.SubElement(listing, tag).text = str(value)
    # Numeric self navigation asks Kodi to wrap at the panel edge. Builtin
    # edge holds leave movement and scrolling inside the native container.
    ET.SubElement(listing, 'onup', condition='String.IsEqual(Window.Property(search_grid),true)').text = 'SetFocus(9500)'
    ET.SubElement(listing, 'onup', condition='!String.IsEqual(Window.Property(search_grid),true) + String.IsEmpty(Window.Property(discover_service_filter))').text = 'SetFocus(9200)'
    ET.SubElement(listing, 'onup', condition=visible).text = 'SetFocus(9204)'
    for tag in ('itemlayout', 'focusedlayout'):
        ET.SubElement(listing, tag, width='220', height='333')
    posters(listing)
    import copy
    # Search uses the same vertical panel, with room for title captions.
    # Its collections/catalogues precede movies and series in the item order.
    for tag in ('itemlayout', 'focusedlayout'):
        search_layout = copy.deepcopy(listing.find(tag))
        search_layout.set('height', '420')
        search_layout.set('condition', 'String.IsEqual(Window.Property(search_grid),true) + !String.IsEqual(Window.Property(filmography_grid),true)')
        listing.find(tag).set('condition', '!String.IsEqual(Window.Property(search_grid),true)')
        listing.append(search_layout)
    for layout in listing.findall('itemlayout') + listing.findall('focusedlayout'):
        search = layout.get('condition', '').startswith('String.IsEqual(Window.Property(search_grid),true)')
        for node in list(layout):
            if not search and node.get('type') == 'label' and float(node.findtext('top', '0')) >= 320:
                layout.remove(node)

    # Filmographies reserve a caption/rating band above the TV's bottom edge.
    from lib.recommendation_cards import append_layout
    for tag in ('itemlayout', 'focusedlayout'):
        layout = copy.deepcopy(listing.findall(tag)[-1])
        layout.set('condition', 'String.IsEqual(Window.Property(filmography_grid),true)')
        for node in list(layout):
            if node.get('type') == 'label' and float(node.findtext('top', '0')) >= 320:
                layout.remove(node)
        for node in layout.iter('control'):
            for prop in ('left', 'top', 'width', 'height'):
                value = node.find(prop)
                if value is not None:
                    origin = 12 if prop in ('left', 'top') else 0
                    value.text = str(round(origin + (float(value.text)-origin) * 200/224))
        from lib.cinematic_cards import control
        control(layout, 'label', left=12, top=324, width=200, height=24,
                label='$INFO[ListItem.Label]', font='Strem4Kodi21',
                textcolor='FFFFFFFF', align='center', scroll='true' if tag == 'focusedlayout' else 'false')
        append_layout(layout, 358)
        listing.append(layout)

    scrollbar=ET.SubElement(controls,'control',type='scrollbar',id='9564')
    for tag,value in {'left':1823,'top':660,'width':6,'height':400,
                      'orientation':'vertical','showonepage':'false','onleft':9500,
                      'onright':9500,'onup':9500,'ondown':9500,
                      'visible':'String.IsEqual(Window.Property(discover_grid),true)'}.items():
        ET.SubElement(scrollbar,tag).text=str(value)
    for tag,color in [('texturesliderbackground','FF303238'),('texturesliderbar','FFBDBDBD'),('texturesliderbarfocus','FFFFFFFF')]:
        ET.SubElement(scrollbar,tag,colordiffuse=color).text='special://home/addons/script.freebird/resources/branding/white.png'
