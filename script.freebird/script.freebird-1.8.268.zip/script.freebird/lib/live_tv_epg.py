"""Public programme metadata, separate from broadcaster playback and accounts."""
from datetime import datetime, timedelta, timezone
import threading
import time

from lib.live_tv_http import json_request
from lib.title_text import plain

ENDPOINT = 'https://awk.epgsky.com/hawk/linear/schedule/'
# London/national schedules. Regional news may differ from the live feed.
SERVICES = dict(zip((
    'bbc_one_hd', 'bbc_two_hd', 'bbc_three_hd', 'bbc_four_hd', 'cbbc_hd',
    'cbeebies_hd', 'bbc_news24', 'bbc_scotland', 'itv1', 'itv2', 'itv3',
    'itv4', 'itv_quiz', 'c4', 'e4', 'more4', 'film4', '4seven', 'c5',
    '5star', '5usa', '5action', '5select'), (
    '3000', '2075', '2080', '2086', '2077', '2090', '2085', '1138',
    '6502', '6532', '6533', '6534', '3026', '4075', '4076', '4043',
    '4044', '3150', '4058', '3023', '3022', '1036', '3028')))
SPAN = 10800
STEP = 1800
_cache = {}
_lock = threading.Lock()


def parse(payload, allowed):
    result = {sid: [] for sid in allowed}
    if not isinstance(payload, dict) or not isinstance(payload.get('schedule'), list):
        return result
    for channel in payload['schedule'][:100]:
        if not isinstance(channel, dict):
            continue
        sid = str(channel.get('sid'))
        if sid not in result or not isinstance(channel.get('events'), list):
            continue
        for event in channel['events'][:1000]:
            if not isinstance(event, dict):
                continue
            start, duration = event.get('st'), event.get('d')
            title = plain(event.get('t'))[:200]
            if (type(start) not in (int, float) or type(duration) not in (int, float)
                    or not 0 < start < 4102444800 or not 0 < duration <= 86400 or not title):
                continue
            result[sid].append(dict(start=start, end=start + duration, title=title,
                                    description=plain(event.get('sy'))[:3000]))
    return result


def load(now=None, fetch=json_request, cancelled=None, channels=None):
    """Include overnight listings; failures never hide a channel."""
    now = time.time() if now is None else now
    cancelled = cancelled or (lambda: False)
    today = datetime.fromtimestamp(now, timezone.utc).date()
    services = SERVICES if channels is None else {c: SERVICES[c] for c in channels if c in SERVICES}
    ids = list(services.values())
    merged = {sid: [] for sid in ids}
    for day in (today - timedelta(days=1), today, today + timedelta(days=1)):
        for offset in range(0, len(ids), 20):
            if cancelled():
                return None
            batch = ids[offset:offset + 20]
            key = day.strftime('%Y%m%d') + '/' + ','.join(batch)
            with _lock:
                cached = _cache.get(key)
            data = cached[1] if cached else {}
            if not cached or now - cached[0] >= 900:
                try:
                    fresh = parse(fetch(ENDPOINT + key, headers={'X-SkyOTT-Territory': 'GB'}), batch)
                    if any(fresh.values()):
                        data = fresh
                        with _lock:
                            # Small process cache; no accounts, URLs or device diagnostics.
                            if len(_cache) >= 8:
                                _cache.pop(next(iter(_cache)))
                            _cache[key] = (now, data)
                except Exception:
                    pass
            for sid in batch:
                merged[sid].extend(data.get(sid, []))
    return {channel: sorted({(p['start'], p['end']): p for p in merged[sid]}.values(),
                            key=lambda p: p['start']) for channel, sid in services.items()}


def cells(programmes, start, span=SPAN):
    """Clip overlaps and fill gaps so every visible channel is selectable."""
    end, cursor, result = start + span, start, []
    for item in sorted(programmes, key=lambda p: p['start']):
        left, right = max(cursor, item['start']), min(end, item['end'])
        if right <= left:
            continue
        if left > cursor:
            result.append(dict(start=cursor, end=left, title='Schedule unavailable', description='', gap=True))
        result.append(dict(item, start=left, end=right, original_start=item['start'], original_end=item['end']))
        cursor = right
    if cursor < end:
        result.append(dict(start=cursor, end=end, title='Schedule unavailable', description='', gap=True))
    return result
