"""Private GitHub transport and credits sync. Never upload credentials."""
import base64
import json
import math
import re
import threading
import time
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.error import HTTPError
from account import Store
from pathlib import Path

REPO = 'daanvb/freeBird-sync'
BASE = 'https://api.github.com/repos/' + REPO
FILE = '/contents/credits.json'
LIMIT = 512 * 1024


class SyncError(Exception):
    def __init__(self,message,code='unknown'):
        super().__init__(message)
        self.code=code


def stamp(row):
    v=row.get('updated',0)
    return v if isinstance(v,(int,float)) and math.isfinite(v) and v>=0 else 0


def clean(data):
    from lib.smart_credits import series_key,CHOICES
    if not isinstance(data,dict):return {}
    out={}
    for key,row in data.items():
        if series_key(key)!=key or not isinstance(row,dict):continue
        samples={}
        source=row.get('samples',{})
        if isinstance(source,dict):
            for episode,v in source.items():
                if series_key(episode)!=key or not isinstance(v,dict):continue
                if v.get('deleted') is True:
                    samples[episode] = {'deleted':True, 'updated':stamp(v)}
                    continue
                duration,lead=v.get('duration'),v.get('lead')
                if not all(isinstance(x,(int,float)) and math.isfinite(x) for x in (duration,lead)):continue
                if duration<=120 or not 20<=lead<=min(600,duration*.35):continue
                samples[episode]={'duration':round(duration),'lead':round(lead),'updated':stamp(v)}
                if v.get('manual') is True:
                    samples[episode]['manual'] = True
                    if v.get('ignore_introdb') is True:
                        samples[episode]['ignore_introdb'] = True
        override=row.get('override')
        if override not in CHOICES:override=None
        out[key]={'override':override,'updated':stamp(row),'samples':samples}
    return out


def newer(a,b):
    # Deterministic ties converge even for legacy entries without timestamps.
    return max((a,b),key=lambda v:(stamp(v),json.dumps(v,sort_keys=True)))


def trim_samples(samples):
    # Keep deletion records so an older/offline device cannot restore bad data.
    deleted = {k:v for k,v in samples.items() if v.get('deleted') is True}
    live = {k:v for k,v in samples.items() if v.get('deleted') is not True}
    return dict(deleted, **dict(sorted(live.items(), key=lambda pair:(stamp(pair[1]),pair[0]))[-24:]))


def merge(a,b):
    a,b=clean(a),clean(b);out={}
    for key in sorted(a.keys()|b.keys()):
        left,right=a.get(key,{}),b.get(key,{})
        # Samples must not influence the ordering of override tombstones.
        pick=newer({k:left.get(k) for k in ('override','updated')},
                   {k:right.get(k) for k in ('override','updated')}) if left and right else (left or right)
        samples=dict(left.get('samples',{}))
        for ep,v in right.get('samples',{}).items():samples[ep]=newer(samples[ep],v) if ep in samples else v
        samples=trim_samples(samples)
        out[key]={'override':pick['override'],'updated':stamp(pick),'samples':samples}
    # Same deterministic bound everywhere, retaining the newest series.
    return dict(sorted(out.items(),key=lambda pair:(max([stamp(pair[1])]+[stamp(v) for v in pair[1]['samples'].values()]),pair[0]))[-200:])


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):raise SyncError('Repository redirected; sync stopped','redirect')


def request(token,path='',payload=None):
    playback_path = bool(re.fullmatch(r'/contents/diagnostic-playback/[0-9a-f]{32}/(?:[0-9]\.json\.gz|index\.json)', path))
    source_report_path = bool(re.fullmatch(r'/contents/diagnostics-source/[0-9a-f]{32}\.json', path))
    limit = 2 * 1024 * 1024 if path == '/contents/formats.json' or playback_path else LIMIT
    body=json.dumps(payload).encode('utf-8') if payload is not None else None
    req=Request(BASE+path,data=body,method='PUT' if payload is not None else 'GET',headers={
        'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json',
        'Content-Type':'application/json','X-GitHub-Api-Version':'2022-11-28',
        'User-Agent':'Strem4Kodi-credits-sync'})
    try:
        with build_opener(NoRedirect()).open(req,timeout=12) as response:raw=response.read(limit+1)
        if len(raw)>limit:raise SyncError('Sync data is too large','size')
        try:data=json.loads(raw)
        except (ValueError,UnicodeError):raise SyncError('Unexpected GitHub response','response') from None
        if not isinstance(data,dict):raise SyncError('Unexpected GitHub response','response')
        return data
    except HTTPError as e:
        if e.code==404 and payload is None and (playback_path or source_report_path or path in (FILE, '/contents/viewers.json', '/contents/saved-lists.json', '/contents/home-state.json', '/contents/formats.json', '/contents/format-scan-slot.json') or re.fullmatch(r'/contents/viewers/(?:main|[0-9a-f]{32})\.json\.gz',path) or re.fullmatch(r'/contents/diagnostics/[0-9a-f]{32}\.json', path) or re.fullmatch(r'/contents/diagnostic-logs/[0-9a-f]{32}/[0-5]\.log\.gz', path)):return None
        if e.code==429 or (e.headers and e.headers.get('Retry-After')):
            raise SyncError('GitHub is temporarily unavailable','backoff') from None
        if e.code in (401,403,404):raise SyncError('Check token access to the private sync repository','access') from None
        if e.code in (409,422):raise SyncError('Concurrent change; retrying on the next sync','conflict') from None
        raise SyncError('GitHub is temporarily unavailable','unavailable') from None
    except SyncError:raise
    except Exception:raise SyncError('Could not connect to GitHub; local data was kept','connection') from None


def decode(response):
    if response is None:return {},None
    if response.get('encoding')!='base64' or not isinstance(response.get('sha'),str):raise SyncError('Invalid credits file')
    try:
        raw=base64.b64decode(response['content'])
        if len(raw)>LIMIT:raise ValueError()
        data=json.loads(raw)
        if data.get('version')!=1 or not isinstance(data.get('series'),dict):raise ValueError()
        return clean(data['series']),response['sha']
    except Exception:raise SyncError('Invalid credits file; remote data was kept') from None


def synchronize(memory,token,still_current=lambda:True,transport=request):
    meta=transport(token)
    if meta.get('private') is not True:raise SyncError('Credits sync requires a private repository')
    if not still_current():return False
    remote,sha=decode(transport(token,FILE))
    if not still_current():return False
    local=memory.merge(remote)
    if local==remote:return True
    payload={'message':'Merge smart credits timings',
             'content':base64.b64encode(json.dumps({'version':1,'series':local},sort_keys=True,separators=(',',':')).encode()).decode()}
    if sha:payload['sha']=sha
    if not still_current():return False
    transport(token,FILE,payload)
    verified,_=decode(transport(token,FILE))
    # A response to PUT alone never counts as a verified sync.
    if merge(verified,local)!=verified:raise SyncError('Upload could not be confirmed; retrying')
    if not still_current():return False
    memory.merge(verified)
    return True


def summary(profile,addon):
    if addon.getSetting('credits_github_enabled')!='true':return 'Off'
    if not addon.getSetting('credits_github_token').strip():return 'Add a GitHub sync token'
    state=Store(Path(profile)/'smart-credits-sync').load()
    return str(state.get('status') or 'Waiting for first sync')


class CreditsSync:
    def __init__(self,profile,addon):
        from lib.smart_credits import CreditsMemory
        self.memory=CreditsMemory(profile);self.addon=addon
        self.status=Store(Path(profile)/'smart-credits-sync')
        self.busy=False;self.next_check=0;self.last_push=0;self.signature=None;self.last_config=None

    def config(self):return (self.addon.getSetting('credits_github_enabled'),self.addon.getSetting('credits_github_token').strip())

    def tick(self):
        config=self.config()
        if self.busy or config[0]!='true' or not config[1]:return
        if config!=self.last_config:self.next_check=0;self.last_config=config
        now=time.monotonic();signature=json.dumps(self.memory.snapshot(),sort_keys=True)
        if now<self.next_check and (signature==self.signature or now-self.last_push<60):return
        self.busy=True;self.next_check=now+300;self.last_push=now
        try:threading.Thread(target=self.run,args=(config,),daemon=True).start()
        except RuntimeError:self.busy=False

    def run(self,config):
        try:
            if synchronize(self.memory,config[1],lambda:self.config()==config):
                self.signature=json.dumps(self.memory.snapshot(),sort_keys=True)
                self.status.save({'status':'Synced with private GitHub','last_sync':time.time()})
        except SyncError as e:self.status.save({'status':str(e)})
        except Exception:
            try:self.status.save({'status':'Sync will retry; local timings were kept'})
            except Exception:pass
        finally:self.busy=False
