"""White artwork frames with bounded, shared card enlargement."""
import math
import xml.etree.ElementTree as ET

FRAME_PARTS = ('poster-glow', 'poster-border', 'cinematic/poster-focus', 'cinematic/wide-focus')
DESCRIPTION = 'Enlarged card focus'
FRAME = 'special://home/addons/script.freebird/resources/skins/Main/media/cards-rounded-v1/'


def _frame(control):
    if control.get('type') != 'image':
        return False
    for texture in control.findall('texture') + control.findall('bordertexture'):
        value = texture.text or ''
        if any(part in value for part in FRAME_PARTS) or value.endswith('/focus.png'):
            return True
    return False


def _number(control, name):
    try:
        return float(control.findtext(name, '0'))
    except (TypeError, ValueError):
        return 0


def _caption_top(control):
    # Multi-line episode titles can slide upward. Reserve their highest
    # possible position even when that conditional animation is inactive.
    top = _number(control, 'top')
    for animation in control.findall('animation'):
        effects = [animation] + list(animation.findall('effect'))
        for effect in effects:
            if effect.get('effect', effect.get('type')) != 'slide':
                continue
            try:
                top += min(0, float(effect.get('end', '0,0').split(',')[1]))
            except (ValueError, IndexError):
                pass
    return top


def _center(start, length, limit, scale):
    middle = start + length / 2
    if scale <= 1:
        return middle
    lower = (scale * (start + length) - limit) / (scale - 1)
    upper = scale * start / (scale - 1)
    return min(upper, max(lower, middle))


def _shape(width, height):
    if width < height:
        return 'poster'
    return 'episode' if width / max(1, height) > 1.85 else 'landscape'


def _round_artwork(tree):
    # Apply to both selected and unselected artwork, including fallback fills.
    # Full-size masks and frames share geometry, so their corners scale together.
    for control in tree.iter('control'):
        if control.get('type') != 'image':continue
        texture = control.find('texture')
        if texture is None:continue
        shape = _shape(_number(control, 'width'), _number(control, 'height'))
        for attribute in (None, 'diffuse'):
            value = (texture.text if attribute is None else texture.get(attribute)) or ''
            kind = None
            if any(value.endswith('/'+name) for name in
                   ('cinematic/poster-mask.png', 'cinematic/wide-mask.png',
                    'episode-card-local/mask.png', 'masks/poster.png')):
                kind = 'mask'
            elif value.endswith(('/cinematic/poster-outline.png', '/cinematic/wide-outline.png')):
                kind = 'outline'
            if kind:
                replacement = FRAME + shape + '-' + kind + '.png'
                if attribute is None:texture.text = replacement
                else:texture.set(attribute, replacement)
        if (texture.text or '').endswith('/cinematic/art-shade.png'):
            texture.set('diffuse', FRAME + 'episode-shade-mask.png')


def apply(tree):
    _round_artwork(tree)
    for listing in tree.iter('control'):
        for layout in listing.findall('focusedlayout'):
            if any(c.findtext('description') == DESCRIPTION for c in layout.findall('control')):
                continue
            frames = [c for c in layout.iter('control') if _frame(c)]
            zooms = [a for a in layout.iter('animation')
                     if a.find("effect[@type='zoom']") is not None]
            if not frames and not zooms:
                continue  # Keep native focus treatments, including circular person portraits.
            for parent in layout.iter():
                for child in list(parent):
                    if child in frames or child in zooms:
                        parent.remove(child)
            images = [c for c in layout.iter('control') if c.get('type') == 'image'
                      and _number(c, 'width') > 70 and _number(c, 'height') > 70]
            if not images:
                continue
            art = max(images, key=lambda c: _number(c, 'width') * _number(c, 'height'))
            x, y, width, height = (_number(art, n) for n in ('left', 'top', 'width', 'height'))
            cell_width = float(layout.get('width'))
            art_bottom = y + height
            captions = [_caption_top(c) for c in layout.findall('control')
                        if c.get('type') in ('label', 'textbox') and _number(c, 'top') >= art_bottom]
            limit_y = min(captions) if captions else float(layout.get('height'))
            # Poster growth rises from 4% to 7%. Wide cards use the largest
            # whole-percent growth that fits a complete first/last cell.
            percent = max(100, min(107, math.floor(100 * cell_width / width), math.floor(100 * limit_y / height)))
            scale = percent / 100
            group = ET.Element('control', type='group')
            for name, value in (('description', DESCRIPTION), ('left', '0'), ('top', '0'),
                                ('width', str(cell_width)), ('height', str(art_bottom))):
                ET.SubElement(group, name).text = value
            for child in list(layout):
                if child.tag == 'control' and _number(child, 'top') < art_bottom:
                    layout.remove(child)
                    group.append(child)
            frame = ET.SubElement(group, 'control', type='image')
            for name, value in (('left', x), ('top', y), ('width', width), ('height', height)):
                ET.SubElement(frame, name).text = str(value)
            ET.SubElement(frame, 'texture', colordiffuse='FFFFFFFF').text = FRAME + _shape(width, height) + '-focus.png'
            ET.SubElement(frame, 'visible').text = 'Control.HasFocus({})'.format(listing.get('id'))
            animation = ET.SubElement(group, 'animation', type='Conditional',
                                      condition='Control.HasFocus({})'.format(listing.get('id')), reversible='true')
            center = '{:.3f},{:.3f}'.format(_center(x, width, cell_width, scale), _center(y, height, limit_y, scale))
            ET.SubElement(animation, 'effect', type='zoom', start='100', end=str(percent), center=center, time='140')
            layout.insert(0, group)
    # Legacy unfocused layouts can also carry coloured border/glow textures.
    for parent in tree.iter():
        for child in list(parent):
            if child.tag == 'control' and _frame(child):
                parent.remove(child)
