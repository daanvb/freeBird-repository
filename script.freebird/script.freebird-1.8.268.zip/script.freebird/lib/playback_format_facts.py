"""Learn only the special formats explicitly detected in owned playback."""
from lib.dolby_variants import FEL, TRUEHD_ATMOS
from lib.player_format_logos import logo


def variants(data):
    icons = (data or {}).get('icons') or {}
    found = []
    if icons.get('hdr') == logo('dolby_vision_fel'):
        found.append(FEL)
    if icons.get('audio') == logo('truehd_atmos'):
        found.append(TRUEHD_ATMOS)
    return found


def remember(profile, context, data, seen=()):
    found = [tag for tag in variants(data) if tag not in seen]
    if not found:
        return []
    from lib.format_database import Database
    kind = context.get('kind')
    identity = context.get('meta_id') if kind == 'movie' else context.get('video_id')
    return found if Database(profile).observe_variants(kind, identity, found) else []
