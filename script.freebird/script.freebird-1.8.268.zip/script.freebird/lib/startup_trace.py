"""Startup offsets buffered in memory and saved at key readiness milestones."""
import time
from pathlib import Path

STAGES = {'splash', 'settings', 'account', 'imports', 'cached_home', 'layout', 'visible',
          'background', 'background_ui', 'background_art'}
_current = None


def begin(started=None):
    global _current
    _current = dict(started=time.monotonic() if started is None else started, stages={},
                    kind='repeat', at=int(time.time()))


def kind(first):
    if _current is not None:_current['kind'] = 'first' if first else 'repeat'


def mark(stage, started=None):
    if _current is not None and started is not None and started != _current['started']:return
    if _current is not None and stage in STAGES and stage not in _current['stages']:
        _current['stages'][stage] = min(1800000, max(0, int((time.monotonic() - _current['started']) * 1000)))


def persist(profile, background=False, started=None, stage=None):
    if _current is None:return
    if started is not None and started != _current['started']:return
    target = stage or ('background' if background else 'visible')
    if target not in STAGES:return
    if target in _current['stages']:return
    mark(target)
    try:
        from account import Store
        store = Store(Path(profile) / 'diagnostic-startup')
        state = store.load()
        rows = state.get('launches', [])
        rows = rows if isinstance(rows, list) else []
        if (background or stage) and rows and rows[-1].get('at') == _current['at']:
            rows = rows[:-1]
        state['launches'] = (rows + [dict(at=_current['at'], kind=_current['kind'],
                                         stages=dict(_current['stages']))])[-12:]
        store.save(state)
    except Exception:pass


def load(profile):
    from account import Store
    rows = Store(Path(profile) / 'diagnostic-startup').load().get('launches', [])
    return [dict(at=r.get('at') if type(r.get('at')) is int else 0,
                 kind=r['kind'], stages={k:v for k,v in r['stages'].items()
                    if k in STAGES and type(v) is int and 0 <= v <= 1800000})
            for r in rows[-12:] if isinstance(r, dict) and r.get('kind') in ('first', 'repeat')
            and isinstance(r.get('stages'), dict)] if isinstance(rows, list) else []
