"""Reveal applicable controls without modifying hidden saved preferences."""


def applicable(rows, get_setting):
    result = []
    for row in rows:
        identity = row.get('id', '')
        if identity in ('source_bitrate_mbps', 'source_bitrate_unknown') and get_setting('source_bitrate_mode') not in ('1', '2'):
            continue
        if identity == 'up_next_episode_limit' and get_setting('up_next_autoplay') != 'true':
            continue
        parent = None
        if identity == 'prerolls_dts': parent = 'prerolls_enabled'
        elif identity in ('unpause_rewind_pause', 'unpause_rewind_seconds'): parent = 'unpause_rewind_enabled'
        elif identity == 'forced_subtitles_language' and get_setting('forced_subtitles_mode') == '0':
            continue
        elif identity == 'startup_delay': parent = 'startup_autostart'
        elif identity.startswith('trailers_') and identity != 'trailers_enabled':
            if get_setting('trailers_enabled').lower() == 'false':
                continue
            parent = 'trailers_auto' if identity in ('trailers_auto_scope', 'trailers_delay') else 'trailers_enabled'
        elif identity.startswith('introdb_') and identity != 'introdb_enabled': parent = 'introdb_enabled'
        elif identity.startswith('up_next_') and identity != 'up_next_enabled': parent = 'up_next_enabled'
        elif identity.startswith('episode_rating_'): parent = identity.replace('episode_', '', 1)
        if parent and get_setting(parent).lower() == 'false':
            continue
        if identity.startswith(('auto_movie_', 'auto_series_', 'auto_animation_')) and not identity.endswith('_mode'):
            scope = next(prefix[:-1] for prefix in ('auto_movie_', 'auto_series_', 'auto_animation_')
                         if identity.startswith(prefix))
            if get_setting(scope + '_mode') in ('', '0'):
                continue
        if identity == 'auto_source_attempts' and not any(get_setting('auto_' + scope + '_mode') == '2' for scope in ('movie', 'series', 'animation')):
            continue
        result.append(row)
    return result
