"""Visible, catalogue-supplied filters for a selected streaming service."""


# Keep the right edge of both surfaces 40px before the cast column at x=1472.
PILL_LEFT = 1184
PILL_MAX_WIDTH = 248
MENU_WIDTH = 320


def pill_width(text):
    from lib.text_metrics import width
    return max(128, min(PILL_MAX_WIDTH, round(width(text, 21) * 1.06) + 40))


def filter_dialog(path):
    from lib.nimbus_select import Dialog
    return Dialog(path, left=PILL_LEFT + PILL_MAX_WIDTH - MENU_WIDTH, top=660, width=MENU_WIDTH)


def options(catalog):
    if (not isinstance(catalog, dict) or catalog.get('family') != 'Streaming services'
            or catalog.get('_search_collection') or catalog.get('_tmdb_collection')):
        return []
    return [e for e in catalog.get('extras', [])
            if e.get('name') not in ('skip', 'search') and e.get('options')]


def label(catalog, values, overview=False):
    if overview:
        genres = catalog.get('_overview_genres') if isinstance(catalog, dict) else []
        available = [{'name': 'genre', 'options': genres}] if genres else []
    else:
        available = options(catalog)
    if not available:
        return ''
    values = dict({} if overview else catalog.get('defaults') or {}, **(values or {}))
    if len(available) == 1:
        extra = available[0]
        required = not overview and (extra.get('isRequired') or any(extra['name'] in m.get('defaults', {}) or
                       any(e.get('name') == extra['name'] and e.get('isRequired') for e in m.get('extras', []))
                       for m in catalog.get('members', [])))
        return extra['name'].replace('_', ' ').title() + ': ' + str(values.get(extra['name'], 'Default' if required else 'All'))
    active = [str(values[e['name']]) for e in available if e['name'] in values]
    return 'Filters: ' + (' · '.join(active) if active else 'All')


def edit(window, path):
    if window.getProperty('page') != 'Discover':
        return
    if window.discover_overview:
        genres = (window.discover_catalog or {}).get('_overview_genres') or []
        if not genres:
            return
        selected = filter_dialog(path).select('Genre', ['All'] + genres)
        if selected < 0:
            return
        window.discover_extras = {'genre': genres[selected - 1]} if selected else {}
        window.discover_skip = 0
        window.discover_overview_offset = 0
        window.load_discover()
        if window.getProperty('discover_service_filter'):
            window.setFocusId(9204)
        return
    available = options(window.discover_catalog)
    if not available:
        return
    index = 0
    if len(available) > 1:
        index = filter_dialog(path).select(
            'Service filters', [e['name'].replace('_', ' ').title() for e in available])
        if index < 0:
            return
    # Reuse the existing option editor, including required values, clearing,
    # remembering and resetting each supplier's pagination cursor.
    window.edit_filters(3 + index)
    if window.getProperty('discover_service_filter'):
        window.setFocusId(9204)
