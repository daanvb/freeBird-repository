"""Group full-page search results without changing supplier title ranking."""


def retain_catalogues(query, rows, cache, scope, candidates=()):
    """Keep relevant lists discovered by earlier related full-page searches."""
    from search_match import normalized, relevance
    key = normalized(query)
    # Provider enumeration follows configured preference order. Reordering the
    # same enabled providers must not discard catalogues while the user refines
    # a query (for example JU -> JUR); only a changed provider set invalidates
    # the in-memory retention cache.
    scope = tuple(sorted(set(scope)))
    if cache.get('scope') != scope:
        cache.clear()
        cache.update(scope=scope, queries={})
    queries = cache['queries']
    result = list(rows)
    seen = {(r.get('type'), r.get('id')) for r in result}
    previous_rows = [row for previous in queries.values() for row in previous]
    previous_rows.extend(row for row in candidates if isinstance(row, dict))
    for row in previous_rows:
        identity = (row.get('type'), row.get('id'))
        if (key and identity not in seen and
                relevance(query, row.get('name')) is not None):
            result.append(row)
            seen.add(identity)
    if key:
        queries.pop(key, None)
        queries[key] = [r for r in result if r.get('_catalogue')][:100]
        while len(queries) > 32:
            queries.pop(next(iter(queries)))
    return result


def ordered(rows):
    def group(row):
        catalog = row.get('_catalogue') or {}
        if row.get('type') == 'collection' or catalog:
            return (0 if catalog.get('_tmdb_collection') else
                    1 if catalog.get('_genre') else
                    2 if catalog.get('_mdblist') else 3)
        return 4 if row.get('type') == 'movie' else 5 if row.get('type') == 'series' else 6
    return sorted(rows, key=group)
