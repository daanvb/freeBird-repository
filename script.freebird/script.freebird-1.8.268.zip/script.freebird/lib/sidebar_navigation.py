"""Hold Left at a browse edge; never interpret a double tap as a hold."""
LONG_PRESS = 0x01000000  # Kodi CKey::MODIFIER_LONG, preserved in Action.
HOLD_SECONDS = .65
REPEAT_GAP = .32
FIRST_REPEAT_GAP = .70


def advance(previous,focus,position,edge,now,button_code=0):
    if not edge:return None,False
    code=button_code if type(button_code) is int else 0
    if code & LONG_PRESS:return None,True
    if (isinstance(previous,tuple) and len(previous)==6
            and previous[:2]==(focus,position) and previous[5]==code):
        started,last,count=previous[2:5]
        limit=FIRST_REPEAT_GAP if count==1 else REPEAT_GAP
        if 0 < now-last <= limit:
            count+=1
            if count>=3 and now-started>=HOLD_SECONDS:return None,True
            return (focus,position,started,now,count,code),False
    return (focus,position,now,now,1,code),False
