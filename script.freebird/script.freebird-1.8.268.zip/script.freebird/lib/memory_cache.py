"""Process response cache bounded by entry count and estimated retained bytes."""
from collections import OrderedDict
from itertools import chain
import sys
import threading
import time

_LOCK = threading.Lock()
_DATA = OrderedDict()
_BYTES = 0
MAX_ENTRIES = 256
MAX_BYTES = 8 * 1024 * 1024


def _weight(key, value):
    """Count nested objects once, stopping as soon as an entry exceeds budget."""
    total = 0
    seen = set()
    pending = [iter((key, value))]
    while pending:
        try:
            current = next(pending[-1])
        except StopIteration:
            pending.pop()
            continue
        identity = id(current)
        if identity in seen:
            continue
        seen.add(identity)
        total += sys.getsizeof(current)
        if total > MAX_BYTES:
            return total
        if isinstance(current, dict):
            pending.append(iter(chain(current.keys(), current.values())))
        elif isinstance(current, (list, tuple)):
            pending.append(iter(current))
    return total


def _discard(key):
    global _BYTES
    row = _DATA.pop(key, None)
    if row is not None:
        _BYTES -= row[2]


def get(key):
    now = time.time()
    with _LOCK:
        row = _DATA.get(key)
        if row is None:
            return None
        expires, value, _ = row
        if expires is not None and expires <= now:
            _discard(key)
            return None
        _DATA.move_to_end(key)
        return value


def put(key, value, ttl):
    expires = None if ttl is None else time.time() + max(0, ttl)
    put_until(key, value, expires)


def put_until(key, value, expires):
    """Retain the response deadline; large responses stay in the disk cache.

    Byte weights describe objects at insertion. Callers share cached responses,
    so this is a retention budget, not a bound on interpreter process memory.
    """
    global _BYTES
    weight = _weight(key, value)
    with _LOCK:
        _discard(key)
        if weight > MAX_BYTES or (expires is not None and expires <= time.time()):
            return
        while _DATA and (len(_DATA) >= MAX_ENTRIES or _BYTES + weight > MAX_BYTES):
            _discard(next(iter(_DATA)))
        _DATA[key] = (expires, value, weight)
        _BYTES += weight


def clear():
    global _BYTES
    with _LOCK:
        _DATA.clear()
        _BYTES = 0
