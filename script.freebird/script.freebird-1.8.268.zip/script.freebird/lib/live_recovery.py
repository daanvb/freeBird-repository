"""Bounded, in-memory recovery of app-owned live sports sessions."""
import threading
import time
import uuid


class LiveRecovery:
    STALL_SECONDS = 12
    STARTUP_SECONDS = 45
    BACKOFF = (2, 10, 30)

    def trace(self, stage, reason=None, outcome=None):
        from lib.runtime_trace import playback
        playback('live.' + stage, owned=True,
                 attempt_number=(self.session or {}).get('retries', 0),
                 attempt_limit=len(self.BACKOFF), reason=reason, outcome=outcome)

    def __init__(self, player, kodi, home, clock=time.monotonic, cover_factory=None):
        self.player, self.kodi, self.home, self.clock = player, kodi, home, clock
        self.cover_factory = cover_factory
        self.lock = threading.RLock()
        self.session = None
        self.cover = None
        self.retired_covers = []
        self.paused = False

    def start(self, key, stream, url, item, ready=True):
        with self.lock:
            if self.session and self.session['key'] == key:
                if not ready:return
                self.session['waiting'] = False
                self.trace('ready')
                self.session['stall'] = None
                if self.cover:self.retired_covers.append(self.cover)
                self.cover = None
                return
            self.cancel()
            if not stream.get('_live_sports') and stream.get('kind') not in ('sport', 'sports'):return
            self.session = dict(key=key, url=url, item=item, retries=0, stall=None,
                                due=None, waiting=False, stopping=False, current_url=url)
            self.paused = False
            self.trace('start')

    def cancel(self):
        with self.lock:
            if self.session:self.trace('cancel', outcome='cancelled')
            self.session = None
            if self.cover:self.retired_covers.append(self.cover)
            self.cover = None

    def cancel_loading(self):
        with self.lock:
            session = self.session
            self.cancel()
            if not session:return
            try:
                if (self.player.isPlayingVideo() and
                        self.player.getPlayingItem().getProperty('StremioPlaybackKey') == session['key']):
                    self.player.stop()
            except (AttributeError, RuntimeError):pass

    def intentional_stop(self):
        from lib.player_back import STOPPING_PROPERTY
        import json
        from lib.playback_recovery import digest
        try:
            mark = json.loads(self.home.getProperty(STOPPING_PROPERTY))
            if not isinstance(mark, dict):return False
            return (self.session and mark.get('identity') in
                    (digest(self.session['url']), digest(self.session['current_url']))
                    and 0 <= self.clock()-float(mark['time']) <= 10)
        except (ValueError, TypeError, KeyError, AttributeError, RuntimeError, OverflowError):return False

    def ended(self, reason):
        with self.lock:
            if not self.session:return
            if self.intentional_stop():self.cancel();return
            if reason == 'stopped':
                # Kodi does not identify the cause of Stop. Respect native Stop;
                # only our own asynchronous shutdown is part of a retry.
                # Decoder failures commonly send Error followed by Stop.
                if self.session['due'] is not None:return
                if not self.session['stopping']:self.cancel()
                return
            self.schedule('playback-error' if reason == 'error' else 'playback-stopped')

    def schedule(self, reason=None):
        session = self.session
        if not session or session['due'] is not None:return
        if session['retries'] >= len(self.BACKOFF):
            self.trace('schedule', reason=reason, outcome='retry-limit')
            self.cancel();return
        self.trace('schedule', reason=reason)
        session['due'] = self.clock() + self.BACKOFF[session['retries']]
        session['waiting'] = False
        session['cover_pending'] = uuid.uuid4().hex

    def finish_covers(self):
        """Service-thread cleanup; never close native GUI from AV callbacks."""
        with self.lock:
            covers, self.retired_covers = self.retired_covers, []
        for cover in covers:cover.finish()

    def tick(self):
        self.finish_covers()
        with self.lock:
            session = self.session
            if not session:return
            token = session.pop('cover_pending', None)
            if token and self.cover_factory:
                if self.cover:self.cover.finish()
                self.cover = self.cover_factory(self.cancel_loading)
                self.cover.begin(token, 'Live sports', 'Reconnecting live stream')
            try:
                playing = self.player.isPlayingVideo()
                if playing:
                    item = self.player.getPlayingItem()
                    key = item.getProperty('StremioPlaybackKey')
                    if key != session['key']:self.cancel();return
                if self.intentional_stop():self.cancel();return
                now = self.clock()
                if session['due'] is not None:
                    if playing:
                        if not session['stopping']:
                            session['stopping'] = True
                            session['stop_at'] = now
                            self.player.stop()
                        elif now-session['stop_at'] >= 5:self.cancel()
                        return
                    # Another selection can be resolving while Kodi reports no
                    # active video. Relinquish this old session before replay.
                    from lib.native_playback import busy
                    if busy():self.cancel();return
                    if now < session['due']:return
                    session['due'] = None
                    session['stopping'] = False
                    session['retries'] += 1
                    session['waiting'] = True
                    session['opened'] = now
                    self.trace('replay')
                    self.player.play(session['url'], session['item'])
                    return
                if session['waiting']:
                    if now-session['opened'] >= self.STARTUP_SECONDS:self.schedule('startup-timeout')
                    return
                if self.paused or not playing:
                    session['stall'] = None
                    return
                # Live/HLS clocks may reset or be absent. Caching is Kodi's
                # affirmative stalled-input evidence; the clock alone is not.
                # Kodi exposes no rendered-frame progress counter here.
                # Stream FPS/queue levels are not frame progress, and identical
                # RenderCapture images also occur during legitimate stills.
                if self.kodi.getCondVisibility('Player.Caching'):
                    if session['stall'] is None:session['stall'] = now
                    elif now-session['stall'] >= self.STALL_SECONDS:self.schedule('caching-stall')
                else:session['stall'] = None
            except (AttributeError, RuntimeError):
                # Query races during decoder teardown must not cause a restart.
                return
