"""Optional Live Football API enrichment for Sports Streams catalogue rows."""
from datetime import datetime, timezone
from collections import OrderedDict
import hashlib
import json
import re
import time
import threading
import unicodedata
from functools import lru_cache
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from lib.sports_epg import entry

API = 'https://live-football-api.com/api/v1/matches'
MAX_BYTES = 2 * 1024 * 1024
CACHE_SECONDS = 5 * 60
MAX_STALE_SECONDS = 15 * 60
FAILURE_SECONDS = 30
MAX_DATES = 32
_cache = OrderedDict()
_lock = threading.Lock()
_pending = {}


def _normal(value):
    value = unicodedata.normalize('NFKD', str(value or ''))
    value = value.encode('ascii', 'ignore').decode('ascii').casefold()
    value = re.sub(r'\b(?:u|under)[\s-]*(\d{1,2})\b', r'u\1', value)
    words = re.sub(r'[^a-z0-9]+', ' ', value).split()
    ignored = {'ac', 'afc', 'as', 'cf', 'club', 'fc', 'ff', 'fk', 'if', 'sc', 'sk', 'ssc'}
    words = tuple(word for word in words if word not in ignored)
    # A few widely used display names are not token prefixes of the names used
    # by fixture feeds. Keep this deliberately small so matching both teams is
    # still a strong identity check rather than fuzzy guessing.
    aliases = {
        ('paris', 'saint', 'germain'): ('psg',),
        ('paris', 'sg'): ('psg',),
        ('manchester', 'united'): ('manchester', 'united'),
        ('man', 'utd'): ('manchester', 'united'),
        ('bayern', 'munchen'): ('bayern', 'munich'),
    }
    return aliases.get(words, words)


def _same_team(left, right):
    return _same_normalized(_normal(left), _normal(right))


def _same_normalized(left, right):
    if not left or not right:
        return False
    # Senior, women's, reserve and youth sides can play the same opponents.
    # Unique names in one daily response do not make these interchangeable.
    def qualifiers(words):
        return {word for word in words if word in ('women', 'womens', 'ladies', 'reserves', 'ii', 'b', 'youth', 'academy')
                or re.fullmatch(r'u\d{1,2}', word)}
    if qualifiers(left) != qualifiers(right):
        return False
    if left == right:
        return True
    shorter, longer = sorted((left, right), key=len)
    # Local/provider suffixes are often omitted. Require every remaining token
    # to agree exactly or as an unambiguous three-character-or-longer prefix.
    return all(any(token == candidate or
                   min(len(token), len(candidate)) >= 3 and
                   max(token, candidate).startswith(min(token, candidate))
                   for candidate in longer) for token in shorter)


def _teams(row):
    title = str(row.get('name') or row.get('title') or '')
    parts = re.split(r'\s+(?:vs?\.?|versus)\s+', title, maxsplit=1, flags=re.I)
    if len(parts) != 2:
        return None
    # Provider catalogue titles can append display-only live/status text.
    away = re.split(r'\s+(?:[-|·]\s*)?(?:live(?:\s+now)?|stream)\b', parts[1], 1, flags=re.I)[0]
    return parts[0].strip(), away.strip()


def _match_teams(match):
    if not isinstance(match, dict):
        return None
    home, away = match.get('home'), match.get('away')
    home = home.get('name') if isinstance(home, dict) else home
    away = away.get('name') if isinstance(away, dict) else away
    return (home, away) if all(isinstance(value, str) and value.strip() for value in (home, away)) else None


def _same_fixture(listing_teams, fixture_teams, same_team=_same_team):
    """Match both clubs even when a catalogue displays the away side first."""
    if not fixture_teams:
        return False
    direct = (same_team(listing_teams[0], fixture_teams[0]) and
              same_team(listing_teams[1], fixture_teams[1]))
    reverse = (same_team(listing_teams[0], fixture_teams[1]) and
               same_team(listing_teams[1], fixture_teams[0]))
    return direct or reverse


def _status(match):
    value = match.get('status') if isinstance(match, dict) else None
    live = False
    if isinstance(value, dict):
        live = value.get('is_live') is True
        value = value.get('status') or value.get('state') or value.get('display')
    if not isinstance(value, str):
        return 'live' if live else 'scheduled'
    value = re.sub(r'[^a-z]+', '', str(value or '').casefold())
    if value == 'postponed':
        return 'postponed'
    if value in ('cancelled', 'canceled'):
        return 'cancelled'
    if live or value in ('live', 'inplay', 'firsthalf', 'secondhalf', 'halftime', 'extratime', 'penalties'):
        return 'live'
    if value in ('ft', 'finished', 'fulltime', 'completed', 'complete', 'ended', 'final', 'postgame'):
        return 'finished'
    return 'scheduled'


def _kickoff(match, match_date):
    value = str(match.get('kickoff') or '').strip()
    try:
        parsed = datetime.strptime(match_date + ' ' + value, '%Y-%m-%d %H:%M')
        return parsed.replace(tzinfo=timezone.utc).isoformat().replace('+00:00', 'Z')
    except (TypeError, ValueError):
        return None


def _download(api_key, match_date, opener=urlopen):
    query = urlencode({'api_key': api_key, 'date': match_date, 'lang': 'en'})
    request = Request(API + '?' + query, headers={'Accept': 'application/json',
                                                   'User-Agent': 'Strem4Kodi/1'})
    with opener(request, timeout=8) as response:
        raw = response.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise ValueError('Live Football API response is too large')
    payload = json.loads(raw.decode('utf-8'))
    if not isinstance(payload, dict) or payload.get('success') is False:
        raise ValueError('Live Football API rejected the request')
    data = payload.get('data')
    matches = data.get('matches') if isinstance(data, dict) else None
    if not isinstance(matches, list):
        raise ValueError('Live Football API matches must be a list')
    return [match for match in matches if isinstance(match, dict)]


def matches(api_key, match_date, now=None, opener=urlopen):
    """Cache one date briefly; never retain or expose the raw credential."""
    return _snapshot(api_key, match_date, now, opener)[0]


def _snapshot(api_key, match_date, now=None, opener=urlopen):
    """Return fixtures and their real observation age, sharing concurrent reads."""
    now = time.monotonic() if now is None else now
    identity = hashlib.sha256(api_key.encode('utf-8')).hexdigest()
    key = identity, match_date
    def usable(cached):
        if cached and cached[0] is not None and 0 <= now - cached[0] <= MAX_STALE_SECONDS:
            return cached[1], now - cached[0]
        return [], 0
    with _lock:
        cached = _cache.get(key)
        if cached:
            _cache.move_to_end(key)
            if now < cached[2]:
                return usable(cached)
        pending = _pending.get(key)
        if pending is None:
            pending = _pending[key] = threading.Event()
            owner = True
        else:
            owner = False
    if not owner:
        pending.wait(9)  # The HTTP operation itself has an eight-second timeout.
        with _lock:
            return usable(_cache.get(key))
    updated = None
    try:
        result = _download(api_key, match_date, opener)
    except Exception:
        updated = (cached[0], cached[1], now + FAILURE_SECONDS) if cached else (None, [], now + FAILURE_SECONDS)
    else:
        updated = now, result, now + CACHE_SECONDS
    finally:
        # Only the owner releases waiters, including injected download failures.
        with _lock:
            if updated is not None:
                _cache[key] = updated
                _cache.move_to_end(key)
                while len(_cache) > MAX_DATES:
                    _cache.popitem(last=False)
            _pending.pop(key, None)
            pending.set()
    return usable(updated)


def enrich(rows, api_key, now=None, opener=urlopen, cancelled=None):
    """Add a trusted UTC kick-off only when both teams identify one match."""
    if cancelled and cancelled() or not api_key or not isinstance(api_key, str):
        return rows
    api_key = api_key.strip()
    if not api_key:
        return rows
    now = datetime.now(timezone.utc) if now is None else now
    candidates = [(row, _teams(row)) for row in rows if isinstance(row, dict)]
    candidates = [(row, teams) for row, teams in candidates
                  if teams and row.get('_sports_role') != '24hr']
    if not candidates:
        return rows
    today = now.astimezone(timezone.utc).date()
    schedules = {}
    # A page compares the same fixture names many times. Reuse normalization
    # only within this enrichment; no provider names survive in a global cache.
    normalized = lru_cache(maxsize=4096)(_normal)
    def same_team(left, right):
        return _same_normalized(normalized(left), normalized(right))
    enriched = {id(row): row for row in rows if isinstance(row, dict)}
    for row, teams in candidates:
        if cancelled and cancelled():
            return rows
        current = entry(row)
        try:
            date = datetime.fromtimestamp(current['start'], timezone.utc).date() if current['start'] is not None else today
        except (ValueError, OverflowError, OSError):
            continue
        # Do not attach today's same-named fixture to a different dated event.
        # Limit enrichment to yesterday/today/tomorrow; retain other provider rows.
        if abs((date - today).days) > 1:
            continue
        match_date = date.isoformat()
        if match_date not in schedules:
            schedules[match_date] = _snapshot(api_key, match_date, opener=opener)
        fixtures, age = schedules[match_date]
        found = [match for match in fixtures
                 if _same_fixture(teams, _match_teams(match), same_team)]
        if len(found) != 1:
            continue
        kickoff = _kickoff(found[0], match_date)
        if not kickoff:
            continue
        value = dict(row, _sports_schedule='Live Football API',
                     _sports_schedule_checked=now.timestamp() - age)
        league = found[0].get('league')
        league_data = league if isinstance(league, dict) else {}
        league_name = league_data.get('name') if league_data else league
        # Replace competition metadata as one unit. The stable API identity
        # prevents equal translated/generic league names from being merged.
        for field in ('_sports_competition', '_sports_competition_id',
                      '_sports_competition_country'):
            value.pop(field, None)
        if isinstance(league_name, str) and league_name.strip():
            value['_sports_competition'] = league_name.strip()[:120]
            league_id = league_data.get('id')
            country = league_data.get('country')
            if isinstance(league_id, str) and league_id.strip():
                value['_sports_competition_id'] = league_id.strip()[:160]
            if isinstance(country, str) and country.strip():
                value['_sports_competition_country'] = country.strip()[:80]
        if current['start'] is None:
            value['startTime'] = kickoff
        kickoff_stamp = datetime.fromisoformat(kickoff.replace('Z', '+00:00')).timestamp()
        marker_stamp = current['start'] if current['start'] is not None else kickoff_stamp
        if current['live'] and now.timestamp() < marker_stamp:
            # The catalogue proves coverage is already available, while the
            # schedule time remains the separate match kick-off marker.
            value['_sports_broadcast_start'] = now.timestamp()
        state = _status(found[0])
        value['_sports_schedule_status'] = state
        if state == 'live':
            value['isLive'] = True
        enriched[id(row)] = value
    return [enriched.get(id(row), row) for row in rows]
