"""SQLite-backed Continue Watching index for fast Kodi Home rendering."""
import json, sqlite3, threading, time
from pathlib import Path
from lib.progress_values import integer

_lock=threading.RLock()
LOGIC_VERSION=5

def watch_age(item, now=None):
    """Seconds since actual playback, never a metadata/cache refresh timestamp."""
    from datetime import datetime, timezone
    if not isinstance(item, dict): return None
    state = item.get('state') if isinstance(item.get('state'), dict) else {}
    value = state.get('lastWatched') or item.get('_home_last_playback')
    try:
      stamp = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
      if stamp.tzinfo is None: stamp = stamp.replace(tzinfo=timezone.utc)
      age = (time.time() if now is None else now) - stamp.timestamp()
      import math
      return max(0, age) if math.isfinite(age) else None
    except (TypeError, ValueError, OverflowError):
      fallback = item.get('_home_last_playback')
      return watch_age({'state': {'lastWatched': fallback}}, now) if fallback and fallback != value else None


def recently_watched(item, now=None):
    age = watch_age(item, now)
    return age is not None and age < 30 * 86400

def suppress(profile, item):
    """Keep an explicit removal until a subsequent playback changes lastWatched."""
    key = 'removed:' + str(item.get('type')) + ':' + str(item.get('_id') or item.get('id'))
    with _lock:
      db = _db(profile)
      try:
        _bind_removals(db, profile)
        db.execute('INSERT OR REPLACE INTO continue_meta(key,value) VALUES(?,?)',
                   (key, str((item.get('state') or {}).get('lastWatched') or '')))
        db.execute('DELETE FROM continue_items WHERE media_type=? AND media_id=?',
                   (item.get('type'), item.get('_id') or item.get('id')))
        db.commit()
      finally: db.close()

def _newer_watch(value, previous):
    from datetime import datetime, timezone
    def parse(stamp):
      instant = datetime.fromisoformat(str(stamp).replace('Z', '+00:00'))
      return instant.replace(tzinfo=timezone.utc) if instant.tzinfo is None else instant
    try:
      current = parse(value)
      return current > parse(previous) if previous else True
    except (TypeError, ValueError, OverflowError): return False

def _path(profile):
    from lib.viewer_profiles import directory
    return directory(profile)/'continue_index.sqlite'
def _db(profile):
    db=sqlite3.connect(str(_path(profile)),timeout=2)
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('''CREATE TABLE IF NOT EXISTS continue_items (
      media_type TEXT NOT NULL, media_id TEXT NOT NULL, status TEXT NOT NULL,
      last_video_id TEXT, next_video_id TEXT, next_release TEXT,
      progress_ms INTEGER NOT NULL DEFAULT 0, last_watched TEXT,
      item_json TEXT NOT NULL, source_mtime TEXT, updated REAL NOT NULL, next_check REAL NOT NULL DEFAULT 0,
      PRIMARY KEY(media_type,media_id))''')
    
    try: db.execute('ALTER TABLE continue_items ADD COLUMN next_check REAL NOT NULL DEFAULT 0')
    except sqlite3.OperationalError: pass
    try: db.execute('ALTER TABLE continue_items ADD COLUMN aliases_json TEXT')
    except sqlite3.OperationalError: pass
    db.execute('CREATE INDEX IF NOT EXISTS cw_status_recent ON continue_items(status,last_watched DESC)')
    db.execute('CREATE TABLE IF NOT EXISTS continue_meta (key TEXT PRIMARY KEY,value TEXT NOT NULL)')
    row=db.execute("SELECT value FROM continue_meta WHERE key='logic_version'").fetchone()
    if not row or str(row[0])!=str(LOGIC_VERSION):
        db.execute('DELETE FROM continue_items')
        db.execute("INSERT OR REPLACE INTO continue_meta(key,value) VALUES('logic_version',?)",(str(LOGIC_VERSION),))
        db.commit()
    return db

def _bind_removals(db, profile):
    """Legacy SQLite removals belong to one signed-in account, like Home state."""
    import hashlib
    from account import Store
    from lib.viewer_profiles import account_token
    token = account_token(profile)
    if not token:
        return
    owner = hashlib.sha256(str(token).encode()).hexdigest()
    previous = db.execute("SELECT value FROM continue_meta WHERE key='removal_owner'").fetchone()
    if previous and previous[0] != owner:
        db.execute("DELETE FROM continue_meta WHERE key LIKE 'removed:%'")
    db.execute("INSERT OR REPLACE INTO continue_meta(key,value) VALUES('removal_owner',?)", (owner,))


def removal_watermarks(profile):
    """Read existing local removals for migration into cross-device Home sync."""
    with _lock:
      db = _db(profile)
      try:
        _bind_removals(db, profile)
        db.commit()
        return {key: value for key, value in db.execute(
            "SELECT key,value FROM continue_meta WHERE key LIKE 'removed:%'")}
      finally:
        db.close()

def seed(profile, library):
    """Import all plausible CW pointers from Stremio without network metadata."""
    now=time.time(); seen=set()
    from account import Store
    from lib.home_state import HomeState
    try:
      from lib.viewer_profiles import account_token
      token = account_token(profile)
      shared = HomeState(profile, token).snapshot() if token else {}
    except Exception:
      shared = {}
    with _lock:
      db=_db(profile)
      try:
        _bind_removals(db, profile)
        for row in library or []:
          if not isinstance(row,dict) or row.get('type') not in ('movie','series'): continue
          state=row.get('state') if isinstance(row.get('state'),dict) else {}
          media_id=str(row.get('_id') or row.get('id') or ''); typ=row.get('type')
          if not media_id: continue
          removal_key = 'removed:' + typ + ':' + media_id
          marker = shared.get(removal_key)
          if marker and not _newer_watch(state.get('lastWatched'), marker['lastWatched']):
            continue
          removed = db.execute('SELECT value FROM continue_meta WHERE key=?', (removal_key,)).fetchone()
          if removed:
            if not _newer_watch(state.get('lastWatched'), removed[0]): continue
            db.execute('DELETE FROM continue_meta WHERE key=?', (removal_key,))
          offset=integer(state.get('timeOffset'))
          duration=integer(state.get('duration'))
          completed = (duration>0 and offset>=duration*0.90) or (bool(state.get('flaggedWatched')) and (duration<=0 or offset<=1))
          # Movies belong in CW only for genuine incomplete progress. A stale
          # offset on a watched/90%+ movie must never resurrect it.
          movie_pointer=typ=='movie' and offset>0 and not completed
          # Preserve recently watched series even when completion clears the
          # pointer offset. Metadata can later supply the next episode to focus.
          series_pointer=typ=='series' and (bool(state.get('video_id')) and (offset>0 or completed or recently_watched(row))
                                           or not row.get('removed') and not row.get('temp'))
          if not (series_pointer or movie_pointer): continue
          status=('waiting' if typ=='series' and (completed or offset<=1 or not state.get('video_id')) else 'partial')
          key=(typ,media_id);seen.add(key)
          item=dict(row,id=media_id);mtime=str(row.get('_mtime') or '');video_id=str(state.get('video_id') or '')
          watched_at=str(state.get('lastWatched') or '') if watch_age(item, now) is not None else ''
          # Normal refreshes read only small scalar fields, not full episode lists.
          existing=db.execute('SELECT status,last_video_id,source_mtime,next_video_id,next_release,NULL,progress_ms,last_watched,aliases_json FROM continue_items WHERE media_type=? AND media_id=?',key).fetchone()
          previous = {}
          # Legacy progress may lack lastWatched. Persist a baseline once rather
          # than renewing its clock on every Home refresh or favourite edit.
          if watch_age(item, now) is None and (movie_pointer or video_id and offset > 1 and not completed):
            raw = db.execute('SELECT item_json FROM continue_items WHERE media_type=? AND media_id=?',key).fetchone() if existing else None
            try: previous = json.loads(raw[0]) if raw else {}
            except (TypeError, ValueError): previous = {}
            if not isinstance(previous, dict): previous = {}
            if (existing and existing[1] == video_id and existing[6] == offset
                    and previous.get('_home_last_playback')):
              item['_home_last_playback'] = previous['_home_last_playback']
            else:
              from datetime import datetime, timezone
              item['_home_last_playback'] = datetime.fromtimestamp(now, timezone.utc).isoformat()
            watched_at = item['_home_last_playback']
          if (existing and existing[1]==video_id and existing[2]==mtime
                  and existing[7]==watched_at
                  and (not item.get('_home_last_playback') or
                       previous.get('_home_last_playback') == item['_home_last_playback'])
                  and (existing[0] in ('next_ready','finished','waiting')
                       or existing[0]=='partial' and existing[6]==offset)):
            # No Stremio state change: preserve the resolved episode/status.
            # Reading Home is not playback and need not rewrite unchanged rows.
            if not existing[8]:
              from lib.catalogue_identity import aliases
              try:
                full=json.loads(db.execute('SELECT item_json FROM continue_items WHERE media_type=? AND media_id=?',key).fetchone()[0])
              except (TypeError,ValueError):full={}
              keys=aliases(full if isinstance(full,dict) else {}) | aliases(item)
              db.execute('UPDATE continue_items SET aliases_json=? WHERE media_type=? AND media_id=?',
                         (json.dumps(sorted(keys)),typ,media_id))
          else:
            from lib.catalogue_identity import aliases
            # REPLACE works on the SQLite versions shipped by older Android builds.
            # A changed pointer intentionally discards the previous resolution.
            db.execute('''INSERT OR REPLACE INTO continue_items(media_type,media_id,status,last_video_id,next_video_id,next_release,progress_ms,last_watched,item_json,source_mtime,updated,aliases_json)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
              (typ,media_id,status,video_id,None,None,offset,watched_at,json.dumps(item,separators=(',',':')),mtime,now,json.dumps(sorted(aliases(item)))))
        # Entries no longer represented by Stremio CW state are removed. Resolved waiting/finished
        # rows remain represented because completed series pointers are seeded above.
        rows=db.execute('SELECT media_type,media_id FROM continue_items').fetchall()
        for key in rows:
          if tuple(key) not in seen: db.execute('DELETE FROM continue_items WHERE media_type=? AND media_id=?',key)
        db.commit()
      finally: db.close()

def resolve_series(profile, media_id, item, target, resume_ms=0, confirmed_finished=False):
    status='next_ready' if target else ('finished' if confirmed_finished else 'waiting')
    next_id=str((target or {}).get('id') or '')
    release=str((target or {}).get('released') or (target or {}).get('firstAired') or '')
    display=dict(item)
    display['state']=dict(display.get('state') or {})
    if target:
      display['state']['video_id']=next_id;display['state']['timeOffset']=int(resume_ms) if resume_ms else 1
    from lib.catalogue_identity import aliases
    with _lock:
      db=_db(profile)
      try:
       db.execute('UPDATE continue_items SET status=?,next_video_id=?,next_release=?,progress_ms=?,item_json=?,updated=?,next_check=?,aliases_json=? WHERE media_type=? AND media_id=?',
                  (status,next_id,release,int(resume_ms or 0),json.dumps(display,separators=(',',':')),time.time(),time.time()+(86400 if status in ('finished','waiting') else 0),json.dumps(sorted(aliases(display))),'series',media_id));db.commit()
      finally: db.close()

def _stored_aliases(value):
    try:
        data = json.loads(value)
        return {(r[0],r[1]) for r in data if isinstance(r,list) and len(r)==2
                and r[0] in ('movie','series') and isinstance(r[1],str)} if isinstance(data,list) else set()
    except (TypeError, ValueError): return set()


def retained_rows(profile, limit=100, now=None):
    """Disjoint Home windows: under 30 days active, 30–60 days reminders.

    Legacy progress has a durable first-observed baseline until genuine playback
    supplies a timestamp. Expiry never deletes the progress record.
    """
    current, forgotten, seen, candidates = [], [], set(), []
    instant = time.time() if now is None else now
    from lib.catalogue_identity import aliases
    with _lock:
      db=_db(profile)
      try:
        data=db.execute('SELECT media_type,media_id,status,progress_ms,last_watched,aliases_json,next_check FROM continue_items').fetchall()
        for typ,media_id,status,progress,stamp,key_data,next_check in data:
          age=watch_age({'state':{'lastWatched':stamp}},instant)
          keys=_stored_aliases(key_data)
          cached=None
          if not keys:  # Upgrade/repair old index records without discarding progress.
            try:
              cached=json.loads(db.execute('SELECT item_json FROM continue_items WHERE media_type=? AND media_id=?',(typ,media_id)).fetchone()[0])
              age=watch_age(cached,instant);keys=aliases(cached)
            except (TypeError,ValueError,AttributeError):continue
          if status not in ('partial','next_ready') and not (typ=='series' and age is not None):continue
          if age is not None and age>=60*86400:continue
          candidates.append((age if age is not None else 0,typ,media_id,status,progress,keys,cached))
        # Numeric ages make timezone offsets and aliases consistent across clients.
        for age,typ,media_id,status,progress,keys,cached in sorted(candidates,key=lambda r:r[0]):
          if keys & seen:continue
          seen.update(keys)
          target=forgotten if age>=30*86400 else current
          if len(target)>=int(limit):continue
          try:
            row=cached if cached is not None else json.loads(db.execute('SELECT item_json FROM continue_items WHERE media_type=? AND media_id=?',(typ,media_id)).fetchone()[0])
            state = row.get('state') or {}
            if (typ == 'series' and integer(state.get('duration')) > 0 and
                    integer(state.get('timeOffset')) >= integer(state.get('duration')) * 0.90):
              # Keep source state intact for metadata resolution, but never
              # render a completed offset as a resumable progress bar.
              row = dict(row)
              row['state'] = dict(row.get('state') or {})
              row['state']['timeOffset'] = 0
            if status=='next_ready' and progress<=1:
              target_id=(row.get('state') or {}).get('video_id')
              episode=next((v for v in row.get('videos',[]) if v.get('id')==target_id),None)
              if episode:row['_next_episode']=dict(episode);row['_focus_video_id']=target_id
            if target is forgotten:row['_continue_watching']=True
            target.append(row)
          except (TypeError,ValueError,AttributeError):continue
          if len(current)>=int(limit) and len(forgotten)>=int(limit):break
      finally:db.close()
    return current, forgotten


def rows(profile, limit=100, now=None):
    return retained_rows(profile, limit, now)[0]


def reminders(profile, limit=100, now=None):
    return retained_rows(profile, limit, now)[1]

def unresolved_series(profile, limit=32):
    with _lock:
      db=_db(profile)
      try:data=db.execute("SELECT media_id,item_json FROM continue_items WHERE media_type='series' AND status IN ('waiting','finished') AND next_check<=? ORDER BY CASE WHEN status='waiting' THEN 0 ELSE 1 END,last_watched DESC LIMIT ?",(time.time(),int(limit))).fetchall()
      finally:db.close()
    out=[]
    for media_id,raw in data:
      try:out.append((media_id,json.loads(raw)))
      except Exception:pass
    return out


def upcoming(profile, limit=100, now=None):
    """Next dated future episode per saved series, read from resolved local metadata."""
    from datetime import datetime, timezone
    from lib.episode_state import watched_ids
    instant = now or datetime.now().astimezone()
    if instant.tzinfo is None:
      instant = instant.replace(tzinfo=timezone.utc)
    with _lock:
      db = _db(profile)
      try: data = db.execute("SELECT item_json FROM continue_items WHERE media_type='series'").fetchall()
      finally: db.close()
    result = []
    for (raw,) in data:
      try:
        row = json.loads(raw)
        videos = row.get('videos') or []
        watched = watched_ids(videos, row)
        candidates = []
        for video in videos:
          if not video.get('id') or video['id'] in watched or int(video.get('season') or 0) <= 0:
            continue
          try:
            date = datetime.fromisoformat(str(video.get('released') or video.get('firstAired') or '').replace('Z', '+00:00'))
            if date.tzinfo is None: date = date.replace(tzinfo=timezone.utc)
          except ValueError: continue
          # Providers often supply midnight as an air date, not an exact start time.
          # Retain today's unwatched release all day; this does not imply a stream exists.
          if date.date() >= instant.date(): candidates.append((date, video))
        if candidates:
          date, episode = min(candidates, key=lambda pair: pair[0])
          card = dict(row, _focus_video_id=episode['id'], _upcoming_episode=True)
          card['name'] = '{} - S{:02d}E{:02d}'.format(row.get('name', ''), int(episode.get('season') or 0), int(episode.get('episode') or episode.get('number') or 0))
          days = (date.date() - instant.date()).days
          card['_release_label'] = ('Airs today' if days == 0 else 'Airs tomorrow' if days == 1 else 'Expected ' + date.strftime('%d %b %Y'))
          card['description'] = episode.get('description') or episode.get('overview') or row.get('description', '')
          result.append((date, card))
      except (ValueError, TypeError): continue
    return [card for _, card in sorted(result, key=lambda pair: pair[0])[:limit]]

def prefetch_rows(profile, limit=6):
    """Recent visible CW items with their exact stream identity."""
    out=[]
    for item in rows(profile,limit):
      typ=item.get('type');media_id=str(item.get('id') or item.get('_id') or '')
      state=item.get('state') if isinstance(item.get('state'),dict) else {}
      identity=str(state.get('video_id') or media_id) if typ=='series' else media_id
      if typ in ('movie','series') and media_id and identity:out.append((typ,identity,item))
    return out


def resolved_series(profile):
    """Return local episode metadata without starting network lookups."""
    with _lock:
        db = _db(profile)
        try:
            data = db.execute("SELECT item_json FROM continue_items WHERE media_type='series'").fetchall()
        finally:
            db.close()
    result = []
    for (raw,) in data:
        try:
            row = json.loads(raw)
            if isinstance(row, dict) and row.get('videos'):
                result.append(row)
        except (ValueError, TypeError):
            continue
    return result


def airing_series(profile):
    """Keep unsuppressed CW provenance when its thirty-day display window ends.

    Saved but unstarted titles also inhabit the index; only playback pointers
    qualify here. Explicit Home removals delete/suppress these indexed records.
    """
    with _lock:
        db = _db(profile)
        try:
            data = db.execute("SELECT item_json,last_video_id FROM continue_items WHERE media_type='series'").fetchall()
        finally:
            db.close()
    result = []
    for raw, video_id in data:
        if not video_id:
            continue
        try:
            row = json.loads(raw)
            if isinstance(row, dict):
                result.append(row)
        except (TypeError, ValueError, OverflowError):
            continue
    return result
