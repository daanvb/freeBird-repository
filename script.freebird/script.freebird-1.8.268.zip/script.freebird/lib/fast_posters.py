"""Device-local, measured-speed poster previews. Source artwork stays intact."""
import json
import math
import re
import time
from urllib.parse import urlsplit, parse_qs, unquote

SETTING = 'ui_fast_posters'
_width = None
_checked = 0.0
_upgrade_delay = 5.0
_cache = {}


def preview_url(full, row, width=342):
    """Only resize documented public TMDB renditions, never signed upstreams."""
    def smaller(url):
        if not isinstance(url, str):return ''
        match = re.fullmatch(r'https://image\.tmdb\.org/t/p/(w342|w500|w780|original|w600_and_h900_bestv2)(/[A-Za-z0-9_.-]+)', url)
        if not match:return ''
        size = {'w342': 342, 'w500': 500, 'w780': 780, 'original': 9999,
                'w600_and_h900_bestv2': 600}[match[1]]
        return 'https://image.tmdb.org/t/p/w%d%s' % (width, match[2]) if size > width else url
    direct = smaller(full)
    if direct:return direct if direct != full else ''
    try:
        parsed = urlsplit(full)
        # The configured provider supplied this independent fallback. Do not
        # unwrap or alter its signed `url` parameter or guess another endpoint.
        if re.fullmatch(r'(?:/poster-cache/proxy)?/poster/(movie|series)/[^/]+', parsed.path):
            fallback = parse_qs(parsed.query).get('fallback', [''])[0]
            return smaller(fallback)
    except ValueError:
        pass
    return ''


def update(addon, clock=time.monotonic):
    global _width, _checked, _upgrade_delay
    if addon.getSetting(SETTING) != '1':
        _upgrade_delay = 5.0
        _width = None
        return
    now = clock()
    if now - _checked < 1:return
    _checked = now
    try:
        from lib.network_speed import snapshot
        from lib.network_limit import connection
        sample = snapshot(addon)
        rate = sample.get('bps')
        _upgrade_delay = 5.0
        if (connection() == 'ethernet' or sample.get('status') != 'measured'
                or type(rate) not in (int, float) or not math.isfinite(rate) or rate <= 0):
            _width = None
        elif rate < 10_000_000:
            _width = 342
            _upgrade_delay = 30.0 if rate < 1_000_000 else 15.0 if rate < 3_000_000 else 5.0
        elif rate >= 15_000_000:
            _width = None
        # 10–15 Mbps retains the previous choice to avoid switching repeatedly.
    except Exception:
        _width = None


def cached(full):
    """Read only an exact texture match; never enumerate or clear Kodi artwork."""
    now = time.monotonic()
    found = _cache.get(full)
    if found and now < found[0]:return found[1]
    try:
        import xbmc
        import xbmcvfs
        result = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': 'Textures.GetTextures',
            'params': {'properties': ['url', 'cachedurl'],
                       'filter': {'field': 'url', 'operator': 'is', 'value': full}}})))
        if 'error' in result:return True  # Unknown cache state keeps full quality.
        rows = result['result']['textures']
        def exists(row):
            url = row.get('url', '')
            if url.startswith('image://'):url = unquote(url[8:].split('/', 1)[0])
            path = row.get('cachedurl', '')
            return (url == full and bool(re.fullmatch(r'[0-9a-f]/[0-9a-f]+\.(?:jpg|png)', path))
                    and xbmcvfs.exists('special://thumbnails/' + path))
        ready = any(exists(row) for row in rows)
        if len(_cache) >= 256:_cache.clear()
        _cache[full] = (now + (30 if ready else 3), ready)
        return ready
    except Exception:
        return True


def present(listing, row, full, addon):
    """Native-only state: do not persist preview URLs as preferred provider art."""
    previous = listing.getProperty('poster_source')
    if isinstance(previous, str) and previous and (previous != full or addon.getSetting(SETTING) != '1'):
        for key in ('poster_source', 'poster_pending_full', 'poster_preview', 'poster_preview_at'):
            listing.setProperty(key, '')
    if addon.getSetting(SETTING) != '1':return full
    if previous == full:
        current = listing.getArt('poster')
        if isinstance(current, str) and current:return current
    preview = preview_url(full, row, _width) if _width else ''
    if not preview or cached(full):return full
    listing.setProperty('poster_source', full)
    listing.setProperty('poster_pending_full', full)
    listing.setProperty('poster_preview', preview)
    listing.setProperty('poster_preview_at', str(time.monotonic()))
    return preview


def tick(window, addon, clock=time.monotonic):
    if window.closed:return
    enabled = addon.getSetting(SETTING) == '1'
    if not enabled and not window.__dict__.get('_fast_posters_enabled'):return
    if enabled:window._fast_posters_enabled = True
    update(addon, clock)
    if window.preview_suspended:return
    import xbmc
    if xbmc.Player().isPlaying():return
    from lib.input_guard import idle
    if not idle(window, clock):return
    now = clock()
    last = window.__dict__.get('_last_input_at')
    if type(last) not in (int, float):last = now - 5
    if now - last < _upgrade_delay or now < window.__dict__.get('_poster_upgrade_at', 0):return
    upgrading = window.__dict__.get('_poster_upgrading')
    if upgrading and now - window.__dict__.get('_poster_upgrade_started', now) < 15 and not cached(upgrading):return
    cid = window.getFocusId()
    rows = window.rows.get(cid, [])
    if not rows:return
    control = window.getControl(cid)
    pos = control.getSelectedPosition()
    # Upgrade the selected poster first, then its neighbours; no hidden rows.
    for index in [pos] + [i for i in range(max(0, pos - 3), min(len(rows), pos + 7)) if i != pos]:
        if not 0 <= index < len(rows):continue
        listing = control.getListItem(index)
        full = listing.getProperty('poster_pending_full')
        if not isinstance(full, str) or not full:continue
        try:
            if now - float(listing.getProperty('poster_preview_at')) < _upgrade_delay:continue
        except (ValueError, TypeError):continue
        # A replaced item/provider can never receive an old upgrade.
        if full != rows[index].get('poster'):continue
        listing.setProperty('poster_fallback', listing.getProperty('poster_preview'))
        listing.setArt({'poster': full, 'thumb': full})
        listing.setProperty('poster_pending_full', '')
        window._poster_upgrading = full
        window._poster_upgrade_started = now
        window._poster_upgrade_at = now + 2
        return


def preview_layers(tree):
    """Keep the small image visible underneath an asynchronously loading upgrade."""
    from copy import deepcopy
    import xml.etree.ElementTree as ET
    for parent in list(tree.iter()):
        for node in list(parent):
            if node.tag != 'control' or node.get('type') != 'image':continue
            texture = node.find('texture')
            if texture is None or texture.text != '$INFO[ListItem.Art(poster)]':continue
            preview = deepcopy(node)
            tex = preview.find('texture')
            tex.text = '$INFO[ListItem.Property(poster_preview)]'
            tex.attrib.pop('fallback', None)
            tex.set('background', 'true')
            for visible in list(preview.findall('visible')):preview.remove(visible)
            ET.SubElement(preview, 'visible').text = '!String.IsEmpty(ListItem.Property(poster_preview))'
            parent.insert(list(parent).index(node), preview)
