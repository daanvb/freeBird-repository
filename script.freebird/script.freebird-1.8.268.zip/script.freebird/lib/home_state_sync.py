"""Background Home sync under the existing private saved-list sync opt-in."""
import base64
import json
import threading
import time
from datetime import datetime, timezone
from account import Store
from pathlib import Path
from lib.credits_sync import request, SyncError, LIMIT
from lib.home_state import HomeState, clean, merge
from lib.saved_lists_sync import SavedListsSync


def legacy_removals(profile):
    """Carry forward removals made before shared Home state was introduced."""
    from lib.continue_index import removal_watermarks
    records = {}
    for key, watched in removal_watermarks(profile).items():
        try:
            instant = datetime.fromisoformat(watched.replace('Z', '+00:00'))
            if instant.tzinfo is None:
                instant = instant.replace(tzinfo=timezone.utc)
            stamp = max(0, instant.timestamp())
        except (TypeError, ValueError, OverflowError):
            stamp = 0
        records[key] = {'updated': stamp, 'lastWatched': watched}
    return clean(records)


def decode(response):
    if response is None:
        return {}, None
    try:
        raw = base64.b64decode(response['content'])
        data = json.loads(raw)
        if (response.get('encoding') != 'base64' or not isinstance(response.get('sha'), str)
                or len(raw) > LIMIT or data.get('version') != 1 or not isinstance(data.get('records'), dict)):
            raise ValueError()
        return clean(data['records']), response['sha']
    except Exception:
        raise SyncError('Invalid Home state file; remote data was kept') from None


def synchronize(memory, token, still_current=lambda: True, transport=request):
    if transport(token).get('private') is not True:
        raise SyncError('Home sync requires a private repository')
    # Like saved-lists.json, the configured private repository is the sync account.
    # Stremio can issue different login keys to clients of the same account.
    path = '/contents/home-state.json'
    for attempt in range(3):
        if not still_current(): return False
        remote, sha = decode(transport(token, path))
        if not still_current(): return False
        local = memory.merge(remote)
        if local == remote: return True
        raw = json.dumps({'version': 1, 'records': local}, sort_keys=True, separators=(',', ':')).encode()
        if len(raw) > LIMIT // 2:
            raise SyncError('Home state is too large; local state was kept')
        payload = {'message': 'Merge Home state', 'content': base64.b64encode(raw).decode()}
        if sha: payload['sha'] = sha
        if not still_current(): return False
        try:
            transport(token, path, payload)
        except SyncError:
            # Re-read and merge a competing device's write before retrying.
            if attempt == 2: raise
            continue
        verified, _ = decode(transport(token, path))
        if merge(verified, local) != verified:
            continue
        if not still_current(): return False
        memory.merge(verified)
        return True
    raise SyncError('Home upload could not be confirmed; retrying')


def summary(profile, addon):
    if addon.getSetting('lists_github_enabled') != 'true':
        return 'Off'
    if not Store(profile).load().get('token'):
        return 'Connect Stremio first'
    if not addon.getSetting('credits_github_token').strip():
        return 'Add a private GitHub sync token'
    from lib.viewer_profiles import current
    if current(profile):
        return 'Included in viewer sync'
    return str(Store(Path(profile) / 'home-state-sync').load().get('status') or 'Waiting for first sync')


class HomeStateSync(SavedListsSync):
    def __init__(self, profile, addon):
        super().__init__(profile, addon)
        self.status = Store(Path(profile) / 'home-state-sync')

    def tick(self):
        config = self.config()
        if self.busy or config[0] != 'true' or not all(config[1:]): return
        if config != self.last_config:
            self.next_check = 0
            self.last_config = config
        now = time.monotonic()
        if now < self.next_check:
            return
        memory = HomeState(self.profile, config[2])
        try:
            memory.merge(legacy_removals(self.profile))
        except Exception:
            pass
        self.busy = True
        self.next_check = now + 60
        self.last_push = now
        try:
            threading.Thread(target=self.run, args=(config, memory), daemon=True).start()
        except RuntimeError:
            self.busy = False

    def run(self, config, memory):
        try:
            before = memory.snapshot()
            if synchronize(memory, config[1], lambda: self.config() == config):
                after = memory.snapshot()
                self.signature = json.dumps(after, sort_keys=True)
                self.status.save({'status': 'Synced with private GitHub', 'last_sync': time.time()})
                if after != before:
                    import xbmcgui
                    xbmcgui.Window(10000).setProperty('strem4kodi.home.recommendations.revision', str(time.time_ns()))
        except SyncError as error:
            self.status.save({'status': str(error)})
        except Exception:
            try: self.status.save({'status': 'Sync will retry; local Home state was kept'})
            except Exception: pass
        finally:
            self.busy = False
