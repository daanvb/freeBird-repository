"""Sort duration choices for display without renumbering saved enum values."""
from lib.cache_policy import parse_duration


def order(values):
    keys = []
    for value in values:
        text = str(value).strip().lower()
        if text in ('kodi default', 'automatic'):
            seconds = -1
        elif text == 'immediately':
            seconds = 0
        else:
            try:
                seconds = parse_duration(text)
            except ValueError:
                # This is not a duration picker (e.g. source quality).
                return list(range(len(values)))
        keys.append(float('inf') if seconds is None else seconds)
    return sorted(range(len(values)), key=keys.__getitem__)
