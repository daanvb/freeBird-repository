"""Prepare Kodi's softly softened backdrop for translucent glass controls."""

from urllib.parse import quote, unquote


def frosted_sidebar(artwork):
    """A strongly softened artwork layer, used only inside the drawer mask.

    Kodi caches this tiny texture separately and smoothly enlarges it. This
    is an artwork approximation, not a capture/blur of live video or controls.
    Empty/unsupported artwork uses the drawer's opaque fallback underneath.
    """
    artwork = str(artwork or '').strip()
    if artwork.startswith('image://'):
        artwork = unquote(artwork[len('image://'):].split('/', 1)[0])
    if not artwork.startswith(('http://', 'https://', 'special://', 'file://')):
        return ''
    return ('image://' + quote(artwork, safe='')
            + '/transform?width=32&height=18&scaling_algorithm=bilinear')


def blurred_background(artwork, width=768, height=432):
    """Return a cacheable, gently softened Kodi backdrop.

    Kodi cannot blur the pixels behind an individual control. This mild
    full-screen transform lets translucent controls read as frosted glass
    without the severe smearing caused by the former 64x36 transform.
    """
    artwork = str(artwork or '').strip()
    if not artwork:
        return ''
    if artwork.startswith('image://'):
        artwork = unquote(artwork[len('image://'):].split('/', 1)[0])
    if not artwork.startswith(('http://', 'https://', 'special://', 'file://')):
        return artwork
    try:
        width = max(256, min(1920, int(width)))
        height = max(144, min(1080, int(height)))
    except (TypeError, ValueError):
        width, height = 768, 432
    return ('image://' + quote(artwork, safe='') + '/transform?width=' + str(width)
            + '&height=' + str(height) + '&scaling_algorithm=bilinear')
