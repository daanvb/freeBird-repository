"""Immutable source items and batch-local numeric creation measurements."""
import time


def _thread_time():
    try:
        return time.thread_time()
    except (AttributeError, OSError, NotImplementedError):
        return None


class ItemBuilder:
    def __init__(self, timing=None):
        self.timing = timing
        self.metrics = {}

    def _add(self, key, value):
        self.metrics[key] = self.metrics.get(key, 0) + value

    def create(self, factory, label, properties):
        # Missing properties read as empty on a new Kodi item. Release names
        # remain on source rows and in the reuse signature/details dialog; the
        # skin never reads stream_release. Never use this to mutate old items.
        values = {key: value for key, value in properties
                  if value and key != 'stream_release'}
        if self.timing is None:
            item = factory(label, offscreen=True)
            if values:item.setProperties(values)
            return item
        cpu_start = _thread_time()
        started = time.monotonic()
        item = factory(label, offscreen=True)
        constructed = time.monotonic()
        if values:item.setProperties(values)
        finished = time.monotonic()
        cpu_end = _thread_time()
        elapsed = (finished - started) * 1000
        self._add('item_construct_ms', (constructed - started) * 1000)
        self._add('item_properties_ms', (finished - constructed) * 1000)
        self._add('item_create_ms', elapsed)
        self._add('item_property_values', len(values))
        if cpu_start is not None and cpu_end is not None:
            cpu = max(0, (cpu_end - cpu_start) * 1000)
            self._add('item_create_cpu_ms', cpu)
            self._add('item_create_wait_ms', max(0, elapsed - cpu))
            self._add('item_cpu_samples', 1)
        return item

    def flush(self):
        # Avoid taking the shared report lock for every item while provider
        # workers are also publishing timing/progress updates.
        if self.timing is not None:
            for key, value in self.metrics.items():self.timing.add(key, value)
        self.metrics.clear()
