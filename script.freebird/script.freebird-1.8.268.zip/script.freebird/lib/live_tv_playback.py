"""Kodi 21 live playback entry; independent of movie/series progress."""
import json
import re
from urllib.request import urlopen

from lib.live_tv_provider import CHANNELS, CHANNEL_IDS, BBC_IDS
from lib.live_tv_quality import HDUnavailable


def check_widevine():
    try:
        import inputstreamhelper
        if inputstreamhelper.Helper('mpd', drm='com.widevine.alpha').check_inputstream():
            return
    except Exception:
        pass
    raise HDUnavailable('Widevine is required. Open Live TV setup to check playback support.')


def prepare(endpoint, channel):
    try:
        with urlopen(endpoint + channel + '.json', timeout=55) as response:
            raw = response.read(4097)
        if len(raw) > 4096:
            raise ValueError('size')
        return json.loads(raw)
    except Exception:
        raise HDUnavailable('No HD stream available. Check your UK connection and broadcaster sign-in.') from None


def resolve(channel, handle, kodi, gui, plugin, addon_module):
    item = gui.ListItem()
    try:
        if channel not in CHANNEL_IDS:
            raise ValueError('Unknown channel')
        addon_module.Addon('inputstream.adaptive')
        if channel not in BBC_IDS:
            check_widevine()
            if channel.startswith('itv'):
                from lib.live_tv_accounts import ITVAccount
                ITVAccount().token()
        window = gui.Window(10000)
        window.clearProperty('s4k.live.endpoint')
        window.setProperty('s4k.live.request', 'true')
        monitor = kodi.Monitor()
        endpoint = ''
        for _ in range(40):
            endpoint = window.getProperty('s4k.live.endpoint')
            if endpoint:
                break
            if monitor.waitForAbort(0.1):
                raise ValueError('Cancelled')
        if not re.fullmatch(r'http://127\.0\.0\.1:[0-9]{1,5}/[0-9a-f]{48}/', endpoint):
            raise ValueError('Live service unavailable')
        if channel not in BBC_IDS:
            metadata = prepare(endpoint, channel)
            if monitor.abortRequested():
                raise ValueError('Cancelled')
            if metadata.get('widevine'):
                item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
                item.setProperty('inputstream.adaptive.license_key', endpoint + channel + '.license||R{SSM}|R')
        item.setPath(endpoint + channel + '.mpd')
        item.setLabel(dict(CHANNELS)[channel])
        from lib.live_tv_art import channel_icon
        item.setArt({'icon': channel_icon(channel), 'thumb': channel_icon(channel)})
        item.setMimeType('application/dash+xml')
        item.setContentLookup(False)
        item.setProperty('inputstream', 'inputstream.adaptive')
        item.setProperty('IsPlayable', 'true')
        item.setProperty('StartOffset', '0')
        item.setProperty('script.trakt.exclude', '1')
        item.setProperty('s4k.live', 'true')
        plugin.setResolvedUrl(handle, True, item)
    except Exception as error:
        plugin.setResolvedUrl(handle, False, gui.ListItem())
        message = str(error) if isinstance(error, HDUnavailable) else 'Live TV unavailable. Check InputStream Adaptive and retry.'
        gui.Dialog().notification('Live TV', message)


def setup(gui, addon_module=None):
    from lib.ui_dialogs import dialog
    selected = dialog().select('Live TV setup', ['Sign in to ITVX', 'Sign out of ITVX', 'Check Widevine playback support', 'BBC picture quality'])
    try:
        if selected == 0:
            email = gui.Dialog().input('ITVX email')
            if not email:
                return
            password = gui.Dialog().input('ITVX password', option=gui.ALPHANUM_HIDE_INPUT)
            if not password:
                return
            from lib.live_tv_accounts import ITVAccount
            ITVAccount().login(email.strip(), password)
            gui.Dialog().notification('Live TV', 'ITVX signed in on this device.')
        elif selected == 1:
            from lib.live_tv_accounts import ITVAccount
            ITVAccount().logout()
            gui.Dialog().notification('Live TV', 'ITVX signed out on this device.')
        elif selected == 2:
            check_widevine()
            gui.Dialog().notification('Live TV', 'Widevine playback support is ready.')
        elif selected == 3:
            quality = dialog().select('BBC picture quality', ['Prefer 1080p (HEVC)', '720p compatibility mode'])
            if quality in (0, 1):
                if addon_module is None:
                    import xbmcaddon as addon_module
                addon_module.Addon('script.freebird').setSetting('live_tv_bbc_hevc', 'true' if quality == 0 else 'false')
                gui.Dialog().notification('Live TV', 'BBC quality applies when you next open a channel.')
    except Exception:
        gui.Dialog().notification('Live TV', 'Setup failed. Check your account details and playback support.')


def show(kodi, gui, addon_module):
    """Open the built-in schedule; playback retains HD manifest validation."""
    from lib.live_tv_guide import show as show_guide
    return show_guide(kodi, gui, addon_module)
