from addon_state import get_addon
import xbmcgui
from lib.theme import window as themed_window

ADDON = get_addon()
ADDON_PATH = ADDON.getAddonInfo('path')
SKIN = 'Main'
RES = '1080i'
SESSION_WINDOW_ID = 10000
APP_RUNNING = 'stremioforkodi.running'


def run(started=None):
    from lib.perf_trace import now, log
    started = now() if started is None else started
    from lib.launch_guard import LaunchGuard, mark_window, unmark_window
    guard = LaunchGuard()
    if not guard.acquire():
        return
    from lib import startup_trace
    startup_trace.begin(started)
    confirmed_exit = False
    closing_window_id = None
    diagnostic_profile = None
    navigation_cover = None
    startup_cover = None
    try:
        from lib.navigation_cover import startup
        startup_cover=startup()
        startup_trace.mark('splash')
        from lib.perf_report import begin_launch
        session = xbmcgui.Window(SESSION_WINDOW_ID)
        from lib.browse_background import starting
        starting(session)
        first_launch = session.getProperty('strem4kodi.startup.seen') != 'true'
        begin_launch(first_launch)
        startup_trace.kind(first_launch)
        session.setProperty('strem4kodi.startup.seen', 'true')
        from lib.playback_settings import apply
        from lib.error_report import show_reporting_notice_once
        apply()
        show_reporting_notice_once()
        startup_trace.mark('settings')
        from lib.signin import signed_in, show_signin
        if not signed_in():
            startup_cover.finish()
            from lib.device_setup_ui import first_run
            if not first_run():return
        from lib.device_setup_ui import activate_pending_skin
        activate_pending_skin(before_apply=startup_cover.finish)
        if not signed_in():
            startup_cover.finish()
            if not show_signin():return
        if startup_cover.closed is True:startup_cover=startup()
        startup_trace.mark('account')
        # Heavy window/provider imports happen behind the local branded cover.
        from lib.nimbus import HomeWindow, InfoWindow
        import xbmcvfs
        from lib import backend
        from lib.ui_crash import begin, phase, finish
        diagnostic_profile = backend.STORE.directory
        from lib.diagnostic_events import install
        install(diagnostic_profile)
        startup_trace.mark('imports')
        begin(diagnostic_profile, guard.token)
        from lib.home_layout import build_layout
        from lib.appearance import options
        # Startup is stale-while-revalidate: never hold the UI behind catalog
        # network requests. HomeWindow refreshes account/catalog data in background.
        rows = backend.account_home(False, allow_background=False)
        startup_trace.mark('cached_home')
        layout_started = now()
        filename, path, count = build_layout(
            ADDON_PATH,
            xbmcvfs.translatePath(ADDON.getAddonInfo('profile')),
            max(8, len(rows), backend.account_home_capacity()),
            options(ADDON)
        )
        log('startup.layout', layout_started, profile=xbmcvfs.translatePath(ADDON.getAddonInfo('profile')), rows=count)
        startup_trace.mark('layout')
        browse_state = None
        search_result = None
        while True:
            phase(diagnostic_profile, 'home.allocate')
            window = HomeWindow(filename, path, SKIN, RES, account_rows=rows, row_count=count, browse_state=browse_state, search_result=search_result, launch_started=started, startup_cover=startup_cover)
            search_result = None
            mark_window(window, 'home')
            try:
                phase(diagnostic_profile, 'home.modal')
                import xbmc
                from lib.native_window import modal
                if not modal(window,xbmc,xbmcgui):
                    raise RuntimeError('Kodi could not open the Home screen. Please try again.')
                phase(diagnostic_profile, 'home.return')
                reload_appearance = getattr(window, 'reload_appearance', False)
                browse_state = getattr(window, 'reload_browse_state', None)
                reload_cover = window.__dict__.get('reload_cover')
                if reload_cover is not None:
                    startup_cover = reload_cover
                details_request = getattr(window, 'details_request', None)
                navigation_cover = window.__dict__.get('_navigation_cover')
                handoff_window_id = getattr(window, 'handoff_window_id', None)
                confirmed_exit = getattr(window, 'exit_requested', False) is True
                closing_window_id = getattr(window, 'exit_window_id', None)
            finally:
                unmark_window(window)
            handed_off = isinstance(details_request, dict)
            retired = True
            if handed_off and type(handoff_window_id) is int:
                import xbmc
                # Keep the Python/native window alive while Close is queued.
                # Deleting it first frees its ID for the next window; a delayed
                # Close can then target that newly allocated title instead.
                from lib.native_window import wait_retired
                retired = wait_retired(handoff_window_id, xbmc, xbmcgui)
                if not retired:
                    phase(diagnostic_profile, 'home.retire.timeout')
            del window
            if not retired:
                break
            while isinstance(details_request, dict):
                details_request = dict(details_request)
                search_origin = details_request.pop('search_origin', None)
                if navigation_cover is not None:
                    details_request['navigation_cover']=navigation_cover
                phase(diagnostic_profile, 'details.allocate')
                details = themed_window(InfoWindow, 'script-stremio-info.xml',
                                        ADDON_PATH, SKIN, RES, shell_return=True, **details_request)
                mark_window(details, 'info')
                from lib.runtime_trace import navigation
                navigation(details, 'details.allocated')
                try:
                    phase(diagnostic_profile, 'details.modal')
                    if not modal(details,xbmc,xbmcgui):
                        details.load_failed=True
                        phase(diagnostic_profile, 'details.activate.failed')
                    phase(diagnostic_profile, 'details.return')
                finally:
                    if (getattr(details, 'load_failed', False) is True
                            and isinstance(browse_state, dict)):
                        browse_state['return_status'] = 'Unable to open this title. Please try again.'
                    unmark_window(details)
                    if navigation_cover is not None:navigation_cover.finish()
                    # Info paints the return cover before closing. Keep it
                    # through native retirement and rebuilding the next window.
                    return_cover=details.__dict__.get('_return_cover')
                    if return_cover is not None:
                        navigation_cover=return_cover
                        startup_cover=return_cover
                    import xbmc
                    from lib.native_window import wait_retired
                    details_retired = wait_retired(getattr(details, '_context_window_id', None), xbmc, xbmcgui)
                    if not details_retired:
                        phase(diagnostic_profile, 'details.retire.timeout')
                    del details
                details_request = None
                if not details_retired:
                    handed_off = False
                    reload_appearance = False
                    break
                if isinstance(search_origin, dict):
                    # The typing dialog is restored by the shell after details
                    # closes. No live Home window sits underneath either one.
                    from lib.search_box import show
                    phase(diagnostic_profile, 'search.modal')
                    query = show(backend.STORE.directory, backend.suggestions,
                                 state=search_origin,
                                 catalogue_searcher=backend.suggestion_collections,
                                 ready_cover=navigation_cover)
                    phase(diagnostic_profile, 'search.return')
                    if isinstance(query, dict) and isinstance(query.get('_search_origin'), dict) and not query.get('_catalogue'):
                        details_request = dict(meta={k:v for k,v in query.items() if k != '_search_origin'},
                                               return_to_search=True, search_origin=query['_search_origin'])
                    elif query:
                        search_result = query
                    else:
                        browse_state = None
                if details_request is not None:
                    continue
            if handed_off:
                # Recreate the originating grid from its loaded rows/selection.
                # The details WindowXML is fully destroyed first, avoiding the
                # overlapping full-window lifetime that crashes some devices.
                continue
            if not reload_appearance:
                break
            rows=backend.account_home(False)
            filename, path, count = build_layout(
                ADDON_PATH, xbmcvfs.translatePath(ADDON.getAddonInfo('profile')),
                max(8, len(rows), backend.account_home_capacity()), options(ADDON))
    finally:
        from lib.browse_background import ready
        ready(xbmcgui.Window(SESSION_WINDOW_ID))
        if startup_cover is not None:startup_cover.finish()
        if navigation_cover is not None:navigation_cover.finish()
        if diagnostic_profile is not None:
            import sys
            finish(diagnostic_profile, guard.token, sys.exc_info()[1])
        try:
            if confirmed_exit:
                # Exit returns to Kodi Home, rather than the addon launcher
                # underneath the modal. Keep the lease until navigation finishes.
                import xbmc
                # doModal can return before Kodi handles its queued native
                # previous-window message. Let that restore the launcher first.
                for _ in range(20):
                    if (xbmcgui.getCurrentWindowId() != closing_window_id
                            and not xbmc.getCondVisibility('System.HasVisibleModalDialog')):
                        break
                    xbmc.sleep(50)
                guard.defer_relaunch()
                xbmc.executebuiltin('ActivateWindow(Home)', True)
        finally:
            guard.release()
