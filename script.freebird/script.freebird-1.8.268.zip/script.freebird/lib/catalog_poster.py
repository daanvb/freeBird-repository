"""Resolve preferred posters independently of catalogue membership."""
import hashlib
import re
import time
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED

from addons_core import active_addons
from protocol import fetch, resource_url
from sources import supports
from provider_roles import artwork_providers, name, selected, key as provider_key
from lib.catalogue_identity import identity, aliases, share_missing, ARTWORK_FIELDS
from lib.poster_enhancement import ARTWORK_GENERATION, legacy_art


def fallback(row):
    """An independent image when the configured poster server fails."""
    if row.get('_artwork_pending'):
        return 'special://home/addons/script.freebird/resources/skins/Main/media/DefaultMovies.png'
    original = row.get('_original_poster')
    if isinstance(original, str) and original.startswith(('https://', 'http://')) and original != row.get('poster') and not legacy_art(original):
        return original
    from lib.list_artwork import details
    cover=details(row)
    if cover:return cover['poster']
    title = identity(row)
    if title and re.fullmatch(r'tt\d+', title[1]):
        return 'https://images.metahub.space/poster/medium/' + title[1] + '/img'
    return 'special://home/addons/script.freebird/resources/skins/Main/media/DefaultMovies.png'


def resolved(artwork, signature):
    """A completed lookup can supply useful artwork without supplying a poster."""
    result = dict(artwork, _artwork_pending=False, _poster_signature=signature)
    if not artwork.get('poster'):
        result.update(_poster_fallback=True, _poster_preferred=True)
        result.setdefault('_poster_provider', 'Fallback after provider lookup')
        result.setdefault('_poster_resolved_at', time.time())
    return result


def retain_preferred(catalogs, current, signature):
    """Progress/snapshot updates must not replace newer resolved artwork."""
    known = {}
    for row in current:
        title = identity(row)
        if (title and row.get('poster') and row.get('_poster_preferred')
                and row.get('_poster_signature') == signature):
            previous = known.get(title)
            if (previous is None or (previous.get('_poster_fallback') and not row.get('_poster_fallback')) or
                    (bool(previous.get('_poster_fallback')) == bool(row.get('_poster_fallback'))
                     and row.get('_poster_resolved_at', 0) > previous.get('_poster_resolved_at', 0))):
                known[title] = row
    result = []
    for catalog in catalogs:
        items = []
        for row in catalog.get('items', []):
            preferred = known.get(identity(row))
            incoming_current = row.get('_poster_signature') == signature and row.get('_poster_preferred')
            if preferred and (not incoming_current or
                              (row.get('_poster_fallback') and not preferred.get('_poster_fallback')) or
                              row.get('_poster_resolved_at', 0) < preferred.get('_poster_resolved_at', 0)):
                row = dict(row, **{key: preferred[key] for key in ARTWORK_FIELDS if key in preferred})
                row['_poster_fallback'] = bool(preferred.get('_poster_fallback'))
                row['_artwork_pending'] = False
            items.append(row)
        result.append(dict(catalog, items=items))
    return result


class Posters:
    def __init__(self, state, cache=None, fetcher=None, cache_ttl=900):
        self.providers = artwork_providers(state)
        self.explicit = selected(state, 'artwork') is not None
        self.trust_catalog = not state.get('artworkRevision')
        self.signature = hashlib.sha256(repr((ARTWORK_GENERATION, [p.get('transportUrl') for p in self.providers],
                                               state.get('artworkRevision', 0))).encode()).hexdigest()
        self.request_scope = hashlib.sha256(str(state.get("token") or "").encode()).hexdigest()
        self.fetch_identity = fetcher
        self.cache = cache
        self.cache_ttl = cache_ttl
        # Configured metadata may need to resolve IDs and generate custom art.
        # This runs off the UI thread; use the normal metadata request budget.
        self.fetcher = fetcher
        self.response_scope = (ARTWORK_GENERATION, state.get("artworkRevision", 0))

    def key(self, title):
        return 'configured-poster-v3:' + self.signature + ':' + title[0] + ':' + title[1]

    def known(self, catalogs, include_catalog=True):
        result = {}
        if not self.providers:
            return result
        titles = {}
        keys = {provider_key(p) for p in self.providers}
        urls = {p.get('transportUrl') for p in self.providers}
        for catalog in catalogs:
            for row in catalog.get('items', []):
                title = identity(row)
                if self.cache is not None and title and title not in titles:
                    titles[title] = self.key(title)
                owner = catalog.get('addon') or row.get('_poster_provider') or ''
                current = (catalog.get('url') in urls if catalog.get('url') else
                           row.get('_artwork_source') in keys)
                if (include_catalog and title and row.get('poster') and current and self.trust_catalog
                        and (not row.get('_poster_signature') or row['_poster_signature'] == self.signature)
                        and (not legacy_art(row['poster']) or row.get('_artwork_generation') == ARTWORK_GENERATION)):
                    result.setdefault(title, {**{field: row[field] for field in ('poster', 'background', 'landscape', 'logo') if row.get(field)}, '_poster_provider': owner,
                                              '_poster_preferred': True, '_poster_response': 'Provider catalogue',
                                              '_poster_signature': self.signature, '_poster_resolved_at': 0,
                                              '_artwork_source': row.get('_artwork_source') or next(
                                                  (provider_key(p) for p in self.providers if p.get('transportUrl') == catalog.get('url')), ''),
                                              '_artwork_generation': ARTWORK_GENERATION})
        if titles:
            try:
                bulk = self.cache.get_many(set(titles.values())) if hasattr(self.cache, 'get_many') else None
            except Exception:
                bulk = {}
            for title, key in titles.items():
                try:
                    cached = bulk.get(key) if bulk is not None else self.cache.get(key)
                    expires = cached.get('expires', 0) if isinstance(cached, dict) else 0
                    if isinstance(cached, dict) and (expires is None or expires > time.time()):
                        artwork = cached.get('artwork') or {}
                        result[title] = resolved(artwork, self.signature)
                        result[title]['_poster_response'] = 'Cached provider response'
                except Exception:
                    pass
        return result

    @staticmethod
    def apply(catalogs, known):
        def apply_row(row):
            result = dict(row)
            artwork = known.get(identity(row))
            if artwork is not None:
                saved = result.pop('_fallback_artwork', {})
                for field, value in saved.items():
                    if not result.get(field):result[field] = value
                result.update(artwork)
                result['_artwork_pending'] = False
            return result
        return [dict(catalog, items=[apply_row(row) for row in catalog.get('items', [])]) for catalog in catalogs]

    def cached(self, catalogs):
        known = self.known(catalogs)
        result = self.apply(catalogs, known)
        if not self.providers:
            return result
        fields = ('poster', 'background', 'landscape', 'landscapePoster', 'logo', 'thumbnail')
        for catalog in result:
            for row in catalog.get('items', []):
                title = identity(row)
                if not title or title in known or row.get('_metadata_checked_signature') == self.signature:
                    continue
                if (row.get('_poster_signature') == self.signature and row.get('_poster_preferred')):
                    continue
                row.setdefault('_fallback_artwork', {field: row[field] for field in fields if row.get(field)})
                for field in fields:
                    row[field] = ''
                row['_poster_preferred'] = False
                row['_artwork_pending'] = True
        return result

    def refresh(self, catalogs, cancelled=lambda: False, priority=None):
        caller_cancelled = cancelled
        cancelled = lambda: (caller_cancelled() or (self.cache is not None
                             and not getattr(self.cache, 'current', lambda: True)()))
        # Catalogue/snapshot artwork is held behind neutral placeholders until
        # the configured metadata endpoint has answered.
        known = self.known(catalogs, include_catalog=False)
        pending = []
        request_ids = {}
        for catalog in catalogs:
            for row in catalog.get('items', []):
                title = identity(row)
                if title and title not in known and title not in request_ids:
                    pending.append(title)
                    # Canonical aliases are cache keys; preserve a provider's
                    # original non-IMDb request syntax (e.g. tmdb:tv:007).
                    original = row.get('id') or row.get('_id')
                    request_ids[title] = title[1] if re.fullmatch(r'tt\d+', title[1]) else str(original or title[1])
        if not self.providers or not pending:
            return

        def lookup(title):
            from lib.artwork_requests import resolve
            scope = (self.request_scope, self.signature, getattr(self.cache, "path", None),
                     getattr(self.cache, "generation", ()), self.cache_ttl, self.fetch_identity, title)
            return title, resolve(scope, lambda abandoned: request(title, abandoned), cancelled)

        def request(title, abandoned):
            if abandoned():
                return {}
            kind, _ = title
            media_id = request_ids[title]
            for provider in self.providers:
                if abandoned():return {}
                if not supports(provider.get('manifest') or {}, kind, media_id, 'meta'):
                    continue
                try:
                    url = resource_url(provider['transportUrl'], 'meta', kind, media_id)
                    response_info = {}
                    payload = (self.fetcher(url) if self.fetcher else
                               fetch(url, timeout=15, cache_info=response_info,
                                     refresh=title in retries, cache_scope=self.response_scope))
                    meta = payload.get('meta') if isinstance(payload, dict) else None
                    if (isinstance(meta, dict) and meta.get('type', kind) == kind
                            and title in aliases(dict(meta, type=kind))):
                        artwork = {'_poster_provider': name(provider), '_poster_preferred': True,
                                       '_poster_fallback': False,
                                       '_artwork_source': provider_key(provider),
                                       '_poster_response': 'Fresh provider response', '_poster_signature': self.signature,
                                       '_poster_resolved_at': time.time(), '_artwork_generation': ARTWORK_GENERATION}
                        for field in ('poster', 'logo', 'background', 'landscape'):
                            value = meta.get(field) or (meta.get('landscapePoster') if field == 'landscape' else None)
                            if isinstance(value, str) and value.startswith(('https://', 'http://')):
                                artwork[field] = value
                        if any(field in artwork for field in ('poster', 'logo', 'background', 'landscape')):
                            if 'expires' in response_info:
                                artwork['_response_expires'] = response_info['expires']
                            return artwork
                except Exception:
                    # URLs may contain private configuration: never log them.
                    continue
            return {}

        # Four in-flight jobs, refilled as each finishes. A slow title cannot
        # hold the next page behind an eight-title batch barrier.
        with ThreadPoolExecutor(max_workers=4) as pool:
            futures = set()
            retries, delayed = set(), {}
            dirty, published = False, 0.0
            while pending or futures or delayed:
                if cancelled():
                    for future in futures:future.cancel()
                    return
                visible = set(priority() or ()) if priority else set()
                for title, due in list(delayed.items()):
                    if title not in visible:
                        del delayed[title]
                    elif time.monotonic() >= due:
                        pending.insert(0, title)
                        del delayed[title]
                if priority and pending and len(futures) < 4:
                    preferred = {title: index for index, title in enumerate(priority() or ())}
                    pending.sort(key=lambda title: preferred.get(title, len(preferred)))
                while pending and len(futures) < 4:
                    if cancelled():break
                    futures.add(pool.submit(lookup, pending.pop(0)))
                if not futures:
                    if delayed:
                        time.sleep(.05)
                        continue
                    return
                ready, futures = wait(futures, timeout=.05, return_when=FIRST_COMPLETED)
                if cancelled():
                    for future in futures:future.cancel()
                    return
                for future in ready:
                    title, artwork = future.result()
                    response_expires = artwork.pop("_response_expires", None)
                    if not artwork.get('poster') and title in visible and title not in retries:
                        # Publish fallback immediately, then retry only the focus/look-ahead
                        # window once. Do not hold a network slot during the backoff.
                        retries.add(title)
                        delayed[title] = time.monotonic() + 1.0
                    previous = known.get(title, {})
                    artwork = dict(previous, **artwork)
                    if self.cache is not None:
                        ttl = self.cache_ttl if artwork.get('poster') else 60
                        try:
                            expires = None if ttl is None else time.time() + ttl
                            if response_expires is not None:
                                expires = response_expires if expires is None else min(expires, response_expires)
                                ttl = max(0, expires - time.time())
                            self.cache.put(self.key(title), {'artwork': artwork, 'expires': expires}, ttl)
                        except Exception:
                            pass
                    known[title] = resolved(artwork, self.signature)
                dirty = dirty or bool(ready)
                if dirty and (not futures and not pending or time.monotonic() - published >= .05):
                    dirty, published = False, time.monotonic()
                    yield self.apply(catalogs, known)



def configured(state):
    from lib.cache_policy import open_cache, read_policy
    try:
        from addon_state import get_addon
        import xbmcvfs
        from lib.provider_config import state as provider_state
        state = provider_state(xbmcvfs.translatePath(get_addon().getAddonInfo('profile')), state)
    except (ImportError, AttributeError):
        pass
    policy = read_policy()
    posters = Posters(state, cache_ttl=policy['metadata'])
    if posters.providers:
        posters.cache = open_cache('metadata', policy)
    return posters
