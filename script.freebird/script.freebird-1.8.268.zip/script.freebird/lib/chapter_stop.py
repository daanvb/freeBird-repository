"""Session-only chapter stopping point; never persists source URLs or timers."""
import hashlib
import json
import math
import queue
import threading
import uuid
from datetime import datetime, timedelta

from lib.player_chapter_timeline import load, timestamp, valid

SESSION = 'strem4kodi.chapter_stop.session'
REQUEST = 'strem4kodi.chapter_stop.request'


def digest(file):
    return hashlib.sha256(file.encode()).hexdigest()


def finish(end, position, now=None):
    return ((now or datetime.now()) + timedelta(seconds=max(0, end-position))).strftime('%H:%M:%S')


def chapter_end(rows, index, duration):
    return rows[index+1]['start'] if index+1 < len(rows) else duration


def choose(player, kodi, home, rpc, picker):
    """Publish a selection only while the service still owns the same session."""
    file = player.getPlayingFile()
    session = home.getProperty(SESSION)
    try:
        if json.loads(session)['file'] != digest(file):
            return
    except (ValueError, KeyError, TypeError):
        picker.ok('Watch until chapter', 'Playback is not ready. Please try again.')
        return
    duration, position = player.getTotalTime(), player.getTime()
    rows = load(rpc, kodi.getInfoLabel, duration, file)
    choices = [i for i in range(len(rows)) if chapter_end(rows, i, duration) > position]
    if not choices and not home.getProperty(REQUEST):
        picker.ok('Watch until chapter', 'No usable chapter timings are available for this stream.')
        return
    def labels():
        position = player.getTime()
        return ['Continue whole video | Cancel the chapter stopping point'] + [
            '{} | Ends at {} · approximately {}'.format(rows[i]['name'],
                timestamp(chapter_end(rows, i, duration)),
                finish(chapter_end(rows, i, duration), position)) for i in choices]
    from lib.player_controls import AudioDialog
    options = {'refresh': labels} if isinstance(picker, AudioDialog) else {}
    selected = picker.select('Watch until chapter', labels(), preselect=-1, **options)
    if (home.getProperty(SESSION) != session or not player.isPlayingVideo()
            or player.getPlayingFile() != file):
        return
    if selected == 0:
        home.clearProperty(REQUEST)
    elif 0 < selected <= len(choices):
        index = choices[selected-1]
        if chapter_end(rows, index, duration) <= player.getTime():
            picker.ok('Watch until chapter', 'That chapter has already ended. Choose a later chapter.')
            return
        home.setProperty(REQUEST, json.dumps(dict(session=session, rows=rows,
                         duration=duration, index=index, nonce=uuid.uuid4().hex)))


class Watcher:
    def __init__(self, player, kodi, home, up_next, factory=None):
        self.player, self.kodi, self.home, self.up_next = player, kodi, home, up_next
        self.factory = factory or create_window
        self.lock = threading.RLock()
        self.actions = queue.SimpleQueue()
        self.identity = self.session = self.raw = self.plan = self.window = None
        self.suppressed = None
        self.hidden = False
        self.close()

    def current(self):
        try:
            if self.player.isPlayingVideo():
                return (digest(self.player.getPlayingFile()), self.player._track_session)
        except (RuntimeError, AttributeError):
            pass
        return None

    def dismiss_window(self):
        window, self.window = self.window, None
        if window:
            window.close()

    def clear(self, resume=False):
        self.dismiss_window()
        self.home.clearProperty(REQUEST)
        if resume and self.suppressed is not None:
            self.up_next.dismissed = self.suppressed
        self.suppressed = None
        self.plan = self.raw = None
        self.hidden = False

    def close(self):
        with self.lock:
            self.clear(resume=True)
            self.home.clearProperty(SESSION)
            self.identity = self.session = None

    def action(self, action, raw):
        with self.lock:
            if (not self.plan or raw != self.raw or self.home.getProperty(REQUEST) != raw
                    or self.current() != self.identity):
                return
            if action == 'continue':
                self.clear(resume=True)
            elif action == 'stop':
                self.clear()
                self.player.stop()
            elif action == 'defer' and self.plan['index']+1 < len(self.plan['rows']):
                self.plan['index'] += 1
                self.raw = json.dumps(self.plan)
                self.home.setProperty(REQUEST, self.raw)
                self.dismiss_window()
                self.hidden = False
            elif action in ('hide', 'end'):
                self.hidden = True
                self.dismiss_window()

    def tick(self):
        with self.lock:
            identity = self.current()
            if identity != self.identity:
                self.clear()
                self.identity = identity
                self.session = json.dumps(dict(file=identity[0], token=uuid.uuid4().hex)) if identity else None
                if self.session:
                    self.home.setProperty(SESSION, self.session)
                else:
                    self.home.clearProperty(SESSION)
            # Kodi input must never wait on this lock while the service is
            # making native window/player calls. Apply choices on this thread.
            while True:
                try:
                    action, request = self.actions.get_nowait()
                except queue.Empty:
                    break
                self.action(action, request)
            if not identity:
                return
            raw = self.home.getProperty(REQUEST)
            if raw != self.raw:
                self.clear(resume=True)
                if not raw:
                    return
                try:
                    plan = json.loads(raw)
                    duration = float(plan['duration'])
                    rows = valid([dict(time=r['start'], name=r['name']) for r in plan['rows']], duration)
                    if (plan['session'] != self.session or not rows or type(plan['index']) is not int
                            or not 0 <= plan['index'] < len(rows)
                            or abs(duration-self.player.getTotalTime()) > 2):
                        return
                except (ValueError, TypeError, KeyError, OverflowError):
                    return
                plan.update(rows=rows, duration=duration)
                self.plan, self.raw = plan, raw
                self.home.setProperty(REQUEST, raw)
                self.suppressed = getattr(self.up_next, 'dismissed', False)
                self.up_next.close()
                self.up_next.dismissed = True
            if not self.plan:
                return
            # Keep automatic episode handoffs suppressed for the whole plan.
            self.up_next.dismissed = True
            position = self.player.getTime()
            if not math.isfinite(position):
                return
            end = chapter_end(self.plan['rows'], self.plan['index'], self.plan['duration'])
            if position >= end:
                self.action('stop', self.raw)
                return
            if end-position > 30:
                self.dismiss_window()
                self.hidden = False
                return
            if self.hidden:
                return
            if self.window is None:
                self.window = self.factory(
                    lambda action, request=self.raw: self.actions.put((action, request)))
                self.window.show()
            row = self.plan['rows'][self.plan['index']]
            following = self.plan['index']+1 < len(self.plan['rows'])
            next_end = chapter_end(self.plan['rows'], self.plan['index']+1, self.plan['duration']) if following else end
            self.window.setProperty('chapter_stop_title', row['name'])
            self.window.setProperty('chapter_stop_detail', 'Stops in {}s · approx. {} · video {}'.format(
                math.ceil(end-position), finish(end, position), timestamp(end)))
            self.window.setProperty('chapter_stop_next', 'Defer · next chapter ends ' + finish(next_end, position)
                                    if following else 'No later chapter')
            self.window.setProperty('chapter_stop_can_defer', 'true' if following else 'false')


def create_window(callback):
    import xbmcgui
    from addon_state import get_addon
    from lib.theme import window

    class Prompt(xbmcgui.WindowXMLDialog):
        submitted = False

        def onInit(self):
            self.setFocusId(201)

        def submit(self, action):
            if self.submitted:
                return
            self.submitted = True
            callback(action)
            self.close()

        def onClick(self, cid):
            action = {201: 'continue', 202: 'defer', 203: 'end'}.get(cid)
            if action:
                self.submit(action)

        def onAction(self, action):
            if action.getId() in (10, 92, 216, 247):
                self.submit('hide')
            elif action.getId() == 13:
                self.submit('stop')

    return window(Prompt, 'script-freebird-chapter-stop.xml',
                  get_addon().getAddonInfo('path'), 'Main', '1080i')
