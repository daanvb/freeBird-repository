"""Explicit source reports, never a union of unrelated tracks or sources."""
import re

FEL = 'Dolby Vision FEL'
TRUEHD_ATMOS = 'TrueHD Atmos'
_DV_FEL = re.compile(r'(?i)(?<![a-z0-9])(?:dolby[ ._-]+vision|dv|dovi)'
                     r'[ ._:·()/-]+(?:(?:p(?:rofile)?[ ._-]*)?7(?:\.6)?[ ._:·()/-]+)?fel(?![a-z0-9])')
_TRUEHD_ATMOS = re.compile(r'(?i)(?<![a-z0-9])true[ ._-]*hd'
                           r'(?:[ ._-]*[257]\.\d)?[ ._:/·+-]*(?:dolby[ ._-]+)?atmos(?![a-z0-9])')


def _positive(pattern, value):
    for match in pattern.finditer(value):
        if re.search(r'(?i)\b(?:no|not|without|non)[ ._:-]*$', value[:match.start()]):
            continue
        if re.match(r'(?i)^[ ._:=+-]*(?:0|false|off|no)\b', value[match.end():]):
            continue
        return True
    return False


def _tracks(value, depth=0):
    if depth > 3:
        return
    if isinstance(value, str):
        yield value[:2048]
    elif isinstance(value, (list, tuple)):
        for track in value[:32]:
            yield from _tracks(track, depth + 1)
    elif isinstance(value, dict):
        # A dictionary describes one track. Never join separate list entries.
        yield ' '.join(str(value.get(key) or '')[:256] for key in
                       ('codec', 'audioCodec', 'format', 'extension'))


def reported_variants(row):
    reports = []
    for key in ('filename', 'detail', 'label', 'name', 'title', 'hdr'):
        value = row.get(key)
        if isinstance(value, str):
            reports.extend(value[:8192].splitlines())
    for key in ('audio', 'audioCodec', 'audioCodecs', 'audioTracks', 'audioStreams'):
        reports.extend(_tracks(row.get(key)))
    found = []
    if any(_positive(_DV_FEL, value) for value in reports):
        found.append(FEL)
    if any(_positive(_TRUEHD_ATMOS, value) for value in reports):
        found.append(TRUEHD_ATMOS)
    return found
