"""Publish verified tiny artwork asynchronously for drawers and Settings."""
import threading
import weakref

from lib.background_artwork import frosted_sidebar

_lock = threading.RLock()
_pending = None
_running = False


def request(window, artwork, property_name='sidebar_frosted'):
    global _pending, _running
    texture = frosted_sidebar(artwork)
    with _lock:
        if (texture and getattr(window, '_sidebar_frost_texture', None) == texture
                and (getattr(window, '_sidebar_frost_request', None) is not None
                     or getattr(window, '_sidebar_frost_ready', None) == texture)):
            return
        window._sidebar_frost_ready = None
        token = object()
        window._sidebar_frost_request = token
        window._sidebar_frost_texture = texture
        window.setProperty(property_name, '')
        if not texture:
            return
        # Only the latest waiting selection matters; never queue whole rows.
        if _pending is not None:
            old_reference, old_token, _, _ = _pending
            old_window = old_reference()
            if old_window is not None and getattr(old_window, '_sidebar_frost_request', None) is old_token:
                old_window._sidebar_frost_request = None
        _pending = (weakref.ref(window), token, texture, property_name)
        if not _running:
            _running = True
            try:
                threading.Thread(target=_run, name='s4k-sidebar-frost', daemon=True).start()
            except RuntimeError:
                _running = False
                _pending = None
                window._sidebar_frost_request = None


def _warm(texture):
    from lib.frost_texture import prepare
    return prepare(texture)


def _run():
    global _pending, _running
    while True:
        with _lock:
            job, _pending = _pending, None
            if job is None:
                _running = False
                return
        reference, token, texture, property_name = job
        try:
            prepared = _warm(texture)
            if not prepared:
                continue
            with _lock:
                window = reference()
                if (window is not None and
                        getattr(window, '_sidebar_frost_request', None) is token and
                        getattr(window, 'closed', False) is not True):
                    window.setProperty(property_name, prepared)
                    window._sidebar_frost_ready = texture
                window = None
        except Exception:
            # Artwork failure must retain the opaque fallback, never interrupt
            # navigation or publish the original sharp image.
            pass
        finally:
            with _lock:
                window = reference()
                if window is not None and getattr(window, '_sidebar_frost_request', None) is token:
                    window._sidebar_frost_request = None
                window = None
