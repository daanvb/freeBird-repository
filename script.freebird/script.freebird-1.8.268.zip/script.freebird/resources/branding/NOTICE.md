# freeBird branding

White freeBird wordmark and angular bird approved by the owner on 4 November 2026.
Production PNGs are extracted from the approved raster, preserving the letter
shapes, bird silhouette and lockup composition. Matte texture is removed and
white interiors are flattened; antialiased edges are retained. The standalone
bird is used for the square charcoal app icon. No font is loaded or bundled by
this process: the concept approximates SF Pro, but is not verified San Francisco
typography. Existing Inter UI fonts and their notices remain unchanged.
Unofficial community addon; not endorsed by Stremio or Kodi.
Software copyright and GPL notices remain preserved.

`freebird-wordmark-v1.png` (880×446) and `freebird-bird-v1.png` (284×274)
have transparent backgrounds. The icon is 512×512; fanart is 1920×1080.
Run `tools/build-freebird-branding.py` with Pillow to reproduce these assets from
`docs/branding/freebird-approved.png`. Inspect at native TV sizes before release.

Old cyan assets remain for historical/compatibility references; current app and
player manifests and in-app textures use the versioned freeBird filenames.
