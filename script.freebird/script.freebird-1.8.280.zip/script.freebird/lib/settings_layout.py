"""Compact in-window choices; keep the settings and Details navigation intact."""
from copy import deepcopy
import xml.etree.ElementTree as ET

PICKER = 'String.IsEqual(Window.Property(settings_picker),true)'


def geometry(count, show_help=False):
    rows = max(1, min(7, count))
    height = rows * 66
    return (1080 - height - (350 if show_help else 160)) // 2, height


def prepare(tree):
    controls = tree.getroot().find('controls')
    # Scrollbars have no Python control wrapper in Kodi. Keep the full-page
    # bar XML-owned and hide it in compact choices; the list still scrolls.
    shared = {'200', '300', '310', '311'}
    for control in list(controls)[1:]:
        if control.get('id') in shared:
            continue
        visible = control.find('visible')
        if visible is None:
            visible = ET.SubElement(control, 'visible')
        visible.text = '!'+PICKER + (' + ['+visible.text+']' if visible.text else '')

    panel = ET.Element('control', type='image', id='312')
    for tag, text in (('left', '580'), ('top', '300'), ('width', '760'), ('height', '480'),
                      ('visible', PICKER)):
        ET.SubElement(panel, tag).text = text
    ET.SubElement(panel, 'texture', border='36', colordiffuse='F0181720').text = (
        'special://home/addons/script.freebird/resources/skins/Main/media/controls/local-card-rounded.png')
    controls.insert(1, panel)
    title = ET.SubElement(controls, 'control', type='label', id='313')
    for tag, text in (('left', '620'), ('top', '330'), ('width', '680'), ('height', '42'),
                      ('font', 'font32'), ('textcolor', 'FFFFFFFF'), ('scroll', 'true'),
                      ('label', ''), ('visible', PICKER)):
        ET.SubElement(title, tag).text = text

    listing = controls.find("control[@id='200']")
    for tag in ('itemlayout', 'focusedlayout'):
        original = listing.find(tag)
        original.set('condition', '!'+PICKER)
        compact = ET.Element(tag, width='720', height='66', condition=PICKER)
        for control in original.findall('control'):
            label = control.findtext('label')
            # Choices need only their label, saved-value marker and focus pill.
            if label not in ('$INFO[ListItem.Label]', '$INFO[ListItem.Label2]'):
                if control.get('type') != 'image' or control.findtext('width') != '1280':
                    continue
            elif label == '$INFO[ListItem.Label2]' and 'status_color))' not in control.findtext('visible', ''):
                continue
            clone = deepcopy(control)
            if label == '$INFO[ListItem.Label]':
                clone.find('width').text = '490'
            elif label == '$INFO[ListItem.Label2]':
                clone.find('left').text = '540'
                clone.find('width').text = '140'
            else:
                clone.find('width').text = '720'
            compact.append(clone)
        listing.append(compact)
