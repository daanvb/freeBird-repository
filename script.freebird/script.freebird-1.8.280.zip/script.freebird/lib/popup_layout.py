"""Compact addon-owned popup geometry; text size and navigation stay unchanged."""
import xml.etree.ElementTree as ET

# Old panel left/width and compact width. Timelines, full-screen pages and
# rich people profiles are not popup option menus.
PANELS = {
    'script-stremio-dialog-select.xml': (535, 850, 600),
    'script-stremio-dialog-message.xml': (520, 880, 720),
    'script-stremio-dialog-confirm.xml': (520, 880, 720),
    'script-stremio-dialog-text.xml': (340, 1240, 1040),
    'script-stremio-dialog-progress.xml': (640, 640, 520),
    'script-stremio-dialog-progress-bg.xml': (1256, 600, 480),
    'script-stremio-dialog-toast.xml': (1356, 500, 440),
    'script-stremio-media-actions.xml': (640, 640, 560),
    'script-freebird-player-audio.xml': (520, 880, 680),
}


def content_width(filename, title='', labels=(), message='', body='', primary='', secondary=''):
    """Use a smaller surface for short prompts, retaining room for longer text."""
    title, message, body = (str(value or '') for value in (title, message, body))
    if filename == 'script-stremio-dialog-select.xml':
        labels = [value.getLabel() if hasattr(value, 'getLabel') else str(value) for value in (labels or ())]
        if len(title) <= 22 and all(len(value) <= 22 for value in labels):
            return 480
    if filename in ('script-stremio-dialog-message.xml', 'script-stremio-dialog-confirm.xml'):
        if len(title) <= 22 and len(message) <= 100 and max(len(str(primary or '')), len(str(secondary or ''))) <= 16:
            return 560
    if filename == 'script-stremio-dialog-text.xml' and len(body) <= 500:
        return 760
    return None


def apply(tree, filename, width=None):
    if filename not in PANELS:return
    if filename in ('script-stremio-dialog-message.xml', 'script-stremio-dialog-confirm.xml'):
        controls = tree.getroot().find('controls')
        body = controls.find("control[@type='textbox']")
        body.set('id', '101')
        ET.SubElement(body, 'pagecontrol').text = '60'
        bar = ET.SubElement(controls, 'control', type='scrollbar', id='60')
        for tag, value in (('left', '1350'), ('top', '420'), ('width', '8'), ('height', '225'),
                           ('orientation', 'vertical'), ('showonepage', 'false'),
                           ('onleft', '201'), ('onright', '201'), ('ondown', '201')):
            ET.SubElement(bar, tag).text = value
        for button in controls.findall("control[@type='button']"):
            ET.SubElement(button, 'onup').text = '60'
    old_left, old_width, default_width = PANELS[filename]
    width = width or default_width
    left = old_left + old_width - width if filename.endswith(('-toast.xml', '-progress-bg.xml')) else (1920-width)//2
    scale = width/old_width

    def adjust(parent, root=False):
        for control in parent.findall('control'):
            x, w = control.find('left'), control.find('width')
            # Keep the full-screen backdrop untouched.
            if root and x is not None and w is not None and x.text == '0' and w.text == '1920':continue
            if x is not None:
                try:x.text = str(round(left+(float(x.text)-old_left)*scale if root else float(x.text)*scale))
                except (ValueError, TypeError):pass
            if w is not None:
                try:
                    if float(w.text)>80:w.text = str(round(float(w.text)*scale))
                except (ValueError, TypeError):pass
            if control.get('type') == 'label':
                scroll=control.find('scroll')
                if scroll is None:scroll=ET.SubElement(control,'scroll')
                scroll.text='true'
            adjust(control)
            for tag in ('itemlayout','focusedlayout'):
                for layout in control.findall(tag):
                    layout.set('width',str(round(float(layout.get('width'))*scale)))
                    adjust(layout)
    adjust(tree.getroot().find('controls'), True)

    if width == 560 and filename in ('script-stremio-dialog-message.xml', 'script-stremio-dialog-confirm.xml'):
        for control in tree.getroot().find('controls').findall('control'):
            kind, identity = control.get('type'), control.get('id')
            if kind == 'image' and control.findtext('height') == '480':
                control.find('top').text = '390'
                control.find('height').text = '300'
            elif kind == 'label':
                control.find('top').text = '420'
            elif identity in ('101', '60'):
                control.find('top').text = '490'
                control.find('height').text = '90'
            elif kind == 'button':
                control.find('top').text = '600'

    if filename == 'script-stremio-media-actions.xml':
        listing = tree.find('.//control[@id="600"]')
        listing.find('left').text = str(left+14)
        listing.find('width').text = str(width-28)
