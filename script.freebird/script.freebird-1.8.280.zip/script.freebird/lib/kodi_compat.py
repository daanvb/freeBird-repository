"""Small version gates for APIs that cannot be discovered with hasattr."""
import re


def version_tuple(value):
    if not isinstance(value, str):
        return ()
    match = re.match(r'^\s*(\d+)\.(\d+)(?:\.(\d+))?', value)
    return tuple(int(part or 0) for part in match.groups()) if match else ()


def native_vertical_action(kodi, forward):
    """Keep old fallback actions; adopt Kodi 22 RC2's scene-aware actions.

    The xbmc module version identifies the Python API, not the Kodi release.
    Unknown builds and older Piers previews retain the existing fallback.
    """
    try:
        build = kodi.getInfoLabel('System.BuildVersion')
    except (AttributeError, RuntimeError):
        build = ''
    version = version_tuple(build)
    modern = bool(version and version >= (22, 0, 0))
    if modern and version == (22, 0, 0):
        # Inspect only the release token, never the trailing version/Git text.
        # Unrecognised preview/fork suffixes do not prove RC2 action support.
        release = build.strip().split()[0].split('(', 1)[0]
        known = re.fullmatch(r'22\.0(?:\.0)?(?:-RC(\d+))?', release, re.I)
        modern = bool(known and (known[1] is None or int(known[1]) >= 2))
    if modern:
        return 'ChapterOrSceneOrBigStepForward' if forward else 'ChapterOrSceneOrBigStepBack'
    return 'ChapterOrBigStepForward' if forward else 'BigStepBack'
