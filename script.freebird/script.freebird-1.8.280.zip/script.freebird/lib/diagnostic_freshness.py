"""Freshness labels for saved observations; never imply a live health check."""
import math
import time
from pathlib import Path

RECENT_SECONDS = 15 * 60


def timestamp(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return value if 0 < value <= 4102444800 and math.isfinite(value) else None


def context(profile, now=None):
    from account import Store, AccountError
    now = time.time() if now is None else now
    try:
        state = Store(Path(profile) / 'diagnostic-ui-session').load()
        current = state.get('current')
        started = timestamp(current.get('started')) if isinstance(current, dict) else None
    except (AccountError, OSError):started = None
    return now, started if started is not None and started <= now else None


def classify(at, now, started=None):
    at = timestamp(at)
    if at is None:return 'unknown'
    if at > now:return 'clock_mismatch'
    if started is not None and at < started:return 'earlier_session'
    return 'recent' if now - at <= RECENT_SECONDS else 'older'


def age(at, now):
    at = timestamp(at)
    if at is None:return 'time unknown'
    if at > now:return 'device clock mismatch'
    seconds = int(now - at)
    if seconds < 60:return '{}s ago'.format(seconds)
    if seconds < 3600:return '{}m ago'.format(seconds // 60)
    if seconds < 86400:return '{}h ago'.format(seconds // 3600)
    return '{}d ago'.format(seconds // 86400)


def describe(at, now, started=None):
    label = age(at, now)
    if classify(at, now, started) == 'earlier_session':label += ' · earlier app session'
    value = timestamp(at)
    if value is not None:
        label += ' (' + time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime(value)) + ')'
    return label
