"""Match Kodi 21 language codes and Kodi 22 BCP 47 stream tags.

Keep the historical base code in saved preferences. Optional variant tags only
refine selection within that language; they never change accessibility policy.
"""
import re

ALIASES = {'hr': 'hrv', 'croatian': 'hrv', 'scr': 'hrv', 'hrv': 'hrv',
           'sr': 'srp', 'serbian': 'srp', 'scc': 'srp', 'srp': 'srp',
           'bs': 'bos', 'bosnian': 'bos', 'bos': 'bos',
           'en': 'eng', 'english': 'eng', 'eng': 'eng'}
# ISO 639-2 bibliographic/terminological pairs. Kodi builds differ in which
# spelling they return; use the historical bibliographic code for both.
PAIRS = dict(zip('bod ces cym deu ell eus fas fra hye isl kat mkd mri msa mya nld ron slk sqi zho'.split(),
                 'tib cze wel ger gre baq per fre arm ice geo mac mao may bur dut rum slo alb chi'.split()))
TAG = re.compile(r'^[a-z]{2,3}(?:-[a-z0-9]{1,8})+$', re.I)


def _text(value):
    return str(value or '').strip().lower()


def language(value):
    value = _text(value)
    tag = value.replace('_', '-')
    # Convert the primary subtag ourselves: Kodi 21 cannot convert BCP 47.
    base = tag.split('-')[0] if TAG.fullmatch(tag) else value
    if base in ALIASES:
        return ALIASES[base]
    try:
        import xbmc
        converted = xbmc.convertLanguage(base, xbmc.ISO_639_2)
        if isinstance(converted, str) and converted.strip():
            base = converted.strip().lower()
    except (ImportError, AttributeError, TypeError, ValueError, RuntimeError):
        pass
    return PAIRS.get(base, base)


def language_tag(value):
    value = _text(value)
    tag = value.replace('_', '-')
    base = language(value)
    return base + '-' + tag.split('-', 1)[1] if TAG.fullmatch(tag) else base


def preference_rank(value, preferred):
    """Exact variant, then base-language fallback, then other languages."""
    candidate, wanted = language_tag(value), language_tag(preferred)
    if language(candidate) != language(wanted):
        return 2
    return 0 if '-' not in wanted or candidate == wanted else 1


def display_language(value, converter=None):
    raw = re.sub(r'[\x00-\x1f\x7f\[\]]', '', str(value or '')).strip()
    if raw.lower() in ('', 'und', 'unk', 'unknown'):
        return 'Language unknown'
    name = ''
    if converter:
        try:
            name = converter(raw)
            if not isinstance(name, str):
                name = ''
        except Exception:
            # Optional presentation must not close a picker on native errors.
            pass
    name = re.sub(r'[\x00-\x1f\x7f\[\]]', '', name or '').strip()
    # Even Kodi 22 can return just the base language name. Do not make two
    # region/script variants indistinguishable in the audio/subtitle picker.
    if TAG.fullmatch(raw.replace('_', '-')) and name and raw.casefold() not in name.casefold():
        return '{} ({})'.format(name, raw)
    return name or raw
