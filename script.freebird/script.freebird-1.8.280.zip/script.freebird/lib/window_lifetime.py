"""Retire native publications independently of background reads.

Only registration/retirement takes the gate. Native calls and data lookups
never hold it. Previously acquired controls obey the same retirement.
"""
import threading
from contextlib import contextmanager


class WindowRetired(RuntimeError):
    """Expected cancellation when Kodi delivers a callback after retirement."""


@contextmanager
def input_callback(window):
    lifetime = window.__dict__.get('_native_lifetime')
    if window.__dict__.get('closed') is True or (lifetime is not None and lifetime.retired):
        yield False
        return
    try:
        yield True
    except WindowRetired:
        pass  # A close may race input; unrelated native errors still propagate.


class Lifetime:
    def __init__(self):
        self.lock = threading.RLock()
        self.retired = False
        self.cleanup = None
        self.active = 0

    def call(self, callback, *args, **kwargs):
        with self.lock:
            if self.retired:raise WindowRetired('Window retired')
            self.active += 1
        try:
            return callback(*args, **kwargs)
        finally:
            with self.lock:
                self.active -= 1
                cleanup = self._cleanup()
            if cleanup:cleanup()

    def retire(self, cleanup=None):
        # A native input callback may own Kodi's window lock while a publisher
        # waits inside a native call. Never wait for that publisher from here.
        with self.lock:
            self.cleanup = cleanup
            self.retired = True
            ready = self._cleanup()
        if ready:ready()

    def _cleanup(self):
        if self.retired and not self.active and self.cleanup:
            callback, self.cleanup = self.cleanup, None
            return callback

    def publish(self, callback, *args):
        if not self.retired:
            try:return self.call(callback, *args)
            except RuntimeError:
                if not self.retired:raise

    def control(self, callback, identity):
        return _Control(self, self.call(callback, identity))


class _Control:
    def __init__(self, lifetime, native):
        self.lifetime, self.native = lifetime, native

    def __getattr__(self, name):
        def call(*args, **kwargs):
            # Native directional navigation accepts Control objects, not proxies.
            # Home passes its other guarded controls to controlUp/Down/Right.
            def native(value):
                if isinstance(value, _Control):
                    if value.lifetime.retired:raise WindowRetired('Window retired')
                    return value.native
                return value
            args = tuple(native(value) for value in args)
            kwargs = {key:native(value) for key,value in kwargs.items()}
            result = self.lifetime.call(lambda: getattr(self.native, name)(*args, **kwargs))
            return _Control(self.lifetime, result) if name in ('getListItem', 'getSelectedItem', 'getVideoInfoTag') else result
        return call
