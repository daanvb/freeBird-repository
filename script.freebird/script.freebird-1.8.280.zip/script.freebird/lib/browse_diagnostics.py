"""Bounded passive browsing evidence; no URLs, titles or extra network probes."""
import math
import re
import statistics
import time
from pathlib import Path

LIMIT = 128
STAGES = ('metadata.first', 'metadata.complete', 'artwork.cache_ready',
          'artwork.cache_unknown', 'artwork.cache_pending', 'artwork.cache_miss',
          'ui.home.full', 'ui.home.incremental', 'ui.home.background.total')
COUNTS = ('probes', 'initial_hit', 'budget_exhausted', 'cancelled', 'episode', 'timing_version')
FAMILIES = ('AIOmetadata', 'Cinemeta', 'Other')


def number(value, maximum):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or (isinstance(value, float) and not math.isfinite(value)):
        return None
    return max(0, min(maximum, value))


def clean(row):
    if not isinstance(row, dict):return None
    at, ms = number(row.get('at'), 4102444800), number(row.get('ms'), 1800000)
    if at is None or ms is None:return None
    result = {'at': at, 'ms': int(ms)}
    if row.get('stage') in STAGES:
        result['stage'] = row['stage']
        for key in COUNTS:
            if key == 'timing_version':
                if row.get(key) == 2:result[key] = 2
                continue
            value = number(row.get(key), 10000 if key == 'probes' else 1)
            if value is not None:result[key] = int(value)
    elif (row.get('stage') == 'request' and row.get('resource') in ('meta', 'catalog', 'manifest')
          and row.get('status') in ('cached', 'refreshed', 'failed')):
        result.update(stage='request', resource=row['resource'], status=row['status'],
                      provider=row.get('provider') if row.get('provider') in FAMILIES else 'Other')
        from lib.provider_diagnostics import _FAILURE_REASONS
        reason = row.get('reason')
        if isinstance(reason, str) and (reason in _FAILURE_REASONS or re.fullmatch(r'HTTP [1-5][0-9]{2}', reason)):
            result['reason'] = reason
        timeout = number(row.get('timeout'), 1800)
        if timeout is not None:result['timeout'] = timeout
    else:return None
    return result


def merge_events(*histories):
    values = {}
    for history in histories:
        for row in history[-LIMIT:] if isinstance(history, (list, tuple)) else []:
            item = clean(row)
            if item:values[tuple(sorted(item.items()))] = item
    return sorted(values.values(), key=lambda row: row['at'])[-LIMIT:]


def stage_event(stage, row):
    return clean(dict(row, stage=stage, at=time.time()))


def request_event(row):
    label = str(row.get('provider', '')).casefold().replace(' ', '')
    family = 'AIOmetadata' if label.startswith('aiometadata') else 'Cinemeta' if label.startswith('cinemeta') else 'Other'
    return clean(dict(row, stage='request', at=row.get('checked'), provider=family))


def snapshot(profile, now=None):
    from account import Store, AccountError
    histories = []
    for folder in ('performance', 'diagnostics'):
        try:histories.append(Store(Path(profile) / folder).load().get('browsing'))
        except (AccountError, OSError):pass
    # The UI interpreter can include not-yet-flushed request observations; the
    # service uses the persisted history. Request writes keep their 15s throttle.
    from lib import provider_diagnostics as requests
    with requests._lock:
        if requests._profile == Path(profile) / 'diagnostics':
            histories.append(list(requests._events))
    # Keep separate caps so busy catalogue traffic cannot evict artwork evidence.
    requests_rows = merge_events(*[[r for r in h if isinstance(r, dict) and r.get('stage') == 'request']
                                    for h in histories if isinstance(h, list)])
    stages = merge_events(*[[r for r in h if isinstance(r, dict) and r.get('stage') != 'request']
                            for h in histories if isinstance(h, list)])
    events = sorted(requests_rows + stages, key=lambda row: row['at'])
    from lib.diagnostic_freshness import context, classify, RECENT_SECONDS
    captured, started = context(profile, now)
    recent = [e for e in events if classify(e['at'], captured, started) == 'recent']
    older = [e for e in events if classify(e['at'], captured, started) != 'recent']
    return {'version': 2, 'captured_at': captured, 'session_started': started,
            'recent_window_seconds': RECENT_SECONDS, 'events': events,
            'summary': summarize(recent), 'historical_summary': summarize(older)}


def summarize(events):
    groups = {}
    for event in events:
        key = event['stage']
        if key == 'request':
            key = '.'.join((event['provider'], event['resource'], event['status']))
        elif key.startswith('artwork.'):
            key += '.episode' if event.get('episode') else '.poster'
            if event.get('timing_version') != 2:key += '.legacy'
        groups.setdefault(key, []).append(event['ms'])
    summary = {key: {'samples': len(values), 'median_ms': int(statistics.median(values)),
                     'max_ms': max(values)} for key, values in groups.items()}
    return summary


def describe(profile):
    report = snapshot(profile)
    if not report['events']:return 'Browse Home and open a title to record measurements.'
    lines = ['Recent observations: last 15 minutes.']
    if report['session_started'] is not None:lines.append('Earlier app sessions are excluded from recent results.')
    if not report['summary']:lines.append('No recent measurements. Browse Home or open a title, then reopen this screen.')
    for key, value in sorted(report['summary'].items()):
        lines.append('{}: {} samples, median {:.2f}s, slowest {:.2f}s'.format(
            key, value['samples'], value['median_ms'] / 1000, value['max_ms'] / 1000))
    if report['historical_summary']:
        lines.append('Earlier observations (historical, not current):')
        for key, value in sorted(report['historical_summary'].items()):
            lines.append('{}: {} samples, slowest {:.2f}s'.format(key, value['samples'], value['max_ms'] / 1000))
    from lib.diagnostic_freshness import describe as observed
    lines.append('Last observation: ' + observed(report['events'][-1]['at'], report['captured_at'], report['session_started']))
    lines.append('Artwork groups marked legacy use the older timer and may include time away from the screen. Cache readiness is not proof an image appeared on screen. Request time includes local cache/coalescing and network work; it is not WiFi speed. Recent request samples can take 15 seconds to reach the service report. Send diagnostic report now uploads this evidence with the existing report and logs.')
    return '\n'.join(lines)
