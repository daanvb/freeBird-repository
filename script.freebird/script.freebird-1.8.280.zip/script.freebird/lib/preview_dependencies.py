"""Repository-managed optional decoder setup, initiated from Playback settings."""
from pathlib import Path
import json
import struct
import platform
from lib.kodi_compat import version_tuple

FFMPEG_ADDON = 'tools.ffmpeg-tools'


def addon_enabled(kodi, identity):
    """HasAddon includes disabled addons, whose VFS protocols cannot be opened."""
    try:
        reply = json.loads(kodi.executeJSONRPC(json.dumps(dict(jsonrpc='2.0', id=1,
            method='Addons.GetAddonDetails', params=dict(addonid=identity, properties=['enabled'])))))
        addon = reply['result']['addon']
        return isinstance(addon, dict) and addon.get('addonid') == identity and addon.get('enabled') is True
    except (KeyError, TypeError, ValueError, RuntimeError):
        return False


def android_decoder(kodi, bits=None, machine=None):
    """Select the Kodi process ABI, never just the device's marketed CPU."""
    version = version_tuple(kodi.getInfoLabel('System.BuildVersion'))
    arch = (machine if machine is not None else platform.machine()).lower()
    size = bits if bits is not None else struct.calcsize('P') * 8
    if not version or version[0] not in (21, 22) or not arch.startswith(('arm', 'aarch64')):
        return None
    if size not in (32, 64):
        return None
    flavour = 'omega' if version[0] == 21 else 'piers'
    abi = 'armv7' if size == 32 else 'aarch64'
    return 'vfs.freebird.preview.{}.{}'.format(flavour, abi)


def find_backend(kodi, translate):
    if kodi.getCondVisibility('System.Platform.Android'):
        identity = android_decoder(kodi)
        if identity and addon_enabled(kodi, identity):
            return 'native:' + identity.replace('vfs.freebird.preview.', 'freebirdpreview').replace('.', '')
        return None
    from core.seek_preview import find_decoder
    return find_decoder(translate)


def elec_distribution(read=None):
    """Do not infer CoreELEC support from Linux or CPU architecture alone."""
    try:
        text = read() if read else Path('/etc/os-release').read_text(encoding='utf-8')
        for line in text.splitlines():
            key, separator, value = line.partition('=')
            if separator and key.strip() == 'ID':
                return value.strip().strip('\"\'').lower() in ('coreelec', 'libreelec')
    except (OSError, UnicodeError):
        pass
    return False


def request_decoder(kodi, translate, notify, discover=None, supported=None):
    """Ask Kodi's installer, never fetch a binary or claim installation succeeded."""
    if discover is None:
        discover = lambda: find_backend(kodi, translate)
    try:
        if kodi.getCondVisibility('System.Platform.Android'):
            identity = android_decoder(kodi)
            if not identity:
                notify('Seek previews', 'This Kodi build has no compatible preview decoder. The normal timeline remains available.')
                return 'unavailable'
            if kodi.getCondVisibility('System.HasAddon({})'.format(identity)):
                if not addon_enabled(kodi, identity):
                    reply = json.loads(kodi.executeJSONRPC(json.dumps(dict(jsonrpc='2.0', id=1,
                        method='Addons.SetAddonEnabled', params=dict(addonid=identity, enabled=True)))))
                    if not isinstance(reply, dict) or reply.get('result') != 'OK' or not addon_enabled(kodi, identity):
                        notify('Seek previews', 'Kodi could not enable the preview decoder. Check it in Kodi Add-ons.')
                        return 'unavailable'
                    notify('Seek previews', 'Preview decoder enabled. Play a movie and use the seek bar to try it.')
                    return 'enabled'
                notify('Seek previews', 'Preview decoder is enabled. Play a movie and use the seek bar to try it.')
                return 'ready'
            kodi.executebuiltin('InstallAddon({})'.format(identity))
            notify('Seek previews', 'Preview decoder installation requested. Keep the freeBird repository enabled.')
            return 'requested'
        if discover():
            return 'ready'
        if not (supported() if supported else elec_distribution()):
            notify('Seek previews', 'Install a compatible FFmpeg executable on this device to generate preview images.')
            return 'unavailable'
        if kodi.getCondVisibility('System.HasAddon({})'.format(FFMPEG_ADDON)):
            notify('Seek previews', 'FFmpeg Tools is installed, but its executable is unavailable. Check it in Kodi Add-ons.')
            return 'unavailable'
        kodi.executebuiltin('InstallAddon({})'.format(FFMPEG_ADDON))
        notify('Seek previews', 'FFmpeg Tools installation requested from Kodi. Keep the CoreELEC or LibreELEC repository enabled.')
        return 'requested'
    except (OSError, RuntimeError, ValueError):
        notify('Seek previews', 'Kodi could not prepare the preview decoder. Check it in Kodi Add-ons and try again.')
        return 'unavailable'
