"""Immediate local UI indexes after a confirmed Stremio playback write-back."""


def refresh_continue_index(store, context, remote, projected=False):
    """Refresh local Continue Watching from the already-verified account state.

    No network calls happen here. For a completed series episode, use the
    playback metadata we already had to resolve the next episode or fully
    watched series immediately instead of waiting for background maintenance.
    """
    from lib import continue_index

    state = store.load()
    from lib.viewer_profiles import storage_directory
    directory=storage_directory(store)
    library = state.get('library', []) if isinstance(state, dict) else []
    if projected:
        from lib.progress_outbox import projected_library
        library = projected_library(store, state)
    continue_index.seed(directory, library)

    if not isinstance(remote, dict) or context.get('kind') != 'series':
        return
    media_id = str(context.get('meta_id') or '')
    videos = context.get('videos') if isinstance(context.get('videos'), list) else []
    if not media_id or not videos:
        return

    from core.continue_playback import continue_series_resolution
    target, resume_ms, finished = continue_series_resolution(videos, remote)
    # A partial episode is already visible after seed(). Only resolve the
    # completed/sentinel case when an aired target or full completion is known.
    state_row = remote.get('state') if isinstance(remote.get('state'), dict) else {}
    try:
        offset = max(0, int(float(state_row.get('timeOffset') or 0)))
    except (TypeError, ValueError, OverflowError):
        offset = 0
    if offset > 1 and target is not None and str(target.get('id') or '') == str(state_row.get('video_id') or ''):
        return
    if target is None and not finished:
        return

    projected = dict(remote)
    projected['id'] = media_id
    projected['videos'] = videos
    for key in ('name', 'poster', 'posterShape', 'behaviorHints'):
        if projected.get(key) in (None, '', {}, []):
            value = context.get(key)
            if value not in (None, '', {}, []):
                projected[key] = value
    continue_index.resolve_series(directory, media_id, projected, target, resume_ms, finished)


def refresh_watched_action(store, meta, remote):
    """Resolve a verified manual episode action in its frozen viewer, then notify UI."""
    import sqlite3
    context = dict(meta, kind=meta.get('type'), meta_id=meta.get('id'),
                   video_id=(remote.get('state') or {}).get('video_id'))
    try:
        refresh_continue_index(store, context, remote)
    except (sqlite3.Error, OSError):
        # Optional index failure must not report a confirmed account write as failed.
        pass
    from lib.progress_signal import publish
    publish(context)
