"""Per-series track preferences; track indices never persist across episodes."""
import hashlib
import re
import time
from pathlib import Path
from account import Store


def series_key(context, file):
    identity = str(context.get('id') or '')
    if context.get('kind') != 'series' or context.get('url_hash') != hashlib.sha256(file.encode()).hexdigest():
        return None
    return identity.split(':')[0] if re.fullmatch(r'tt[0-9]+:[0-9]+:[0-9]+', identity) else None


def signature(track, subtitle=False):
    from lib.kodi_language import language, language_tag
    code = language(track.get('language'))
    if not code or code in ('und','unk','none','off'):
        return None
    result = {'language': code}
    tag = language_tag(track.get('language'))
    if tag != code:
        result['language_tag'] = tag
    if subtitle:
        result.update(forced=bool(track.get('isforced') or re.search(r'\bforced\b', str(track.get('name') or ''), re.I)),
                      impaired=bool(track.get('isimpaired')))
    else:
        result['codec'] = str(track.get('codec') or '').lower()[:30]
    return result


def match(tracks, preference, subtitle=False):
    if not isinstance(preference, dict):return None
    from lib.kodi_language import language, preference_rank
    candidates = [(track, signature(track, subtitle)) for track in tracks if isinstance(track, dict) and isinstance(track.get('index'), int)]
    candidates = [(track, value) for track, value in candidates if value and value['language'] == language(preference.get('language'))]
    if subtitle:
        candidates = [(t,v) for t,v in candidates if v.get('forced') == preference.get('forced') and v.get('impaired') == preference.get('impaired')]
    wanted = preference.get('language_tag') or preference.get('language')
    candidates.sort(key=lambda pair: (preference_rank(pair[1].get('language_tag') or pair[1]['language'], wanted),
                                     pair[1].get('codec') != preference.get('codec')))
    return candidates[0][0] if candidates else None


def english_audio(tracks, current=None, preference=None):
    """Prefer labelled English dialogue; never guess from the release name."""
    from subtitles import language
    candidates=[]
    for track in tracks:
        if not isinstance(track,dict) or type(track.get('index')) is not int:continue
        raw=str(track.get('language') or '').strip().lower()
        code='eng' if re.fullmatch(r'en(?:[-_][a-z0-9]+)*',raw) else language(raw)
        name=str(track.get('name') or '')
        if code!='eng' and not (code in ('','und','unk') and re.search(r'\benglish\b',name,re.I)):continue
        candidates.append(track)
    if not candidates:return None
    dialogue=[t for t in candidates if not (t.get('isvisuallyimpaired') or
        re.search(r'commentary|audio description|descriptive|visually impaired',str(t.get('name') or ''),re.I))]
    candidates=dialogue or candidates
    from lib.player_audio import codec_name
    def quality(track):
        codec=codec_name(track.get('codec'))
        name=str(track.get('name') or '')
        if 'atmos' in codec or re.search(r'\batmos\b',name,re.I):tier=0
        elif codec=='truehd':tier=1
        elif codec=='eac3':tier=2
        elif codec=='ac3':tier=3
        elif codec.startswith(('dts','dca')):tier=4
        else:tier=5
        try:channels=max(0,int(track.get('channels') or 0))
        except (TypeError,ValueError,OverflowError):channels=0
        return tier,-channels
    best=min(quality(t) for t in candidates)
    candidates=[t for t in candidates if quality(t)==best]
    active=next((t for t in candidates if t['index']==current),None)
    preferred=match(candidates,preference) if preference else None
    return active or preferred or candidates[0]


def manage(profile, player, rpc, picker):
    file = player.getPlayingFile()
    key = series_key(Store(Path(profile)/'playback').load(), file)
    if not key:return picker.ok('Series track preferences', 'Available during a freeBird episode.')
    choice = picker.select('Series track preferences', ['Remember current audio and subtitles', 'Forget saved preferences'], preselect=-1)
    if choice not in (0,1) or player.getPlayingFile()!=file:return
    store = Store(Path(profile)/'series-tracks')
    rows = store.load().get('series', {})
    if choice == 1:rows.pop(key,None)
    else:
        active = next((p for p in rpc('Player.GetActivePlayers') or [] if p.get('type')=='video'),None)
        if not active:return
        props = rpc('Player.GetProperties', {'playerid':active['playerid'], 'properties':['currentaudiostream','currentsubtitle','subtitleenabled']}) or {}
        if player.getPlayingFile()!=file:return
        rows[key] = {'audio': signature(props.get('currentaudiostream') or {}),
                     'subtitle': signature(props.get('currentsubtitle') or {},True) if props.get('subtitleenabled') else 'off',
                     'updated': int(time.time())}
    rows = dict(sorted(rows.items(),key=lambda pair:pair[1].get('updated',0))[-200:])
    store.save({'series':rows})
    picker.ok('Series track preferences', 'Preferences saved for this series.' if choice==0 else 'Saved preferences removed.')

class Watcher:
    def __init__(self,profile,player,home,rpc):
        self.profile,self.player,self.home,self.rpc=Path(profile),player,home,rpc
        self.file=None;self.session=None;self.started=0;self.done=set()
    def tick(self):
        try:
            file=self.player.getPlayingFile() if self.player.isPlayingVideo() else None
            if not file or file!=getattr(self.player,'_playing_file',None):return
            session=getattr(self.player,'_track_session',None)
            if self.file!=file or self.session!=session:
                self.file=file;self.session=session;self.started=time.monotonic();self.done=set()
            if time.monotonic()-self.started>30:return
            key=series_key(Store(self.profile/'playback').load(),file)
            pref=(Store(self.profile/'series-tracks').load().get('series',{}).get(key) or {}) if key else {}
            # ProgressPlayer only supplies _playing_file for owned VOD. Apply
            # the English default to movies too, with no global Kodi change.
            if 'audio' in self.done and (not pref or 'subtitle' in self.done):return
            active=next((p for p in self.rpc('Player.GetActivePlayers') or [] if p.get('type')=='video'),None)
            if not active:return
            props=self.rpc('Player.GetProperties', {'playerid':active['playerid'], 'properties':['audiostreams','currentaudiostream','subtitles']}) or {}
            digest=hashlib.sha256(file.encode()).hexdigest()
            for kind in ('audio','subtitle'):
                if kind in self.done:continue
                if self.home.getProperty('strem4kodi.'+('audio' if kind=='audio' else 'subtitles')+'.manual')==digest:
                    self.done.add(kind);continue
                value=pref.get(kind)
                tracks=props.get('audiostreams' if kind=='audio' else 'subtitles') or []
                current=(props.get('currentaudiostream') or {}).get('index')
                track=(english_audio(tracks,current,value) or match(tracks,value)) if kind=='audio' else match(tracks,value,True)
                if self.player.getPlayingFile()!=file or getattr(self.player,'_track_session',None)!=session:return
                if kind=='audio' and track:
                    if track['index']!=current:
                        self.rpc('Player.SetAudioStream',{'playerid':active['playerid'],'stream':track['index']})
                elif kind=='subtitle' and value=='off':
                    # Off keeps the app's automatic forced-subtitle policy active.
                    self.rpc('Player.SetSubtitle',{'playerid':active['playerid'],'subtitle':'off'})
                elif kind=='subtitle' and track:
                    self.rpc('Player.SetSubtitle',{'playerid':active['playerid'],'subtitle':track['index'],'enable':True})
                    self.home.setProperty('strem4kodi.subtitles.manual',digest)
                else:continue
                self.done.add(kind)
        except Exception:pass
