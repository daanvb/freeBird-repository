"""Periodic disk budget for identifiable freeBird textures, via Kodi's API.

The budget is eventual: Kodi can download images between passes. Never delete
files directly or infer ownership from a provider host or a thumbnail filename.
"""
import hashlib
import json
from pathlib import Path
import threading
import time

DEFAULT_MB = '512'
SIZES = ('128', '256', '512', '1024', '2048', 'unlimited')
SETTING = 'cache_artwork_mb'


def limit(get_setting):
    from lib.cache_policy import parse_size
    try:
        value = parse_size(get_setting(SETTING) or DEFAULT_MB)
        if value == 0:
            raise ValueError('Artwork caching is managed by Kodi')
        return value
    except (ValueError, TypeError, ArithmeticError):
        return int(DEFAULT_MB) * 1048576


def _fingerprint(url):
    from lib.artwork_cache import _raw
    # GetTextures adds a wrapper, including around existing resize wrappers.
    for _ in range(4):
        raw = _raw(url)
        if raw == url:
            break
        url = raw
    return hashlib.sha256(url.encode('utf-8')).hexdigest()


def _file(root, cached):
    # Kodi returns paths relative to special://thumbnails. Only stat regular
    # files inside that root; reject absolute paths, traversal and symlinks out.
    relative = Path(cached)
    if not cached or relative.is_absolute() or relative.drive or '..' in relative.parts:
        return None
    path = (root / relative).resolve()
    if root not in path.parents or not path.is_file():
        return None
    return path


def enforce(cache, thumbnails, execute, maximum, store, cancelled=lambda: False):
    """Measure exact files and evict least recently used owned textures.

    Keep hashes of still-existing textures so ownership survives the bounded URL
    ledger's expiry. Older images absent from both ledgers cannot be reclaimed.
    Kodi's `sizes.size` is a variant number, NOT a byte count.
    """
    if maximum is None or cancelled():
        return None

    def rpc(method, params):
        reply = json.loads(execute(json.dumps({'jsonrpc': '2.0', 'id': 1,
                                              'method': method, 'params': params})))
        if 'error' in reply or 'result' not in reply:
            raise RuntimeError('Artwork cache maintenance unavailable')
        return reply['result']

    with cache.connect() as db:
        known = {_fingerprint(row[0]) for row in db.execute('SELECT url FROM artwork_urls')}
    previous = store.load().get('owned', [])
    known.update(value for value in previous if isinstance(value, str) and len(value) == 64)
    if not known:
        return None
    textures = rpc('Textures.GetTextures', {'properties': ['url', 'cachedurl', 'sizes']})['textures']
    root = Path(thumbnails).resolve()
    entries, owned, files = [], set(), set()
    for texture in textures:
        if cancelled():
            return None
        fingerprint = _fingerprint(str(texture.get('url') or ''))
        if fingerprint not in known:
            continue
        owned.add(fingerprint)
        try:
            path = _file(root, str(texture.get('cachedurl') or ''))
            if path is None or path in files:
                continue
            size = path.stat().st_size
        except OSError:
            continue
        files.add(path)
        last_used = max((str(s.get('lastused') or '') for s in texture.get('sizes', [])), default='')
        entries.append((last_used, texture['textureid'], size))
    total = sum(row[2] for row in entries)
    # Persist ownership before deletions; a failed RPC must not lose ownership.
    state = {'owned': sorted(owned), 'bytes': total, 'limit': maximum, 'checked': time.time()}
    store.save(state)
    target = int(maximum * .9) if total > maximum else maximum
    removed = 0
    for _, identity, size in sorted(entries):
        if total <= target or cancelled():
            break
        if rpc('Textures.RemoveTexture', {'textureid': identity}) != 'OK':
            raise RuntimeError('Artwork cache maintenance unavailable')
        total -= size
        removed += 1
    state.update(bytes=total, removed=removed)
    store.save(state)
    return state


class ArtworkBudget:
    """One cancellable worker; never block the progress/player service loop."""
    INTERVAL = 300

    def __init__(self, profile, addon):
        self.profile, self.addon = Path(profile), addon
        self._next = time.monotonic() + 60
        self._setting = addon.getSetting(SETTING)
        self._worker = None
        self._stop = threading.Event()
        self._monitor = self._player = None

    def _cancelled(self):
        import xbmc
        if self._stop.is_set():
            return True
        if self._monitor is None:
            self._monitor, self._player = xbmc.Monitor(), xbmc.Player()
        return self._monitor.abortRequested() or self._player.isPlaying()

    def tick(self):
        current = self.addon.getSetting(SETTING)
        if current != self._setting:
            self._setting, self._next = current, 0
        if (self._stop.is_set() or time.monotonic() < self._next
                or (self._worker is not None and self._worker.is_alive()) or self._cancelled()):
            return
        self._next = time.monotonic() + self.INTERVAL
        self._worker = threading.Thread(target=self._run, daemon=True)
        self._worker.start()

    def _run(self):
        try:
            maximum = limit(self.addon.getSetting)
            if maximum is None or self._cancelled():
                return
            import xbmc
            import xbmcvfs
            from account import Store
            from lib.disk_cache import DiskCache
            cache = DiskCache(self.profile / 'cache')
            enforce(cache, xbmcvfs.translatePath('special://thumbnails/'), xbmc.executeJSONRPC,
                    maximum, Store(self.profile / 'artwork-budget'),
                    lambda: self._cancelled() or limit(self.addon.getSetting) != maximum)
        except Exception:
            # Optional maintenance must never stop playback or leak image URLs.
            pass

    def close(self):
        self._stop.set()
