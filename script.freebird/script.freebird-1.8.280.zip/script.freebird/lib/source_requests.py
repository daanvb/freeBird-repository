"""Share overlapping source searches within a runtime; retain no completed jobs."""
from copy import deepcopy
import threading


class SourceRequests:
    def __init__(self):
        self.lock = threading.Lock()
        self.jobs = {}

    def request(self, key, loader, on_rows=None, on_progress=None, cancelled=None):
        """Return an independent result, or None when this caller cancels.

        A follower can leave without stopping the owner or other subscribers.
        The owner's loader remains responsible for observing all_cancelled.
        """
        if cancelled is not None and cancelled():return None
        with self.lock:
            job = self.jobs.get(key)
            owner = job is None or job.get('abandoned', False)
            if owner:
                job = {'lock': threading.RLock(), 'event': threading.Event(),
                       'subscribers': [], 'rows': None, 'progress': None, 'result': None, 'error': None,
                       'abandoned': False}
                self.jobs[key] = job
        callbacks = (on_rows, on_progress, cancelled)
        def inactive(subscriber):
            return subscriber[2] is not None and subscriber[2]()
        def all_cancelled():
            with job['lock']:
                job['abandoned'] = job['abandoned'] or all(inactive(s) for s in job['subscribers'])
                return job['abandoned']
        def deliver(subscriber, index, value):
            callback = subscriber[index]
            if callback is not None and value is not None:
                try:
                    if not inactive(subscriber):callback(deepcopy(value))
                except Exception:
                    pass
        def publish(field, value, index):
            with job['lock']:
                job[field] = deepcopy(value)
                for subscriber in job['subscribers']:
                    deliver(subscriber, index, value)
        try:
            with job['lock']:
                job['subscribers'].append(callbacks)
                deliver(callbacks, 0, job['rows'])
                deliver(callbacks, 1, job['progress'])
            if owner:
                try:
                    job['result'] = loader(lambda rows: publish('rows', rows, 0),
                                           lambda status: publish('progress', status, 1), all_cancelled)
                except Exception as error:
                    job['error'] = error
                finally:
                    with self.lock:
                        if self.jobs.get(key) is job:
                            del self.jobs[key]
                    job['event'].set()
            else:
                while not job['event'].wait(0.05):
                    if inactive(callbacks):return None
            if inactive(callbacks):return None
            if job['error'] is not None:
                raise job['error']
            return deepcopy(job['result'])
        finally:
            with job['lock']:
                # Detach by identity: two subscribers may have equal callbacks.
                job['subscribers'] = [s for s in job['subscribers'] if s is not callbacks]


requests = SourceRequests()
