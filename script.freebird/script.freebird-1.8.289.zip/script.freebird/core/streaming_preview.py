"""Incremental executable-preview reads within the existing block budgets."""
from collections import OrderedDict
from core.file_chapters import Unavailable
from core.seek_preview import (PreviewReader, PreviewFailure, BLOCK, FRAME_BYTES,
                               RATE_BYTES, MEMORY_BYTES)

SLICE = 32 * 1024


class StreamingReader(PreviewReader):
    """Deliver available bytes before the rest of a charged range arrives.

    At most two upstream responses are held open, matching the proxy slots. Cache entries are contiguous block
    prefixes; abandoning a response keeps its received prefix and its full charge.
    The inherited lock serialises readers, accounting and response ownership.
    """
    def __init__(self, source, **kwargs):
        self.responses = OrderedDict()
        super().__init__(source, **kwargs)

    @property
    def response(self):
        return next((entry[0] for entry in self.responses.values()), None)

    def finish(self):
        while self.responses:
            _, (response, _) = self.responses.popitem(last=False)
            response.close()

    def begin(self, alive):
        self.finish()
        super().begin(alive)

    def _chunk(self, offset):
        if self.local is not None:
            return super()._chunk(offset)
        self.check()
        if offset < 0: raise PreviewFailure('range')
        start = offset // BLOCK * BLOCK
        relative = offset-start
        data = self.cache.get(start, b'')
        needed = relative+(8 if offset == 0 else 1)
        if self.total is not None: needed = min(needed, self.total-start)
        if relative < len(data) and len(data) >= needed:
            self.cache_hits += 1
            self.cache.move_to_end(start)
            return data[relative:relative+SLICE]
        if self.total is not None and offset >= self.total: return b''
        self.read_started = self.clock()
        try:
            if start not in self.responses:
                if len(self.responses) >= 2:
                    _, (old_response, _) = self.responses.popitem(last=False)
                    old_response.close()
                at = start+len(data)
                length = BLOCK-len(data)
                if self.total is not None: length = min(length, self.total-at)
                self._expire_reads()
                if self.recent_bytes+length > RATE_BYTES: raise PreviewFailure('budget')
                if self.frame_bytes+length > FRAME_BYTES or self.requests >= 80:
                    raise PreviewFailure('read_limit')
                # Reserve the complete range, even if the decoder closes early.
                self.requests += 1
                self.frame_bytes += length
                self.spent += length
                self.recent.append((self.clock(), length))
                self.recent_bytes += length
                response, remaining = self.open_remote(at, length)
                self.responses[start] = (response, at+remaining)
            response, response_end = self.responses[start]
            self.responses.move_to_end(start)
            read = getattr(response, 'read1', response.read)
            needed = min(needed, response_end-start)
            while len(data) < needed:
                self.check()
                remaining = response_end-start-len(data)
                if remaining <= 0: return b''
                sock = getattr(getattr(getattr(response, 'fp', None), 'raw', None), '_sock', None)
                if sock is not None:
                    sock.settimeout(max(.05, min(self.socket_seconds, self.deadline-self.clock())))
                chunk = read(min(SLICE, remaining))
                if not chunk or len(chunk) > min(SLICE, remaining):
                    raise Unavailable('Incomplete metadata range')
                self.received(len(chunk))
                self.check()
                data += chunk
                self.cache[start] = data
                self.cache.move_to_end(start)
                while len(self.cache)*BLOCK > MEMORY_BYTES:
                    self.cache.popitem(last=False)
            if start+len(data) == response_end:
                self.responses.pop(start)
                response.close()
            return data[relative:relative+SLICE]
        except PreviewFailure:
            self.finish()
            raise
        except Unavailable as error:
            self.finish()
            if str(error) in ('Byte ranges unavailable', 'Inconsistent metadata range',
                              'Media changed during metadata read'):
                raise PreviewFailure('range') from None
            raise
        except OSError as error:
            self.finish()
            timed_out = isinstance(error, TimeoutError) or isinstance(getattr(error, 'reason', None), TimeoutError)
            raise PreviewFailure('timeout' if timed_out else 'network', self.evidence()) from None
        finally:
            self.read_seconds += max(0, self.clock()-self.read_started)
            self.read_started = None
