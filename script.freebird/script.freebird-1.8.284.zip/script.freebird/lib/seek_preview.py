"""Service-owned preview worker and a nonblocking scrub-dialog mailbox."""
import hashlib
import json
import math
from collections import OrderedDict
import threading
import time
import uuid
from urllib.parse import urlsplit

PREFIX = 'strem4kodi.player.preview.'
SESSION, REQUEST, REPLY = (PREFIX + name for name in ('session', 'request', 'reply'))
STATUS = PREFIX + 'status'
SETTLE_SECONDS = .3
MESSAGES = {
    'starting': 'Preparing seek previews…',
    'missing': 'Preview decoder is missing or disabled. Turn previews off and on in Playback settings.',
    'decoder_failed': 'Preview decoder could not start. Check it in Kodi Add-ons.',
    'waiting': 'Previews are waiting for playback to settle. Pause to try again.',
    'generating': 'Generating seek previews…',
    'retrying': 'Still generating the preview…',
    'failed': 'Could not create a preview for this part of the video.',
    'budget': 'Preview reads are cooling down. They will resume automatically.',
    'settling': 'Choose a position to preview…',
    'no_frame': 'No nearby keyframe is available for this position.',
    'timeout': 'Preview timed out while reading or decoding this video.',
    'read_limit': 'This preview needs more data than the per-picture limit.',
    'range': 'This stream does not provide consistent byte ranges for previews.',
    'network': 'Could not read this stream for previews.',
    'container': 'Preview images currently support MKV and MP4 files.',
}


def digest(source):
    return hashlib.sha256(source.encode('utf-8')).hexdigest()


def read(window, name):
    try:
        raw = window.getProperty(name)
        if not isinstance(raw, str) or len(raw) > 8192:
            return {}
        value = json.loads(raw or '{}')
        return value if isinstance(value, dict) else {}
    except (ValueError, RuntimeError):
        return {}


def slot(target, duration):
    return max(0, min(int(duration-.1)//10*10, int(target+5)//10*10))


def plan(target, position, duration, direction=1, focused=False):
    """Bounded latest-target plan; remote repeats never append work to a queue."""
    return [max(0, min(int(duration-.1), int(target))) if focused else slot(position, duration)]


class Client:
    """Only property reads/writes on the paint thread; no disk, network or waits."""
    def __init__(self, window, source, duration, clock=time.monotonic):
        self.window, self.file, self.duration, self.clock = window, digest(source), duration, clock
        self.owner = uuid.uuid4().hex
        self.last = None
        self.sent = 0
        self.catalogue = OrderedDict()
        self.token = None
        self.lock = threading.Lock()
        self.closed = False

    def images(self, target, direction=1):
        with self.lock:
            if self.closed:
                return [None]*3
            try:
                return self._images(target, direction)
            finally:
                if self.closed:
                    self._clear_request()

    def _images(self, target, direction):
        session = read(self.window, SESSION)
        if session.get('file') != self.file or session.get('duration') != self.duration:
            return [None]*3
        token = session.get('token')
        if not isinstance(token, str) or not token:
            return [None]*3
        if token != self.token:
            self.catalogue.clear()
            self.token = token
        target = max(0, min(int(self.duration-.1), int(target)))
        identity = (token, target, direction)
        if identity != self.last or self.clock()-self.sent > 1:
            self.window.setProperty(REQUEST, json.dumps(dict(token=token, owner=self.owner,
                target=target, direction=direction, at=self.clock())))
            self.last, self.sent = identity, self.clock()
        reply = read(self.window, REPLY)
        if reply.get('token') == token and reply.get('owner') == self.owner:
            rows = reply.get('images')
            if isinstance(rows, list) and len(rows) == 3:
                for row in rows:
                    if (isinstance(row, dict) and isinstance(row.get('path'), str)
                            and isinstance(row.get('time'), (int, float))
                            and math.isfinite(row['time']) and 0 <= row['time'] < self.duration):
                        self.catalogue[row['time']] = row
                        self.catalogue.move_to_end(row['time'])
                while len(self.catalogue) > 64:
                    self.catalogue.popitem(last=False)
        # A sparse cache must not move the same picture between three boxes.
        # Match the selected second, never a future frame or rounded bucket.
        result = [None]*3
        available = [t for t in self.catalogue if 0 <= target-t <= 5]
        if available:
            t = min(available, key=lambda t: (abs(t-target), t))
            result[1] = self.catalogue[t]
        return result

    def close(self):
        self.closed = True
        # Back/Stop must not wait for even a delayed native property call in
        # the painter. That call's finally block clears its late request.
        if self.lock.acquire(blocking=False):
            try:
                self._clear_request()
            finally:
                self.lock.release()

    def status(self):
        """Fixed messages only; no media access or exception text on the painter."""
        if self.closed:
            return ''
        status = read(self.window, STATUS)
        if status.get('file') == self.file and status.get('duration') == self.duration:
            if status.get('target') is not None and (self.last is None or status['target'] != self.last[1]):
                return MESSAGES['settling']
            code = status.get('code')
            if isinstance(code, str) and code in MESSAGES:
                return MESSAGES[code]
        return 'Previews are unavailable for this playback.'

    def _clear_request(self):
        if read(self.window, REQUEST).get('owner') == self.owner:
            self.window.clearProperty(REQUEST)


class Watcher:
    def __init__(self, profile, addon, player, kodi, window, clock=time.monotonic,
                 decoder_factory=None, discover=None):
        from core.seek_preview import create_decoder
        self.profile, self.addon, self.player, self.kodi, self.window = profile, addon, player, kodi, window
        self.clock = clock
        self.decoder_factory = decoder_factory or create_decoder
        self.discover = discover or self._discover
        self.worker = None
        self.stop = threading.Event()
        self.identity = None
        self.token = None
        self.state = None
        self.started = 0
        self.retry_discovery = 0
        self.lock = threading.Lock()
        for name in (SESSION, REQUEST, REPLY, STATUS):
            self.window.clearProperty(name)

    def _discover(self):
        import xbmcvfs
        from lib.preview_dependencies import find_backend
        return find_backend(self.kodi, xbmcvfs.translatePath)

    def _snapshot(self):
        if self.addon.getSetting('seek_previews') != 'true':
            return None
        context = getattr(self.player, '_context', None)
        source = getattr(self.player, '_playing_file', None)
        if (not isinstance(context, dict) or context.get('kind') not in ('movie', 'series')
                or not context or not isinstance(source, str) or not source
                or getattr(self.player, '_live_file', None)
                or self.kodi.getSkinDir() != 'skin.freebird'
                or not self.player.isPlayingVideo() or self.player.getPlayingFile() != source
                or not self.kodi.getCondVisibility('Player.SeekEnabled')):
            return None
        # ISA/DRM and plugin/manifest sources are never opened by this worker.
        path = source.split('|', 1)[0]
        parsed = urlsplit(path)
        if parsed.scheme not in ('', 'file', 'http', 'https') and not (len(parsed.scheme) == 1 and path[1:2] == ':'):
            return None
        if parsed.path.lower().endswith(('.m3u8', '.mpd', '.ism', '.ts')):
            return None
        try:
            item = self.player.getPlayingItem()
            if any(item.getProperty(key) for key in ('inputstream', 'inputstreamaddon', 'inputstream.adaptive.license_type')):
                return None
        except (AttributeError, RuntimeError):
            return None
        duration, position = float(self.player.getTotalTime()), float(self.player.getTime())
        if not math.isfinite(duration) or not 30 <= duration <= 86400 or not math.isfinite(position):
            return None
        identity = (source, getattr(self.player, '_track_session', None), duration)
        blocked = (bool(getattr(self.player, '_resume_target_ms', 0))
                   or bool(getattr(self.player, '_resume_rewind_pending', False))
                   or self.kodi.getCondVisibility('Player.Caching | Player.Seeking'))
        paused = self.kodi.getCondVisibility('Player.Paused')
        try:
            # Kodi rounds this absolute percentage. Subtract half a percent
            # rather than mistake rounding for many seconds of available data.
            ahead = ((float(self.kodi.getInfoLabel('Player.ProgressCache'))-.5) / 100 * duration) - position
        except (TypeError, ValueError):
            ahead = 0
        # Unknown/low buffer: show cached pictures, make nothing new.
        local = parsed.scheme in ('', 'file') or len(parsed.scheme) == 1
        return identity, dict(position=position, duration=duration,
                              allowed=not blocked and (local or paused or ahead >= 15), at=self.clock())

    def tick(self):
        try:
            snapshot = self._snapshot()
        except (AttributeError, RuntimeError, ValueError, TypeError):
            snapshot = None
        if snapshot is None:
            self.close()
            return
        identity, state = snapshot
        if identity != self.identity:
            self.close()
            # An old decoder must exit before the next session starts one.
            if self.worker is not None and self.worker.is_alive():
                return
            self.identity, self.started = identity, self.clock()
            self.stop = threading.Event()
            self.token = uuid.uuid4().hex
            self._status(identity, self.token, 'starting')
        with self.lock:
            self.state = state
        if self.worker is not None and self.worker.is_alive():
            return
        if self.retry_discovery and self.clock() >= self.retry_discovery:
            self.worker = None
            self.retry_discovery = 0
        if self.clock()-self.started < 5 or self.worker is not None:
            return
        worker = threading.Thread(target=self._run, args=(identity, self.token, self.stop),
                                  daemon=True, name='freebird-seek-previews')
        self.worker = worker
        try:
            worker.start()
        except RuntimeError:
            self.worker = None
            raise

    def close(self):
        self.stop.set()
        self.identity = None
        self.retry_discovery = 0
        with self.lock:
            self.state = None
        if self.token and read(self.window, SESSION).get('token') == self.token:
            for name in (SESSION, REQUEST, REPLY):
                self.window.clearProperty(name)
        if self.token and read(self.window, STATUS).get('token') == self.token:
            self.window.clearProperty(STATUS)
        self.token = None
        if self.worker is not None and not self.worker.is_alive():
            self.worker = None

    def _status(self, identity, token, code, target=None):
        if self.identity != identity or self.token != token or self.stop.is_set():
            return
        value = dict(token=token, file=digest(identity[0]), duration=identity[2], code=code)
        if target is not None:
            value['target'] = target
        if read(self.window, STATUS) != value:
            self.window.setProperty(STATUS, json.dumps(value))

    def _run(self, identity, token, stop):
        from core.seek_preview import Cache, RATE_BYTES, FRAME_BYTES, PreviewFailure
        source, track, duration = identity
        decoder = None

        def alive():
            if stop.is_set():
                return False
            try:
                return (self.player.isPlayingVideo() and self.player.getPlayingFile() == source
                        and getattr(self.player, '_track_session', None) == track)
            except RuntimeError:
                return False

        def state_now():
            with self.lock:
                return dict(self.state or {})

        def allowed():
            state = state_now()
            return (alive() and state.get('allowed', False) and self.clock()-state.get('at', 0) < 2.5
                    and not self.kodi.getCondVisibility('Player.Caching | Player.Seeking'))

        def request():
            value = read(self.window, REQUEST)
            try:
                if (value.get('token') == token and isinstance(value.get('owner'), str)
                        and 0 <= self.clock()-float(value['at']) < 2
                        and isinstance(value.get('target'), (int, float))
                        and value.get('direction') in (-1, 1)
                        and 0 <= float(value['target']) < duration):
                    return value
            except (KeyError, TypeError, ValueError):
                pass
            return {}

        try:
            binary = self.discover()
            if not alive():
                return
            if not binary:
                # Kodi's optional addon installation can finish after playback
                # has started. Recheck locally without reopening media or UI.
                self.retry_discovery = self.clock() + 10
                self._status(identity, token, 'missing')
                return
            cache = Cache(self.profile, digest(source + '\n' + str(duration)))
            self._status(identity, token, 'starting')
            decoder = self.decoder_factory(binary, source)
            if not alive():
                return
            self.window.setProperty(SESSION, json.dumps(dict(token=token, file=digest(source), duration=duration)))
            failures, next_work, last_reply = {}, 0, None
            failure_codes = {}
            retried = set()
            background_bytes = 0
            observed_focus, focus_since = None, 0
            while alive() and not stop.wait(.05):
                state = state_now()
                focus = request()
                target = focus.get('target', state.get('position', 0))
                focus_key = (focus.get('owner'), focus.get('target'))
                if focus_key != observed_focus:
                    observed_focus, focus_since = focus_key, time.monotonic()
                if focus:
                    rows = [None, cache.preceding(target), None]
                    reply = json.dumps(dict(token=token, owner=focus['owner'], target=target, images=rows))
                    if reply != last_reply and alive():
                        self.window.setProperty(REPLY, reply)
                        last_reply = reply
                    if rows[1]:
                        continue
                    if time.monotonic()-focus_since < SETTLE_SECONDS:
                        self._status(identity, token, 'settling', target)
                        continue
                if not allowed():
                    self._status(identity, token, 'waiting')
                    continue
                if decoder.reader.cooldown() > 0:
                    self._status(identity, token, 'budget')
                    continue
                # Keep speculative background reads bounded across playback.
                if not focus and background_bytes + FRAME_BYTES > RATE_BYTES // 4:
                    continue
                if not focus and self.clock() < next_work:
                    continue
                candidates = plan(target, state.get('position', 0), duration, focus.get('direction', 1), bool(focus))
                candidate = next((t for t in candidates if t not in cache.images
                                  and failures.get(t, 0) <= self.clock()), None)
                if candidate is None:
                    if focus and target in cache.images:
                        self._status(identity, token, 'no_frame', target)
                    elif focus and target in failure_codes:
                        self._status(identity, token, failure_codes[target], target)
                    continue

                def relevant():
                    newest = request()
                    # New input supersedes background and distant focus work.
                    return allowed() and (newest.get('owner'), newest.get('target')) == focus_key

                failure = 'failed'
                spent_before = decoder.reader.spent
                blocks_before = set(decoder.reader.cache)
                try:
                    self._status(identity, token, 'generating', target)
                    ok = cache.make(candidate, decoder, relevant)
                except PreviewFailure as error:
                    ok = False
                    failure = error.reason if error.reason in MESSAGES else 'failed'
                except Exception:
                    ok = False  # Never log a decoder/source exception or private address.
                if not focus:
                    background_bytes += max(0, decoder.reader.spent-spent_before)
                if not alive():
                    break
                if not ok and relevant() and not getattr(decoder, 'busy', False):
                    retry = (bool(focus) and failure == 'timeout' and candidate not in retried
                             and bool(set(decoder.reader.cache)-blocks_before))
                    if retry:
                        retried.add(candidate)
                        failure = 'retrying'
                    failures[candidate] = self.clock() + (.15 if retry else 1 if failure == 'budget' else 60)
                    failure_codes[candidate] = failure
                    self._status(identity, token, failure, target)
                # Yield bandwidth/CPU between speculative pictures. Focused
                # work starts immediately on the next mailbox poll.
                next_work = self.clock() + (0 if focus else 1)
        except Exception:
            if alive():
                self.retry_discovery = self.clock() + 10
                self._status(identity, token, 'decoder_failed')
        finally:
            if decoder is not None:
                try:
                    decoder.close()
                except Exception:
                    pass
            if read(self.window, SESSION).get('token') == token:
                for name in (SESSION, REPLY):
                    self.window.clearProperty(name)
