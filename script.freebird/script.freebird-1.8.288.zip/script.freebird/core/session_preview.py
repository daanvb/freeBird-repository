"""Persistent native preview adapter; source URLs/authentication stay in Python."""
import json
from pathlib import Path
import re
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler

from core.native_preview import Client, NativeUnavailable
from core.file_chapters import Unavailable
from core.seek_preview import (Decoder, PreviewReader, PreviewFailure, valid_image,
                               RangeServer, FRAME_BYTES, RATE_BYTES, MEMORY_BYTES)

PREFIX = 'freebirdpreviewsession://'
PREPARE_SECONDS = 10
PREPARE_SOCKET_SECONDS = .5


class SparseReader(PreviewReader):
    """Offset-based cache without the aligned block overfetch penalty.

    Start with 256 KiB; grow to 512 KiB only for a sequential continuation.
    This bounds overfetch while amortising round-trip cost for large indexes.
    Authentication, validators, cancellation and rolling accounting are shared
    with the existing reader. Entries and retained bytes are both bounded.
    """
    def __init__(self, source):
        super().__init__(source)
        self.memory = 0
        self.last_end, self.last_size = -1, 0
        self.preparing = False

    def span(self, offset, count):
        with self.lock:
            try:
                self.check()
                if offset < 0 or not 0 < count <= 512*1024: raise PreviewFailure('range')
                for start, data in list(self.cache.items()):
                    if start <= offset < start+len(data):
                        self.cache_hits += 1; self.cache.move_to_end(start)
                        return data[offset-start:offset-start+count]
                ahead = min(512*1024, self.last_size*2) if offset == self.last_end else 256*1024
                length = max(count, ahead)
                if self.total is not None: length = min(length, self.total-offset)
                following = [start for start in self.cache if start > offset]
                if following: length = min(length, min(following)-offset)
                if length <= 0: return b''
                self._expire_reads()
                # Leave one complete picture's allowance for foreground work.
                ceiling = RATE_BYTES-FRAME_BYTES if self.preparing else RATE_BYTES
                if self.recent_bytes+length > ceiling: raise PreviewFailure('budget')
                if self.frame_bytes+length > FRAME_BYTES or self.requests >= 80:
                    raise PreviewFailure('read_limit')
                self.requests += 1; self.frame_bytes += length; self.spent += length
                self.recent.append((self.clock(), length)); self.recent_bytes += length
                if self.local is not None:
                    with self.local.open('rb') as handle:
                        handle.seek(offset); data = handle.read(length)
                    self.received(len(data))
                else: data = self.remote(offset, length)
                self.check()
                self.last_end, self.last_size = offset+len(data), len(data)
                self.cache[offset] = data; self.memory += len(data)
                while self.memory > MEMORY_BYTES or len(self.cache) > 256:
                    _, old = self.cache.popitem(last=False); self.memory -= len(old)
                return data[:count]
            except PreviewFailure as error:
                self.failure = error
                raise


class SessionClient(Client):
    def __init__(self, request, prefix=PREFIX):
        super().__init__(request, prefix)
        self.busy = False

    def capabilities(self):
        try:
            value = json.loads(self._call('capabilities/'))
        except (ValueError, TypeError) as error:
            raise NativeUnavailable('Invalid session capabilities') from error
        if (not isinstance(value, dict) or type(value.get('protocol')) is not int or
                value.get('protocol') != 2 or value.get('persistent') is not True or
                value.get('prepare') is not True or value.get('index_lease') is not True):
            raise NativeUnavailable('Persistent preview protocol required')
        return value

    def begin(self, port, token, container, milliseconds, size, prepare=False):
        if (type(port) is not int or not 1024 <= port <= 65535 or
                not isinstance(token, str) or not re.fullmatch('[0-9a-f]{32}', token) or
                container not in ('matroska', 'mov') or type(milliseconds) is not int or
                not 0 <= milliseconds <= 604800000 or type(size) is not int or
                not 16 <= size <= 999999999999 or type(prepare) is not bool or
                prepare and milliseconds != 0):
            raise ValueError('Invalid session request')
        identity = uuid.uuid4().hex
        operation = 'prepare' if prepare else 'start'
        reply = self._call('{}/{}/{}/{}/{}/{}/{}'.format(operation, identity, port, token, container, milliseconds, size))
        self.busy = reply == b'busy\n'
        if reply != b'accepted\n':
            raise NativeUnavailable('Session request rejected')
        self.current = identity
        return identity

    def prepared(self):
        reply = self._call('result/'+self.current)
        if reply == b'pending\n': return False
        if reply == b'timeout\n': raise PreviewFailure('timeout')
        if reply != b'prepared\n': raise NativeUnavailable('Index preparation unavailable')
        return True

    def metrics(self):
        try:
            result = json.loads(self._call('stats/'+self.current))
        except (ValueError, TypeError) as error:
            raise NativeUnavailable('Invalid session metrics') from error
        if (not isinstance(result, dict) or type(result.get('generation')) is not int or
                not 1 <= result['generation'] <= 999999999999):
            raise NativeUnavailable('Invalid session generation')
        return result

    def retire(self, token):
        return self._call('close/'+token)

    def renew(self, token, generation):
        reply = self._call('lease/{}/{}'.format(token, generation))
        if reply not in (b'retained\n', b'missing\n'):
            raise NativeUnavailable('Invalid index lease response')
        return reply == b'retained\n'


class SessionDecoder(Decoder):
    """Worker-owned persistent endpoint/index with bounded optional preparation."""
    supports_preparation = True
    def __init__(self, source, client):
        super().__init__(None, source, reader_factory=SparseReader)
        self.client = client
        self.client.capabilities()
        self.actual_time = None
        self.metrics = None
        self.operation = threading.Lock()
        self.preempt = threading.Event()
        self.closed = threading.Event()
        self.preparation_attempted = False
        self.preparation = None
        self.generation = None
        self.busy = False

    def maintain(self, owns_source):
        """Playback worker heartbeat, normally every ten seconds; no downloads.

        Ownership is distinct from bandwidth eligibility. A buffering playback
        may retain its already parsed index, but may not prepare or read more.
        False ownership closes the source; missed/expired leases never restart it.
        This callback must not run on the UI thread (close drains active reads).
        """
        if not owns_source():
            self.close()
            return False
        if not self.operation.acquire(blocking=False): return False
        try:
            if self.closed.is_set() or self.generation is None: return False
            if self.client.renew(self.token[1:], self.generation): return True
            self.generation = None
            return False
        finally: self.operation.release()

    def _serve(self):
        reader, token = self.reader, self.token
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args): pass
            def do_GET(self):
                if self.path != token:
                    self.send_error(404); return
                try:
                    self.connection.settimeout(1)
                    reader.check()
                    match = re.fullmatch(r'bytes=(\d+)-(\d+)', self.headers.get('Range', ''))
                    if not match: self.send_error(416); return
                    start, end = map(int, match.groups())
                    if not 0 <= start <= end < reader.total or end-start+1 > 512*1024:
                        self.send_error(416); return
                    self.send_response(206)
                    self.send_header('Content-Range', 'bytes {}-{}/{}'.format(start, end, reader.total))
                    self.send_header('Content-Length', str(end-start+1))
                    self.send_header('Connection', 'close'); self.end_headers()
                    while start <= end:
                        data = reader.span(start, end-start+1)
                        if not data: return
                        self.wfile.write(data); start += len(data)
                except (OSError, ValueError): pass
                finally: self.close_connection = True
        self.server = RangeServer(('127.0.0.1', 0), Handler)
        self.server_thread = threading.Thread(target=self.server.serve_forever,
                                              kwargs={'poll_interval': .05}, daemon=True)
        self.server_thread.start()

    def _begin(self, alive, prepare=False):
        self.busy = self.client.busy = False
        if not self.client.release():
            self.busy = True
            raise NativeUnavailable('Previous job still stopping')
        self.reader.begin(alive)
        self.reader.preparing = prepare
        self.reader.socket_seconds = PREPARE_SOCKET_SECONDS if prepare else 5
        if prepare: self.reader.deadline = self.reader.attempt_started+PREPARE_SECONDS
        header = self.reader.span(0, 16) if self.reader.total is None or self.server is None else None
        if header is not None:
            if header[:4] == bytes.fromhex('1a45dfa3'): self.container = 'matroska'
            elif header[4:8] in (b'ftyp', b'moov', b'wide', b'free'): self.container = 'mov'
            else: raise PreviewFailure('container')
        if self.server is None:
            self._serve()
        self.actual_time = None
        self.metrics = None
        self.reader.phase = 'frame'

    def _retire(self):
        self.generation = None
        self.reader.alive = lambda: False
        try:
            self.client.cancel()
        finally:
            try: self.client.retire(self.token[1:])
            finally: self._stop_server()

    def prepare(self, eligible):
        """One optional attempt per source, off the UI thread, before scrub.

        Eligibility must include playback health/headroom. Loss of eligibility,
        foreground demand, timeout or failure permanently consumes this attempt.
        The short preparation socket bound limits teardown behind blocked I/O.
        """
        with self.operation:
            if self.preparation_attempted or self.closed.is_set() or self.preempt.is_set():
                return False
            if not eligible(): return False  # defer without spending the attempt
            self.preparation_attempted = True
            started = time.monotonic()
            ok, reason = False, 'unavailable'
            try:
                self._begin(lambda: not self.preempt.is_set() and not self.closed.is_set() and eligible(), True)
                self.client.begin(self.server.server_port, self.token[1:], self.container,
                                  0, self.reader.total, prepare=True)
                while True:
                    self.reader.check()
                    try:
                        prepared = self.client.prepared()
                    except NativeUnavailable:
                        self.reader.check()  # Preserve the proxy's specific failure.
                        raise
                    if prepared:
                        self.reader.check()
                        self.metrics = self.client.metrics()
                        self.generation = self.metrics['generation']
                        ok, reason = True, 'prepared'
                        return True
                    time.sleep(.005)
            except (Unavailable, NativeUnavailable, OSError) as error:
                reason = 'cancelled' if self.preempt.is_set() or self.closed.is_set() or not eligible() else getattr(error, 'reason', 'unavailable')
                return False
            finally:
                if not ok: self._retire()
                self.preparation = dict(ok=ok, reason=reason, seconds=round(time.monotonic()-started, 3),
                                        bytes=self.reader.frame_bytes, native=self.metrics)
                self.reader.alive = lambda: False  # no work between operations

    def extract(self, target, destination, alive):
        self.preempt.set()  # signal before waiting for preparation's reader drain
        with self.operation:
            if self.closed.is_set(): raise Unavailable('Preview closed')
            return self._extract(target, destination, alive)

    def _extract(self, target, destination, alive):
        try:
            self._begin(lambda: not self.closed.is_set() and alive())
            self.client.begin(self.server.server_port, self.token[1:], self.container,
                              int(target*1000), self.reader.total)
            while True:
                self.reader.check()
                try:
                    result = self.client.poll()
                except NativeUnavailable:
                    self.reader.check()  # Preserve timeout/budget evidence from I/O.
                    raise
                if result is not None:
                    self.reader.check()
                    stamp, jpeg = result
                    self.metrics = self.client.metrics()
                    self.generation = self.metrics['generation']
                    self.actual_time = stamp/1000
                    Path(destination).write_bytes(jpeg)
                    return valid_image(destination)
                time.sleep(.005)
        except Exception as error:
            self.busy |= self.client.busy
            if isinstance(error, PreviewFailure) and error.reason == 'timeout' and error.evidence is None:
                error.evidence = self.reader.evidence()
            try:
                if self.client.current is not None:
                    self.metrics = self.client.metrics()
            except (ValueError, NativeUnavailable): pass
            # Error recovery retires the endpoint too: no old proxy request can
            # inherit the next attempt's deadline/eligibility callback.
            self._retire()
            raise

    def close(self):
        self.closed.set()
        self.preempt.set()
        with self.operation:
            self._retire()
