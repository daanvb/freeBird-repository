"""Read-only texture-cache readiness samples; never claim GPU render completion."""
import time
from lib.request_budget import Pool

_PROBES = Pool(workers=1, pending=4)


class Sampler:
    def __init__(self):
        self.entries = {}
        self.pending = None
        self.next_at = 0

    def sample(self, urls, profile, clock=time.monotonic):
        from lib.fast_posters import cache_state
        from lib.perf_trace import log
        now = clock()
        urls = tuple(dict.fromkeys(url for url in urls if isinstance(url, str)
                     and url.startswith(('https://', 'http://', 'image://'))))[:4]
        # Source URLs are transient process memory only, never written to the report.
        self.entries = {url: self.entries.get(url, [now, False, 0]) for url in urls}
        if self.pending and self.pending.done():
            try:results = self.pending.result()
            except Exception:results = []
            self.pending = None
            for url, started, ready, sampled in results:
                entry = self.entries.get(url)
                if not entry or entry[0] != started or entry[1]:continue
                entry[2] += 1
                if ready is True or ready is None or sampled - started >= 120:
                    stage = 'artwork.cache_ready' if ready is True else 'artwork.cache_unknown' if ready is None else 'artwork.cache_pending'
                    log(stage, profile=profile, started=started,
                        probes=entry[2], initial_hit=int(ready is True and entry[2] == 1))
                    entry[1] = True
        for entry in self.entries.values():
            if not entry[1] and now - entry[0] >= 120:
                log('artwork.cache_pending', started=entry[0], profile=profile, probes=entry[2])
                entry[1] = True
        if self.pending or now < self.next_at:return
        waiting = sorted(((url, entry[0]) for url, entry in self.entries.items() if not entry[1]),
                         key=lambda pair: self.entries[pair[0]][2])[:2]
        if not waiting:return
        self.next_at = now + 1
        def probe():
            return [(url, started, cache_state(url), clock()) for url, started in waiting]
        self.pending = _PROBES.submit(probe)


def tick(window, profile):
    """Optional inspection must never interrupt navigation or progress recovery."""
    try:_tick(window, profile)
    except Exception:pass  # A retired/transient native control is not a cache miss.


def _tick(window, profile):
    """Called only by an active, unobstructed window's existing browse pump."""
    if window.closed or getattr(window, "preview_suspended", False):return
    from lib.input_guard import idle
    if not idle(window):return
    import xbmc
    if xbmc.Player().isPlaying():return
    cid = window.getFocusId()
    if isinstance(window.__dict__.get('rows'), dict):
        rows = window.rows.get(cid, [])
        if not rows:return
        size, art = len(rows), 'poster'
    else:
        # Episode thumbnails only; never inspect stream/source lists.
        if cid != 501:return
        size, art = window.getControl(cid).size(), 'thumb'
    control = window.getControl(cid)
    pos = control.getSelectedPosition()
    if not 0 <= pos < size:return
    urls = [control.getListItem(index).getArt(art)
            for index in range(max(0, pos-1), min(size, pos+3))]
    sampler = window.__dict__.get('_artwork_sampler')
    if sampler is None:sampler = window._artwork_sampler = Sampler()
    sampler.sample(urls, profile)
