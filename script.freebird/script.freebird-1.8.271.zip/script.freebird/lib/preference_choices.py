"""Selectable installed providers and languages, keeping stored values stable."""
LANGUAGES = ('English', 'Dutch', 'German', 'French', 'Spanish', 'Italian', 'Portuguese',
             'Polish', 'Czech', 'Swedish', 'Norwegian', 'Danish', 'Finnish', 'Greek',
             'Turkish', 'Arabic', 'Hindi', 'Chinese', 'Japanese', 'Korean', 'Bosnian',
             'Croatian', 'Serbian', 'Russian', 'Ukrainian')


def provider_names(providers):
    names = []
    for provider in providers:
        manifest = provider.get('manifest') or {}
        if not any(resource == 'stream' or isinstance(resource, dict) and resource.get('name') == 'stream'
                   for resource in manifest.get('resources', [])):
            continue
        name = str(manifest.get('name') or '').strip()
        if name and name not in names:names.append(name)
    return sorted(names, key=str.casefold)


def choices(setting, value, providers):
    if setting == 'source_provider':
        from lib.autoplay_ranking import provider_group
        value=provider_group(value)
        available = {provider_group(name) for name in provider_names(providers)}
        values = [''] + [name for name in ('AIOStreams', 'Usenet', 'Pengu') if name in available]
        labels = ['Any provider'] + values[1:]
    elif setting == 'source_language':
        values = ['Any'] + list(LANGUAGES)
        labels = ['Any language'] + values[1:]
        value = value or 'English'
    else:
        values = ['https://v3-cinemeta.strem.io/manifest.json']
        labels = ['Official Cinemeta']
        for provider in providers:
            manifest = provider.get('manifest') or {}
            url = provider.get('transportUrl')
            if manifest.get('catalogs') and url and url not in values:
                values.append(url);labels.append(str(manifest.get('name') or 'Installed catalogue'))
    if value and value not in values and setting not in ('source_provider', 'manifest'):
        values.append(value);labels.append('Current saved preference' if setting == 'manifest' else value)
    selected = values.index(value) if value in values else 0
    return labels, values, selected
