"""Local skip buttons backed by IntroDB's free read API.

Read-only integration: one lookup per playback identity with a 24h local cache.
No IntroDB API key or Stremio credential is sent to IntroDB.
"""
import json
import math
import threading
import time
from pathlib import Path
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler

import xbmc
import xbmcgui

from account import Store
from lib.theme import window as themed_window

INTRODB_ORIGIN = "https://api.introdb.app"
CACHE_SECONDS = 24 * 60 * 60
TIMEOUT_SECONDS = 6
ROOT = str(Path(__file__).resolve().parents[1])
SEGMENT_ORDER = ("recap", "intro", "outro", "post_credits")
LABELS = {
    "intro": "Skip Intro",
    "recap": "Skip Recap",
    "outro": "Skip Outro",
    "post_credits": "Skip Post-Credits",
}


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def _preferences():
    from addon_state import get_addon
    addon = get_addon()
    return {name: addon.getSetting('introdb_' + name) != 'false'
            for name in SEGMENT_ORDER}


def _introdb_enabled():
    # IntroDB reads are free; Strem4Kodi uses a local opt-out setting.
    from addon_state import get_addon
    return get_addon().getSetting('introdb_enabled') != 'false'


def _identity(kind, value):
    raw = str(value or "").strip()
    if kind == "series":
        parts = raw.split(":")
        if len(parts) != 3 or not parts[0].startswith("tt"):
            return None
        try:
            season, episode = int(parts[1]), int(parts[2])
        except (TypeError, ValueError):
            return None
        if season < 0 or episode < 1:
            return None
        return {"imdb_id": parts[0], "season": season, "episode": episode}
    if kind == "movie" and raw.startswith("tt"):
        return {"imdb_id": raw, "is_movie": "true"}
    return None


def _cache_key(identity):
    if identity.get("is_movie") == "true":
        return "movie:" + identity["imdb_id"]
    return "series:{}:{}:{}".format(identity["imdb_id"], identity["season"], identity["episode"])


def _clean_segment(name, row):
    if not isinstance(row, dict):
        return None
    try:
        start = float(row.get("start_sec"))
        end = float(row.get("end_sec"))
    except (TypeError, ValueError):
        return None
    if not math.isfinite(start) or not math.isfinite(end) or start < 0 or end <= start or end - start > 1800:
        return None
    return {
        "type": name,
        "label": LABELS.get(name, "Skip"),
        "start": start,
        "end": end,
        "confidence": float(row.get("confidence") or 0),
    }


def fetch_segments(profile, kind, value, opener=None, now=None):
    identity = _identity(kind, value)
    if not identity:
        return []
    now = int(time.time()) if now is None else int(now)
    store = Store(Path(profile) / "introdb-cache")
    key = _cache_key(identity)
    try:
        cache = store.load()
    except Exception:
        cache = {}
    row = cache.get(key) if isinstance(cache, dict) else None
    if isinstance(row, dict) and now - int(row.get("checked_at") or 0) < CACHE_SECONDS:
        return row.get("segments") if isinstance(row.get("segments"), list) else []
    query = urlencode(identity)
    url = INTRODB_ORIGIN + "/segments?" + query
    parsed = urlsplit(url)
    if parsed.scheme != "https" or parsed.netloc != "api.introdb.app" or parsed.path != "/segments":
        return []
    client = opener or build_opener(_NoRedirect())
    try:
        with client.open(Request(url, headers={"Accept": "application/json", "User-Agent": "Strem4Kodi/1.1"}), timeout=TIMEOUT_SECONDS) as response:
            data = response.read(128 * 1024 + 1)
        if len(data) > 128 * 1024:
            return []
        payload = json.loads(data.decode("utf-8"))
    except Exception:
        return []
    segments = []
    for name in SEGMENT_ORDER:
        item = _clean_segment(name, payload.get(name) if isinstance(payload, dict) else None)
        if item:
            segments.append(item)
    cache[key] = {"checked_at": now, "segments": segments}
    # Keep cache bounded to recent lookups only.
    if len(cache) > 100:
        cache = dict(sorted(cache.items(), key=lambda kv: int(kv[1].get("checked_at") or 0), reverse=True)[:100])
    try:
        store.save(cache)
    except Exception:
        pass
    return segments


class SkipWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.label = str(kwargs.pop("label", "Skip"))
        self.on_skip = kwargs.pop("on_skip", None)
        self.valid = kwargs.pop('valid',None)
        self.expiry = threading.Event()
        self.expiry_started = False
        super().__init__(*args, **kwargs)

    def onInit(self):
        self.setProperty("skip_label", self.label)
        self.setFocusId(201)
        if self.valid and not self.expiry_started:
            self.expiry_started=True
            try:threading.Thread(target=self._expire,daemon=True).start()
            except RuntimeError:
                self.expiry_started=False
                self.close()
                raise

    def _expire(self):
        # A slow service task must not leave an expired button over the film.
        # Use playback position, so pausing doesn't consume the intro window.
        while not self.expiry.wait(.2):
            try:valid=self.valid()
            except Exception:valid=False
            if not valid:
                self.close()
                return

    def close(self):
        self.expiry.set()
        super().close()

    def onClick(self, control_id):
        if control_id == 201:
            callback = self.on_skip
            self.close()
            if callable(callback):
                try:
                    callback()
                except Exception:
                    pass

    def onAction(self, action):
        if action.getId() in (10, 92, 216, 247):
            self.close()


class SkipSegmentWatcher:
    def __init__(self, profile):
        self.profile = Path(profile)
        self.player = xbmc.Player()
        self.current_hash = None
        self.segments = []
        self.dismissed = set()
        self.loading = False
        self.requested_hash = None
        self.window = None
        self.visible_type = None
        self.lock = threading.Lock()

    def close(self, dismiss=False):
        if dismiss and self.visible_type:
            self.dismissed.add(self.visible_type)
        if self.window:
            try:
                self.window.close()
            except Exception:
                pass
        self.window = None
        self.visible_type = None

    def _current_hash(self):
        try:
            if not self.player.isPlayingVideo():
                return None
            from source_probe import error_video
            if error_video(self.player.getPlayingFile()):return None
            import hashlib
            return hashlib.sha256(self.player.getPlayingFile().encode()).hexdigest()
        except Exception:
            return None

    def _context(self, digest):
        try:
            context = Store(self.profile / "playback").load()
            return context if context.get("url_hash") == digest else None
        except Exception:
            return None

    def _load(self, digest):
        try:
            context = self._context(digest)
            segments = []
            if context and _introdb_enabled():
                enabled = _preferences()
                segments = [segment for segment in fetch_segments(self.profile, context.get("kind"), context.get("id")) if enabled.get(segment.get("type"), True)]
            with self.lock:
                if self.current_hash == digest:
                    self.segments = segments
        finally:
            with self.lock:
                self.loading = False

    def _start(self, digest):
        self.close()
        self.current_hash = digest
        self.segments = []
        self.dismissed = set()
        self._request_current()

    def _request_current(self):
        with self.lock:
            digest = self.current_hash
            if not digest or self.loading or self.requested_hash == digest:
                return
            self.loading = True
            self.requested_hash = digest
        try:
            threading.Thread(target=self._load, args=(digest,), daemon=True).start()
        except RuntimeError:
            with self.lock:
                self.loading = False
                self.requested_hash = None
            raise

    def _seek(self, segment):
        try:
            self.player.seekTime(float(segment["end"]) + 0.15)
        finally:
            self.dismissed.add(segment["type"])

    def _show(self, segment):
        if self.window or segment["type"] in self.dismissed:
            return
        self.visible_type = segment["type"]
        digest=self.current_hash
        def valid():
            return (self.current_hash==digest and self._current_hash()==digest and
                    segment.get('start',0)-1.5 <= float(self.player.getTime()) < segment['end']-.25)
        try:
            self.window = themed_window(
                SkipWindow, "script-stremio-skip.xml", ROOT, "Main", "1080i",
                label=segment["label"], on_skip=lambda: self._seek(segment),valid=valid
            )
            self.window.show()
            if segment['type'] == 'outro':
                from lib.credits_watched import signal
                signal(self.profile, self.player, expected_hash=self.current_hash)
        except Exception:
            self.window = None
            self.visible_type = None

    def tick(self):
        digest = self._current_hash()
        if digest != self.current_hash:
            self._start(digest)
        self._request_current()
        if not digest:
            self.close()
            return
        try:
            position = float(self.player.getTime())
        except Exception:
            return
        active = None
        with self.lock:
            for segment in self.segments:
                # Give the button a brief lead-in and keep it through the segment.
                if segment["start"] - 1.5 <= position < segment["end"] - 0.25:
                    active = segment
                    break
        if active:
            try:
                up_next = xbmcgui.Window(10000).getProperty('strem4kodi.up_next.visible') == 'true'
            except Exception:
                up_next = False
            if active['type'] == 'outro' and up_next:
                self.close()
                return
            if self.visible_type != active["type"]:
                self.close()
            self._show(active)
        elif self.window:
            self.close()
