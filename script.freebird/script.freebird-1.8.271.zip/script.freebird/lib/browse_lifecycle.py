"""Pause browse rendering across screensaver/display sleep and settle on wake.

Poll Kodi's display state rather than activating/closing somebody else's window.
Wall-clock gaps also cover hosts whose monotonic clock stops during suspend.
"""
import time

DISPLAY_ASLEEP = 'System.ScreenSaverActive | System.DPMSActive'


def display_asleep(kodi):
    return kodi.getCondVisibility(DISPLAY_ASLEEP) is True


class BrowseLifecycle:
    def __init__(self, kodi, gui, clock=time.monotonic, wall=time.time):
        self.kodi, self.gui = kodi, gui
        self.clock, self.wall = clock, wall
        self.previous = None
        self.paused = False
        self.settle_until = 0
        self.recover = False
        self.focus = None

    def tick(self, window):
        now, wall = self.clock(), self.wall()
        gap = self.previous is not None and (
            now - self.previous[0] > 5 or wall - self.previous[1] > 5)
        self.previous = now, wall
        if display_asleep(self.kodi):
            self.paused = True
            return False
        if self.paused or gap:
            self.paused = False
            self.recover = True
            self.settle_until = now + 1
        if now < self.settle_until:
            return False
        self._focus(window)
        return True

    def _focus(self, window):
        from lib.hero_preview import NO_DIALOG
        owner = window.__dict__.get('browse_window_id') or window.__dict__.get('_context_window_id')
        if (type(owner) is not int or not 13000 <= owner < 13200
                or self.gui.getCurrentWindowId() != owner
                or self.gui.getCurrentWindowDialogId() not in NO_DIALOG
                or window.__dict__.get('closed') is True
                or window.__dict__.get('_ui_initializing') is True
                or type(window.__dict__.get('_input_owner')) is int
                or window.__dict__.get('preview_suspended') is True
                or self.kodi.Player().isPlayingVideo() is True):
            return
        for name in ('_navigation_cover', '_return_cover'):
            cover = window.__dict__.get(name)
            if cover is not None and getattr(cover, 'closed', False) is not True:
                return
        for name in ('_streams_search_screen', '_streams_loading_screen'):
            session = window.__dict__.get(name)
            if session is not None and getattr(session, 'attempt', ''):
                return
        def usable(control):
            return (type(control) is int and control > 0
                    and self.kodi.getCondVisibility('Control.IsVisible({})'.format(control)) is True
                    and self.kodi.getCondVisibility('Control.IsEnabled({})'.format(control)) is True)
        try:focused = window.getFocusId()
        except RuntimeError:focused = 0  # Kodi raises when no control has focus.
        if usable(focused):
            self.focus = focused
            self.recover = False
        elif self.recover:
            # Restore only a previously focused, still usable control. No guessed
            # default, activation, selection reset or takeover from another window.
            if usable(self.focus):
                window.setFocusId(self.focus)
                self.recover = False


def pause(kodi, milliseconds):
    try:
        kodi.sleep(milliseconds)
    except Exception:
        # A failing native sleep must not turn recovery into a CPU spin loop.
        time.sleep(milliseconds / 1000.0)
