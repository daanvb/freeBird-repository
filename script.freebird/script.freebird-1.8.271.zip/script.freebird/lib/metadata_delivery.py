"""Progressive title presentation with a single end-to-end caller budget."""
from concurrent.futures import wait, FIRST_COMPLETED
import re

from protocol import fetch
from sources import supports
from provider_roles import is_aiometadata
from metadata_bridge import (HOME_MANIFEST, resolve_identity, normalize, _provider_meta,
                             _merge_metadata, _episode_reference)
from lib.request_budget import Budget


def details(kind, identity='', query='', providers=(), fetcher=fetch,
            on_partial=None, alive=lambda: True, seconds=20, budget=None):
    budget = budget or Budget(seconds, alive)
    results, preview, reference = [], {}, {}
    resolved = identity
    reference_job = None
    try:
        def request(url):
            remaining = budget.remaining()
            if not remaining:raise TimeoutError()
            return fetch(url, timeout=min(15, remaining)) if fetcher is fetch else fetcher(url)

        if identity:
            resolved, preview = resolve_identity(kind, identity, query, request)
        else:
            resolved, preview = budget.result(budget.submit(
                lambda: resolve_identity(kind, identity, query, request)), ('', {}))
        if not resolved:return normalize(preview, kind)
        # Start independent episode identity work alongside the primary, not after it.
        if kind == 'series' and re.fullmatch(r'tt\d+', str(resolved)):
            reference_job = budget.submit(lambda: _episode_reference(resolved, fetcher))

        def one(provider):return _provider_meta(provider, kind, resolved, request)

        def presentation():
            if not on_partial or not results or not budget.remaining():return
            value = _merge_metadata(kind, resolved, [dict(meta, videos=[]) for meta in results], {})
            # Presentation may appear early; episode identities/actions wait for final merge.
            value['videos'] = []
            value['_metadata_partial'] = True
            try:on_partial(value)
            except Exception:pass  # A transient presentation failure must not discard final metadata.

        primary = [p for p in providers if is_aiometadata(p)
                   and supports(p.get('manifest') or {}, kind, resolved, 'meta')]
        for provider in primary:
            result = budget.result(budget.submit(lambda p=provider: one(p)), {})
            if result:
                results.append(result)
                presentation()
                break
            if not budget.remaining():break

        required = ('name', 'description', 'poster', 'background', 'landscape', 'logo', 'genres', 'runtime')
        complete = bool(results) and all(results[0].get(field) for field in required)
        if kind == 'series':
            videos = results[0].get('videos', []) if results else []
            titles = [str(v.get('title') or v.get('name') or '').strip().casefold()
                      for v in videos]
            complete = complete and bool(videos) and not any(a and a == b for a, b in zip(titles, titles[1:]))
        rating_needed = any('ratings' in p.get('_preferred_roles', []) and p not in primary for p in providers)
        if budget.remaining() and (not complete or rating_needed):
            rows = [p for p in providers if p not in primary
                    and supports(p.get('manifest') or {}, kind, resolved, 'meta')]
            if kind == 'series' and re.fullmatch(r'tt\d+', str(resolved)):
                rows = [p for p in rows if p.get('transportUrl') != HOME_MANIFEST]
            needs_manifest = not (kind == 'series' and re.fullmatch(r'tt\d+', str(resolved))) and HOME_MANIFEST not in {p.get('transportUrl') for p in providers}
            # Configured supplements need not wait for the fallback manifest.
            # Keep provider ordering for role precedence despite out-of-order completion.
            jobs = {budget.submit(lambda p=p: one(p)): index for index, p in enumerate(rows)}
            if needs_manifest:jobs[budget.submit(lambda: request(HOME_MANIFEST))] = None
            supplements = {}
            base = list(results)
            while jobs and budget.remaining():
                ready, _ = wait(jobs, timeout=min(.05, budget.remaining()), return_when=FIRST_COMPLETED)
                for job in ready:
                    index = jobs.pop(job)
                    try:value = job.result()
                    except Exception:value = {}
                    if index is None:
                        if value and budget.remaining():
                            fallback = {'transportUrl': HOME_MANIFEST, 'manifest': value, 'fallback': True}
                            jobs[budget.submit(lambda: one(fallback))] = len(rows)
                    else:supplements[index] = value
                if ready:
                    results = base + [supplements[i] for i in sorted(supplements) if supplements[i]]
                    presentation()
        if reference_job:
            # Include an already-completed reference even if another provider used the budget.
            if reference_job.done():
                try:reference = reference_job.result() or {}
                except Exception:pass
            else:reference = budget.result(reference_job, {})
        if reference:results.append(reference)
        value = _merge_metadata(kind, resolved, results, reference)
        for key, item in preview.items():
            if value.get(key) in (None, '', [], {}):value[key] = item
        value['_metadata_budget_exhausted'] = not bool(budget.remaining()) and alive()
        return value
    finally:
        budget.close()
