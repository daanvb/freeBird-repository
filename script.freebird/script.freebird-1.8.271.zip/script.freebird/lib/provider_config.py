"""Device-local preferences, saved separately from concurrent account sync."""
from pathlib import Path
from account import Store, AccountError


def _load(profile):
    try:
        return Store(Path(profile) / 'providers').load()
    except AccountError:
        return {}  # A damaged preference file must not prevent account playback.


def account_configuration(store):
    """Read provider/login settings without loading the viewer's library."""
    from lib.viewer_profiles import ViewerAccount, _configuration
    if isinstance(store, ViewerAccount):
        try:
            return _configuration(store.directory, snapshot=False)
        except OSError:
            # A profile without an account file has the same empty state as load().
            return Store(store.directory).load()
    return store.load()


def state(profile, account=None):
    account = Store(profile).load() if account is None else account
    config = _load(profile)
    return dict(account, providerPreferences=config.get('providerPreferences') or {},
                disabledProviderRoles=config.get('disabledProviderRoles') or {},
                artworkRevision=config.get('artworkRevision', 0))


def toggle(profile, role, identity):
    from provider_roles import enabled, eligible, key, ROLES
    current = state(profile)
    provider = next((p for p in current.get('addons', []) if key(p) == identity), None)
    if (role not in ROLES or provider is None or not eligible(provider, role)
            or provider.get('id') in current.get('disabledAddons', [])):
        return False
    config = _load(profile)
    roles = dict(config.get('disabledProviderRoles') or {})
    disabled = set(roles.get(role, []))
    if enabled(current, provider, role):disabled.add(identity)
    else:disabled.discard(identity)
    roles[role] = sorted(disabled)
    config['disabledProviderRoles'] = roles
    if role in ('metadata', 'artwork', 'ratings'):
        config['artworkRevision'] = int(config.get('artworkRevision') or 0) + 1
    Store(Path(profile) / 'providers').save(config)
    return True


def choose(profile, role, value):
    from provider_roles import save_preference
    current = state(profile)
    save_preference(current, role, value)
    store = Store(Path(profile) / 'providers')
    config = _load(profile)
    config['providerPreferences'] = current['providerPreferences']
    store.save(config)


def refresh_artwork(profile):
    """Invalidate resolved posters without clearing catalogue/login/progress data."""
    store = Store(Path(profile) / 'providers')
    config = _load(profile)
    config['artworkRevision'] = int(config.get('artworkRevision') or 0) + 1
    store.save(config)
    return config['artworkRevision']


def hostname(provider):
    """Display only a transport hostname, excluding credentials and URL tokens."""
    from urllib.parse import urlsplit
    import re
    try:
        url=urlsplit(str(provider.get('transportUrl') or ''))
        host=url.hostname or ''
        if url.scheme not in ('http','https') or not re.fullmatch(r'[a-zA-Z0-9_.:-]{1,253}',host):
            return 'Host unavailable'
        return host.lower()
    except (ValueError,TypeError):
        return 'Host unavailable'
