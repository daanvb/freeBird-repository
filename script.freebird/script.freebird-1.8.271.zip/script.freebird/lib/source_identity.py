"""Reject explicit episode conflicts before ranking automatic candidates."""
import re
import unicodedata
from urllib.parse import unquote, urlsplit

EPISODE = re.compile(r'(?i)\bs(\d{1,3})[ ._-]*e(\d{1,3})(?!\d)|\b(\d{1,3})x(\d{1,3})(?!\d)')


def target(meta, identity):
    if meta.get('type') != 'series' or not identity:
        return None
    video = next((v for v in meta.get('videos') or [] if isinstance(v, dict) and v.get('id') == identity), {})
    from episode_identity import conflict
    if conflict(video or {'id':identity}, str(meta.get('id') or '')):
        return None
    try:
        return int(video['season']), int(video.get('episode', video.get('number')))
    except (KeyError, TypeError, ValueError, OverflowError):
        match = re.search(r':(\d+):(\d+)$', str(identity))
        return (int(match[1]), int(match[2])) if match else None


def words(value):
    text = unicodedata.normalize('NFKD', str(value)).encode('ascii', 'ignore').decode().casefold()
    text = re.sub(r"['’]", '', text)
    return tuple(w for w in re.findall(r'[a-z0-9]+', text)
                 if w not in ('the', 'a', 'an') and not re.fullmatch(r'(19|20)\d{2}', w))


def filenames(row, meta=None):
    """Independent provider filenames, including formatted media-file lines.

    Query strings and numeric pack indices are not episode evidence.
    """
    candidates=row.get('filename_candidates') or []
    if not isinstance(candidates,(list,tuple)):candidates=[]
    candidates=list(candidates)+[row.get('filename'),(row.get('card') or {}).get('filename')]
    # Some stream addons expose the selected file only inside their formatted
    # title/description. Extract a complete media filename beginning with this
    # series, not a loose mention of an episode elsewhere in the description.
    series=words((meta or {}).get('name') or '')
    if series:
        prefix=re.compile(r'(?i)(?<![a-z0-9])'+r'[ ._-]+'.join(map(re.escape,series))+r'(?![a-z0-9])')
        for field in ('title','description','detail','name','label'):
            for line in str(row.get(field) or '').splitlines():
                extension=re.search(r'(?i)\.(?:mkv|mp4|avi|m4v|webm|m2ts|ts)\b',line)
                match=prefix.search(line[:extension.end()]) if extension else None
                if match:candidates.append(line[match.start():extension.end()])
    try:
        linked=unquote(urlsplit(str(row.get('url') or '')).path).rsplit('/',1)[-1]
        if re.search(r'(?i)\.(mkv|mp4|avi|m4v|webm|ts)$',linked):candidates.append(linked)
    except ValueError:pass
    return list(dict.fromkeys(value.replace('\\','/').rsplit('/',1)[-1]
                             for value in candidates if isinstance(value,str) and value.strip()))


def title_number(text, marker, meta, expected):
    """Resolve a complete filename title without guessing missing titles.

    Only a complete, unique title from this season supplies episode evidence.
    Short generic names and duplicate titles are insufficient evidence.
    """
    suffix = text[marker.end():] if marker else text
    suffix = re.sub(r'(?i)\.(mkv|mp4|avi|m4v|webm|m2ts|ts)$', '', suffix)
    release = re.search(r'(?i)(?:^|[ ._-])(?:\d{3,4}p|2160|1080|720|'
                        r'web[ ._-]?dl|web[ ._-]?rip|blu[ ._-]?ray|bdrip|hdtv|remux|'
                        r'uhd|fhd|p7|fel|dv|dovi|hdr10[+]?|hdr|sdr|'
                        r'true[ ._-]?hd|atmos|ddp(?:[257])?|aac|dts|'
                        r'x26[45]|h[ ._-]?26[45]|hevc|av1)(?=$|[ ._-])', suffix)
    candidate = words(suffix[:release.start()] if release else suffix)
    if marker is None:
        # A title-only filename must also identify the series. Do not mistake
        # a generic episode title in an unrelated show for this episode.
        series = words(meta.get('name') or '')
        if not series or candidate[:len(series)] != series:
            return None
        candidate = candidate[len(series):]
    if len(candidate) < 2:
        return None
    known = []
    for video in meta.get('videos') or []:
        if not isinstance(video, dict):
            continue
        try:
            number = int(video['season']), int(video.get('episode', video.get('number')))
        except (KeyError, TypeError, ValueError, OverflowError):
            continue
        if number[0] == expected[0] and words(video.get('title') or video.get('name') or '') == candidate:
            known.append(number)
    return known[0] if len(set(known)) == 1 else None


def title_conflict(text, marker, meta, expected):
    number = title_number(text, marker, meta, expected)
    return number is not None and number != expected


def status(row, meta, identity):
    from episode_identity import conflict
    video = next((v for v in meta.get('videos') or [] if isinstance(v, dict) and v.get('id') == identity), {})
    if conflict(video or {'id':identity}, str(meta.get('id') or '')):
        return 'conflict'
    expected = target(meta, identity)
    if expected is None:
        return 'unknown'
    verified = False
    for field in ('seriesId', 'imdbId'):
        supplied = str(row.get(field) or '')
        wanted = str(meta.get('imdb_id') or meta.get('id') or '').split(':')[0]
        if supplied.startswith('tt') and wanted.startswith('tt'):
            if supplied.split(':')[0] != wanted:
                return 'conflict'
    for field,number in zip(('season','episode'),expected):
        try:
            if row.get(field) is not None and int(row[field])!=number:return 'conflict'
        except (TypeError,ValueError,OverflowError):pass
    try:verified=(int(row['season']),int(row['episode']))==expected
    except (KeyError,TypeError,ValueError,OverflowError):pass
    evidence=[(value,True) for value in filenames(row,meta)]
    evidence.extend((str(row.get(field) or ''),False) for field in ('title','description','detail'))
    for text,is_filename in evidence:
        marks = list(EPISODE.finditer(text))
        if not marks:
            if is_filename:
                number = title_number(text, None, meta, expected)
                if number is not None:
                    if number != expected:return 'conflict'
                    verified = True
            continue
        numbers = {(int(m[1] or m[3]), int(m[2] or m[4])) for m in marks}
        # Multi-episode files are left for manual selection: their internal
        # timeline cannot safely be inferred from a release name.
        if numbers != {expected} or re.search(r'(?i)e\d+[ ._-]*e\d+|e\d+-\d+', text):
            return 'conflict'
        verified = True
        if is_filename and title_conflict(text, marks[0], meta, expected):
            return 'conflict'
        if is_filename and meta.get('name'):
            prefix = text[:marks[0].start()]
            actual, wanted = words(prefix), words(meta['name'])
            if actual and wanted and actual != wanted:
                return 'conflict'
    return 'match' if verified else 'unknown'


def eligible(rows, meta, identity, require_match=False):
    if target(meta, identity) is None:
        return [] if require_match and meta.get('type') == 'series' else list(rows)
    classified = [(row, status(row, meta, identity)) for row in rows]
    matches = [row for row, result in classified if result == 'match']
    # Unlabelled streams remain available to the manual picker. Automatic
    # playback needs positive episode evidence; guessing an unknown result can
    # start the wrong episode even when its source was returned for this ID.
    if matches:return matches
    return [] if require_match else [row for row, result in classified if result == 'unknown']


def title_verified(row, meta, identity):
    """A matching episode title in a media filename is stronger than SxxExx.

    Display labels and provider episode numbers do not establish file content.
    Keep the conflict check in status authoritative for every candidate file.
    """
    expected = target(meta, identity)
    if expected is None or status(row, meta, identity) != 'match':
        return False
    for filename in filenames(row, meta):
        markers = list(EPISODE.finditer(filename))
        if title_number(filename, markers[0] if markers else None, meta, expected) == expected:
            return True
    return False


def comparable_title(meta, identity):
    """Whether episode metadata has a title precise enough to verify a file."""
    expected = target(meta, identity)
    if expected is None:
        return False
    for video in meta.get('videos') or []:
        if not isinstance(video, dict):
            continue
        try:
            number = int(video['season']), int(video.get('episode', video.get('number')))
        except (KeyError, TypeError, ValueError, OverflowError):
            continue
        if number == expected and len(words(video.get('title') or video.get('name') or '')) >= 2:
            return True
    return False
