"""Addon-owned hero stream panel; Back restores the original cards and focus."""
import threading
import time
import xbmcgui
from lib.ui_dialogs import dialog as themed_dialog
from lib import backend as api
from lib.runtime_trace import playback as trace_playback
from lib.stream_presenter import presentation, target_label, playback_meta, filter_rows, provider_choices, stream_traits, DisplayBatch

LIST, CLOSE, RETRY, PROVIDER_FILTER, CODEC_FILTER, HDR_FILTER = 7100, 7101, 7103, 7104, 7105, 7106
SORT, CLEAR_FILTERS, QUALITY_FILTER = 7107, 7108, 7109
BACK = (10, 92, 216, 247)


class InlineStreams:
    def init_streams(self):
        self._streams_lock = threading.RLock()
        self._streams_failed = set()
        self._streams_recovery_player = None
        from lib.playback_recovery import RecoveryTracker
        self._streams_recovery = RecoveryTracker()
        # Construct on the long-lived media-window thread. A player created by
        # an early-selection Timer loses its callback pump when that timer exits.
        from lib.playback_recovery import player
        self._streams_recovery_player=player(self._streams_recovery, api.STORE.directory,
            on_started=self._stream_started,on_opened=self._stream_opened,on_intro=self._intro_opened)
        self._streams_recovery_event = None
        self._streams_worker = None
        self._streams_request = None
        self._streams_updates = {}
        self._streams_search_progress = None
        self._streams_early_timer = None
        self._streams_search_started = 0
        self._streams_search_elapsed = -1
        self._streams_generation = 0
        self._streams_dead = False
        self._streams_open = False
        self._streams_rows = []
        self._streams_display = None
        self._streams_items = []
        self._streams_item_generation = None
        self._streams_display_generation = None
        self._streams_sports_sort = 4
        self._streams_visible = []
        self._streams_positions = {}
        self._streams_refresh_selection = False
        self._streams_refresh_anchor = ''
        self._streams_launching = False
        self._streams_loading_screen = None
        self._streams_search_screen = None
        self._streams_search_token = ''
        self._streams_playback_generation = None
        self._streams_loading_art = None
        self._streams_resume_grace = None
        self._streams_prefetch_identity = None
        self._streams_prefetched = set()
        self._streams_cache_context = None
        self._streams_cache_evidence = {}
        self._streams_prefetch_timer = None
        self._streams_format_status = {}
        self._streams_provider_filter = 'All'
        self._streams_codec_filter = 'All'
        self._streams_dynamic_filter = 'All'
        from addon_state import get_addon
        from lib.source_preferences import load_filters
        self._streams_provider_filter, self._streams_codec_filter, self._streams_dynamic_filter = load_filters(get_addon())
        self._streams_codec_filter = 'All'
        addon = get_addon()
        remember = addon.getSetting('source_remember_filters') == 'true'
        self._streams_audio_filter = (addon.getSetting('source_filter_audio') or 'All') if remember else 'All'
        self._streams_quality_filter = (addon.getSetting('source_filter_quality') or 'All') if remember else 'All'
        self._sync_stream_filter_labels()

    def _refresh_stream_cache_context(self):
        context=(str(api.STORE.directory),api._stream_provider_signature())
        with self._streams_lock:
            if self._streams_cache_context is None:
                self._streams_cache_context=context
            elif context!=self._streams_cache_context:
                self._streams_cache_context=context
                self._streams_generation+=1
                self._streams_prefetched.clear()
                self._streams_cache_evidence.clear()
                for key in list(self.section_cache):
                    if key.startswith('streams:'):self.section_cache.pop(key,None)
        return context

    def _cache_stream_rows(self,identity,result,complete=True,updated=None,context=None):
        with self._streams_lock:
            if self._streams_cache_context is None:self._refresh_stream_cache_context()
            if context is not None and context!=self._streams_cache_context:return
            saved=time.monotonic()
            if type(updated) in (int,float):saved-=max(0,time.time()-updated)
            self.section_cache['streams:'+identity]=result
            self._streams_cache_evidence[identity]=(result,saved,bool(complete and not result[2]))

    def prefetch_streams(self, identity):
        """Explicit title-open check; reuse fresh sources and check each target once."""
        if not identity or self._streams_dead:return
        context=self._refresh_stream_cache_context()
        if self.meta.get('type') == 'series':
            from lib.episode_availability import upcoming, release_today_without_time
            episode = next((row for row in self.meta.get('videos', [])
                            if str(row.get('id') or '') == str(identity)), None)
            if episode is not None and (upcoming(episode) or
                    (getattr(self, '_broadcast_check_pending', False)
                     and release_today_without_time(episode))):
                return
        from lib.loading_trivia import prefetch as prefetch_trivia
        prefetch_trivia(self.meta)
        self._streams_prefetch_identity = identity
        self.setProperty('format_check_status', self._streams_format_status.get(identity, ''))
        if identity in self._streams_prefetched:return
        from addon_state import get_addon
        from lib.coreelec import enabled
        import xbmc
        if self._streams_prefetch_timer:
            self._streams_prefetch_timer.cancel()
            self._streams_prefetch_timer = None
        cached_state=api.stream_cache_state(self.meta,identity)
        cached=api.cached_source_rows(self.meta,identity,cache_state=cached_state) if cached_state else None
        if cached and cached[0]:
            complete=isinstance(cached_state,(tuple,list)) and len(cached_state)>=5 and not cached_state[4]
            self._cache_stream_rows(identity,cached,complete=complete,updated=cached_state[3],context=context)
            from lib.available_formats import apply
            apply(self, cached[0])
        # Badge freshness is independent of short-lived playback URLs.
        summary = api.availability_summary(dict(self.meta, _focus_video_id=identity))
        if (isinstance(summary, dict) and summary.get('target') == identity and summary.get('formats')
                and summary.get('complete') is not False and not summary.get('stale')):
            from lib.available_formats import hero_properties, FormatFacts
            facts = FormatFacts(summary['formats'], available=summary.get('available_formats'), groups=summary.get('source_formats'))
            for key, value in hero_properties(self, self.meta, facts).items():self.setProperty(key, value)
            self._streams_prefetched.add(identity)
            self._set_format_status(identity, '')
            return
        # Fresh cache needs no provider fan-out. Stale/missing cache refreshes once
        # in the background while the user can already open the cached rows.
        if cached_state and not cached_state[4]:
            self._streams_prefetched.add(identity)
            self._set_format_status(identity, '')
            return
        from lib.format_preload import background_allowed
        if enabled(get_addon()) and not background_allowed(xbmc.Player(), self.getProperty('hero_trailer'), getattr(self, 'preview_url', None)):
            return
        from lib.format_budget import claim, cooldown, retry_after
        if not claim(api.STORE.directory, len(api.providers('streams'))):
            self._set_format_status(identity, 'Waiting to refresh')
            delay = retry_after(api.STORE.directory)
            if delay is not None:
                def retry():
                    if not self._streams_dead and self.play_target == identity and not self._streams_open:
                        self.prefetch_streams(identity)
                self._streams_prefetch_timer = threading.Timer(delay, retry)
                self._streams_prefetch_timer.daemon = True
                self._streams_prefetch_timer.start()
            return
        self._streams_prefetched.add(identity)
        self._set_format_status(identity, 'Checking formats…')
        from lib.available_formats import formats, merge_formats, hero_properties
        retained = formats(cached[0]) if cached and cached[0] else (
            summary.get('formats', []) if isinstance(summary, dict) and summary.get('target') == identity else [])
        def arriving(rows):
            if not self._streams_dead and context==self._streams_cache_context and self.play_target == identity and not self._streams_open:
                for key, value in hero_properties(self, self.meta, merge_formats(retained, formats(rows))).items():self.setProperty(key, value)
        outcome = []
        def refresh():
            try:
                result=api.source_rows(self.meta,identity,on_formats=arriving,on_status=outcome.append,
                    cancelled=lambda:self._streams_dead or self.play_target != identity or context!=self._streams_cache_context)
                if context!=self._streams_cache_context:return
                limited = 'rate_limited' in outcome
                if limited or result is None or (result[2] and not result[0]):
                    cooldown(api.STORE.directory)
                from lib.source_loading import failure_label
                reason = next((value for value in outcome if value), '')
                self._set_format_status(identity, failure_label(reason) if reason not in ('','unavailable') else
                    'Some providers unavailable' if result and result[0] and result[2] else
                    'Provider unavailable' if result is None or result[2] else
                    '' if result[0] else 'No format information')
                if not self._streams_dead and result is not None:
                    if result[0]:self._cache_stream_rows(identity,result,context=context)
                    if result[0] and self.play_target == identity and not self._streams_open:
                        found = merge_formats(retained, formats(result[0])) if result[2] else formats(result[0])
                        for key, value in hero_properties(self, self.meta, found).items():self.setProperty(key, value)
            except Exception:
                cooldown(api.STORE.directory)
                self._set_format_status(identity, 'Provider unavailable')
        try:threading.Thread(target=refresh,daemon=True).start()
        except RuntimeError:pass

    def refresh_format_status(self):
        # Database/other-client updates can populate logos without completing
        # this window's deferred source check. Reconcile the display locally.
        identity = self._streams_prefetch_identity
        if (not self._streams_dead and identity == getattr(self, 'play_target', None)
                and self._streams_format_status.get(identity) == 'Waiting to refresh'
                and any(self.getProperty('available_format_' + str(i)) for i in range(4))):
            self._set_format_status(identity, '')

    def _set_format_status(self, identity, text):
        if (text == 'Waiting to refresh' and identity == self._streams_prefetch_identity
                and any(self.getProperty('available_format_' + str(i)) for i in range(4))):
            text = ''
        self._streams_format_status[identity] = text
        if not self._streams_dead and self._streams_prefetch_identity == identity:
            self.setProperty('format_check_status', text)

    def choose_source(self, identity, resume_ms=0, allow_auto=True, continue_auto=False, random_mode=False):
        if self.meta.get('type') == 'series':
            from lib.episode_availability import upcoming, release_today_without_time
            episode = next((row for row in getattr(self, 'cards', [])
                            if str(row.get('id') or '') == str(identity)), None)
            if episode is None:
                episode = next((row for row in self.meta.get('videos', [])
                                if str(row.get('id') or '') == str(identity)), None)
            from episode_identity import conflict
            if conflict(episode or {'id':identity}, str(self.meta.get('id') or '')):
                self.report('Episode identity disagrees with its numbering. Refresh metadata before choosing a source.')
                return
            if episode is not None and (getattr(self, '_broadcast_check_pending', False)
                    and release_today_without_time(episode)):
                self.report('Checking the TV listing. Please try again shortly.')
                return
            if episode is not None and upcoming(episode):
                self.report('This episode has not aired yet.')
                return
        if (self._streams_dead or self._streams_open or
                (self._streams_loading_screen and ((self._streams_loading_screen.attempt and not continue_auto)
                    or not self._streams_loading_screen.cancel_done.is_set()))):
            return
        if not continue_auto:
            self._streams_random_mode = bool(random_mode)
        trace_playback('sources.open')
        self.cancel_trailer()
        self._streams_previous_preview = self.preview_suspended
        self.preview_suspended = True
        self._streams_origin = self.getFocusId()
        self._streams_card_position = self.getControl(self.active_list).getSelectedPosition()
        self._streams_identity, self._streams_resume = identity, resume_ms
        self._streams_allow_auto = allow_auto
        self._streams_auto_chain = False
        self._streams_loading_art = None
        self._streams_resume_grace = None
        if not continue_auto:
            self._streams_auto_attempts = 0
            self._streams_owner_window = xbmcgui.getCurrentWindowId()
        self._streams_rows, self._streams_visible = [], []
        self._streams_rendered = []
        self._sync_stream_filter_labels()
        self._streams_open = True
        self.clearProperty('menu')
        self.menu_mode = None
        heading = target_label(self.meta, identity)
        if getattr(self, 'sports_source_only', False) or self.meta.get('type') in ('sport', 'sports'):
            from lib.stream_presenter import sports_sources
            listed = sports_sources(self.meta)
            if listed:heading += '  |  Listed sources: ' + listed
        self.setProperty('streams_target', heading)
        import uuid
        from lib import playback_timing
        self._streams_search_token = 'search:' + uuid.uuid4().hex
        playback_timing.begin(self._streams_search_token)
        from addon_state import get_addon
        from lib.auto_source import configured
        if allow_auto and configured(get_addon(), self.meta)[0] == 2:
            from lib.playback_loading import LoadingSession, loading_artwork
            from lib.loading_trivia import choose as loading_fact
            self._streams_loading_art = dict(loading_fact(self.meta), **loading_artwork(
                self.meta, self.getProperty('fanart'), self._sports_sources()))
            self.setProperty('streams_auto_loading', 'true')
            generation = self._streams_generation + 1
            art=dict(self._streams_loading_art,stage='Finding your stream',
                     hint='Trying another source' if continue_auto else 'Checking your enabled add-ons')
            previous=self._streams_loading_screen if continue_auto else None
            if previous and previous.advance(self._streams_search_token,target_label(self.meta,identity),
                    art=art,on_cancel=lambda:self._cancel_stream_search(generation)):
                self._streams_search_screen=previous
                self._streams_loading_screen=None
            else:
                self._streams_search_screen = LoadingSession(lambda:self._cancel_stream_search(generation))
                self._streams_search_screen.begin(self._streams_search_token,target_label(self.meta, identity),art=art)
            self._streams_search_screen.load_trivia(dict(self.meta))
        self.setProperty('streams_open', 'true')
        self._queue_streams()

    def _finish_stream_search(self):
        screen, self._streams_search_screen = self._streams_search_screen, None
        if screen:screen.finish()
        self.clearProperty('streams_auto_loading')

    def _cancel_stream_search(self, generation):
        loading=None
        with self._streams_lock:
            if generation != self._streams_generation:
                # A click during the search/playback handover still cancels
                # that attempt, but a stale callback cannot cancel a retry.
                if (generation == self._streams_playback_generation and self._streams_loading_screen
                        and self._streams_loading_screen.attempt):
                    loading=self._streams_loading_screen
            else:
                self._streams_allow_auto = False
                self._streams_auto_chain = False
                self.close_streams()
                self.report('Playback cancelled.')
        if loading:loading.cancel(loading.attempt)

    def _queue_streams(self, refresh=False):
        if refresh:trace_playback('sources.refresh')
        with self._streams_lock:
            self._refresh_stream_cache_context()
            self._streams_refresh_selection = refresh
            self._streams_refresh_anchor = ''
            self._cancel_early_stream()
            self._streams_generation += 1
            generation, identity = self._streams_generation, self._streams_identity
            self.clearProperty('streams_ready')
            self.setProperty('streams_loading', 'true')
            self.setProperty('streams_message', 'Finding available sources…')
            self.setProperty('streams_count', '')
            from lib.source_search_timing import SearchTiming
            self._streams_timing = SearchTiming(api.STORE.directory)
            self._streams_search_started = time.monotonic()
            self._streams_search_elapsed = -1
            self._streams_search_progress = None
            self.setProperty('streams_search_status', 'Searching your enabled add-ons')
            self.setProperty('streams_search_detail', 'Sources appear as each add-on replies')
            if not self.getProperty('streams_auto_loading'):self.setFocusId(CLOSE)
            self._streams_updates.clear()
            lookup_started = time.monotonic()
            if not refresh:
                result = self.section_cache.get('streams:' + identity)
                from lib.stream_index import TTL
                evidence=self._streams_cache_evidence.get(identity)
                fresh=bool(evidence and evidence[0] is result and evidence[2]
                           and 0<=time.monotonic()-evidence[1]<=TTL)
                if not fresh:
                    cached = api.stream_cache_state(self.meta, identity)
                    if isinstance(cached, (tuple, list)) and len(cached) >= 5:
                        replacement = api.cached_source_rows(self.meta, identity, cache_state=cached)
                        if isinstance(replacement,(tuple,list)) and len(replacement)==3:
                            result=replacement
                            fresh=not cached[4] and not result[2]
                            self._cache_stream_rows(identity,result,complete=fresh,updated=cached[3])
                self._streams_timing.add('cache_lookup_ms', (time.monotonic() - lookup_started) * 1000)
                if isinstance(result, (tuple, list)) and len(result) == 3 and result[0]:
                    if fresh:
                        self.setProperty('streams_search_status', 'Saved sources · ready to choose')
                        self.clearProperty('streams_search_detail')
                        self._show_stream_result(generation, result)
                        return
                    # Show usable saved rows, but never finish best-quality
                    # selection or start early playback from an incomplete cache.
                    # Start live collection before any expensive saved-list render.
                    # The UI pump may skip this snapshot if fresh results win the race.
                    self._queue_stream_update(generation, 'cached', result)
            self._streams_request = (generation, identity)
            if self._streams_worker is not None:
                return
            try:
                self._streams_worker = threading.Thread(target=self._load_streams, daemon=True)
                self._streams_worker.start()
            except RuntimeError:
                self._streams_worker = None
                self._streams_request = None
                if 'cached' in self._streams_updates:
                    self._queue_stream_update(generation, 'result', (None, {}))
                else:
                    self._show_stream_result(generation, None)

    def _load_streams(self):
        while True:
            with self._streams_lock:
                job, self._streams_request = self._streams_request, None
                if self._streams_dead or job is None:
                    self._streams_worker = None
                    return
                timing = getattr(self, '_streams_timing', None)
            generation, identity = job
            context=self._streams_cache_context
            if timing:timing.mark('worker_start_ms')
            worker_started = time.monotonic()
            observations = {}
            try:
                result = api.source_rows(self.meta, identity,
                    on_formats=lambda rows: self._queue_stream_update(generation, "rows", rows),
                    on_progress=lambda status: self._queue_stream_update(generation, "progress", status),
                    on_observations=observations.update,
                    cancelled=lambda:self._streams_dead or not self._streams_open or generation != self._streams_generation)
                if not isinstance(result, (tuple, list)) or len(result) != 3:
                    result = None
            except Exception as error:
                from lib.diagnostic_events import record
                record('sources.search', error)
                result = None  # Never log provider URLs or raw exceptions.
            if timing:
                timing.mark('worker_done_ms')
                timing.add('worker_ms', (time.monotonic() - worker_started) * 1000)
            cache_started = time.monotonic()
            with self._streams_lock:
                if not self._streams_dead and context==self._streams_cache_context and result is not None and result[0]:
                    self._cache_stream_rows(identity,result,context=context)
                if timing:timing.add('cache_ms', (time.monotonic() - cache_started) * 1000)
                self._queue_stream_update(generation, 'result', (result, observations))

    def _queue_stream_update(self, generation, kind, value):
        # Provider callbacks only transfer data. Never enter Kodi while owning
        # the lock that Back/close needs from a native input callback.
        with self._streams_lock:
            if self._streams_dead or not self._streams_open or generation != self._streams_generation:
                return
            timing = getattr(self, '_streams_timing', None)
            if timing:timing.enqueue(kind)
            self._streams_updates[kind] = (generation, value)

    def _drain_stream_updates(self):
        with self._streams_lock:
            updates, self._streams_updates = self._streams_updates, {}
            timing = getattr(self, '_streams_timing', None)
            if timing:timing.dequeue(updates)
        # Cumulative rows/progress are coalesced; completion always goes last.
        # Native calls happen outside the transfer lock, including empty/error
        # cleanup and focus restoration.
        arrival, completion = updates.get('rows'), updates.get('result')
        cached = updates.get('cached')
        if cached and ((arrival and arrival[0] == cached[0] and arrival[1]) or
                       (completion and completion[0] == cached[0] and completion[1][0] is not None)):
            updates.pop('cached')  # Never repaint an obsolete saved list before live results.
        if arrival and completion and arrival[0] == completion[0]:
            final = completion[1][0]
            if final is not None:
                from collections import Counter
                from core.source_service import service_id
                def identities(rows):
                    return Counter((row['url'], service_id(row)) for row in rows)
                incoming, finished = arrival[1], final[0]
                # Completion may enrich cards/FEL metadata or add sources. Skip
                # the obsolete render only if every source identity survives.
                if incoming == finished or (
                        all(isinstance(row, dict) and isinstance(row.get('url'), str) and row['url']
                            for rows in (incoming, finished) for row in rows)
                        and not (identities(incoming) - identities(finished))):
                    updates.pop('rows')
        for kind in ('cached', 'rows', 'progress', 'result'):
            if kind not in updates:continue
            generation, value = updates[kind]
            if self._streams_dead or not self._streams_open or generation != self._streams_generation:
                continue
            try:
                if kind == 'cached':self._show_stream_result(generation, value, partial=True, cached=True)
                elif kind == 'rows':self._stream_arrival(generation, value)
                elif kind == 'progress':self._stream_progress(generation, value)
                else:
                    result, observations = value
                    if self._sports_sources():
                        from lib.sports_epg import update_from_sources
                        update_from_sources(self.meta, result[0] if result else [], observations)
                    self._show_stream_result(generation, result)
            except (RuntimeError, ValueError, TypeError) as error:
                from lib.diagnostic_events import record
                record('sources.render', error)
                self.clearProperty('streams_loading')
                self._finish_stream_search()
                self.setProperty('streams_message', 'Could not show sources. Select Refresh to retry.')
                self.setFocusId(RETRY)

    def _stream_arrival(self, generation, rows):
        if rows:
            self._show_stream_result(generation, (rows, 0, 0), partial=True)

    def _stream_progress(self, generation, status):
        if self._streams_dead or not self._streams_open or generation != self._streams_generation:
            return
        self._streams_search_progress = dict(status)
        if not self._streams_rows:
            from lib.source_loading import properties
            self.setProperty('streams_message', properties(status)['streams_search_detail'] or 'Finding available sources.')
        self._streams_search_elapsed = -1
        self._update_search_progress()

    def _update_search_progress(self):
        if self._streams_search_progress is None:
            return
        from lib.source_loading import properties
        elapsed = int(max(0, time.monotonic() - self._streams_search_started))
        if elapsed == self._streams_search_elapsed:
            return
        self._streams_search_elapsed = elapsed
        for key, value in properties(self._streams_search_progress, elapsed).items():
            self.setProperty(key, value)
        if self._streams_search_screen:
            self._streams_search_screen.hint(
                'Some add-ons are taking longer. You can cancel and try again.' if elapsed >= 15
                else 'Checking your enabled add-ons')

    def _show_stream_result(self, generation, result, partial=False, cached=False):
        timing = getattr(self, '_streams_timing', None)
        if generation != self._streams_generation or timing is None:
            return self._apply_stream_result(generation, result, partial, cached)
        with timing.measure('result_ms'):
            self._apply_stream_result(generation, result, partial, cached)
        if not self.getProperty('streams_loading'):
            timing.finish()

    def _apply_stream_result(self, generation, result, partial=False, cached=False):
        # A fresh cached list must not race an initial speed measurement into
        # autoplay. Render partial results now and finish via the owned pump.
        if (not partial and result and result[0] and self._streams_open
                and generation == self._streams_generation
                and getattr(self, '_streams_speed_wait_generation', None) != generation):
            from addon_state import get_addon
            from lib.network_limit import policy
            if policy(get_addon()).get('speed_status') == 'measuring':
                self._streams_speed_wait_generation = generation
                timing = getattr(self, '_streams_timing', None)
                def finish_speed():
                    speed_started = time.monotonic()
                    from lib.network_speed import wait
                    wait(get_addon(), cancelled=lambda: self._streams_dead or not self._streams_open
                         or generation != self._streams_generation)
                    if timing:timing.add('speed_wait_ms', (time.monotonic() - speed_started) * 1000)
                    self._queue_stream_update(generation, 'result', (result, {}))
                try:
                    threading.Thread(target=finish_speed, daemon=True).start()
                    partial, cached = True, True
                except RuntimeError:
                    pass  # Fall back to the configured cap; never block input.
        if self._streams_dead or not self._streams_open or generation != self._streams_generation:
            return
        had_rows = bool(self._streams_rows)
        incomplete = result is None and had_rows
        # Reset once when the active search finishes, including Refresh. Partial
        # arrivals and later redraws preserve selection; abandoned/failed searches
        # cannot move it. Keep configured automatic/highlight behavior below.
        completed = (not partial and result is not None
                     and bool(self.getProperty('streams_loading')))
        if incomplete:
            result = (self._streams_rows, 0, 1)
            self._streams_allow_auto = False
        if (not partial and result and self._sports_sources()
                and not self.meta.get('_sports_source_start')):
            from lib.sports_epg import update_from_sources
            update_from_sources(self.meta, result[0])
        if not partial:
            self._cancel_early_stream()
            self.clearProperty('streams_loading')
            if result is None or incomplete:
                self.setProperty('streams_search_status', 'Search incomplete')
            elif self.getProperty('streams_search_status').startswith('Searching'):
                self.setProperty('streams_search_status', 'Search complete')
        from lib.playback_recovery import digest
        from lib.source_failures import blocked
        failures=blocked(api.STORE.directory) or set()
        self._streams_rows = [dict(row) for row in (result[0] if result else []) if isinstance(row, dict)]
        for row in self._streams_rows:
            row['_session_failed'] = row.get('_session_failed', False) or digest(row.get('url','')) in self._streams_failed or digest(row.get('url','')) in failures
        prepared = self._prepare_stream_display()
        automatic_loading = bool(self.getProperty('streams_auto_loading'))
        if not automatic_loading:
            from lib.available_formats import apply
            apply(self, self._streams_rows, prepared=prepared)
            self.refresh_format_status()
        if self._streams_dead or not self._streams_open or generation != self._streams_generation:return
        if not self._streams_rows:
            self._finish_stream_search()
            if self._streams_dead or not self._streams_open or generation != self._streams_generation:return
            self.clearProperty('streams_ready')
            detail = self.getProperty('streams_search_detail')
            message = 'Unable to load sources. Select Refresh to try again.' if result is None else (
                'No supported sources. ' + detail if detail and result[2] else
                'No supported sources. {} unsupported · {} add-on requests failed.'.format(result[1], result[2]))
            self.setProperty('streams_message', message)
            self.setFocusId(RETRY)
            return
        automatic_loading = bool(self.getProperty('streams_auto_loading'))
        reset_selection = self._streams_refresh_selection
        if not automatic_loading:
            anchor = self._streams_refresh_anchor
            previous = getattr(self, '_streams_rendered', [])
            position = self.getControl(LIST).getSelectedPosition()
            selected_url = previous[position].get('url', '') if 0 <= position < len(previous) else ''
            # New arrivals can rank ahead of the first partial result. Keep
            # the default at the top unless the user moved off that result.
            if reset_selection and anchor and selected_url != anchor:
                reset_selection = self._streams_refresh_selection = False
            restore = not reset_selection and (not anchor or selected_url != anchor)
            self._render_streams(restore=restore and not completed, prepared=prepared)
            if reset_selection:
                self._streams_refresh_anchor = self._streams_visible[0].get('url', '') if self._streams_visible else ''
            if not partial:
                self._streams_refresh_selection = False
                self._streams_refresh_anchor = ''
        if self._streams_dead or not self._streams_open or generation != self._streams_generation:return
        if (not had_rows or reset_selection) and not automatic_loading:
            self.setFocusId(LIST if self._streams_visible else CLOSE)
        if partial:
            if not cached:self._schedule_early_stream(generation)
            return
        if incomplete:
            self.setProperty('streams_message', 'Search stopped early. Available sources are kept; Refresh to retry.')
        elif self._streams_search_progress and self._streams_search_progress.get('failed') and not self.getProperty('streams_message'):
            self.setProperty('streams_message', self.getProperty('streams_search_detail'))
        if getattr(self, '_streams_allow_auto', False):
            self._streams_allow_auto = False
            from addon_state import get_addon
            from lib.auto_source import select
            from lib.last_source import load as successful_source
            remembered = successful_source(api.STORE.directory, self.meta.get('type'), self._streams_identity) if self._streams_resume > 0 else None
            mode, selected, fallback = select(self._streams_rows, get_addon(), self.meta,
                (self._streams_provider_filter, self._streams_codec_filter, self._streams_dynamic_filter, self._streams_audio_filter, self._streams_quality_filter), remembered=remembered, identity=self._streams_identity, profile=api.STORE.directory)
            if selected is not None:
                if fallback:self.setProperty('streams_message', 'Using the closest available match to your preferences.')
                if mode == 2:
                    self._streams_auto_chain = True
                    self._play_stream_row(selected)
                    return
                elif mode == 1:
                    for index, row in enumerate(self._streams_visible):
                        if selected in (row.get('_alternatives') or [row]):
                            self.getControl(LIST).selectItem(index)
                            break
            elif mode==2:
                self._manual_source_only=True
                self.refresh_primary_action()
        if automatic_loading:
            self._finish_stream_search()
            self._render_streams(restore=not completed, prepared=prepared)
            self.setFocusId(LIST if self._streams_visible else CLOSE)

    def _cancel_early_stream(self):
        timer = self._streams_early_timer
        self._streams_early_timer = None
        if timer:
            timer.cancel()

    def _early_stream_match(self, resume_fallback=False):
        from addon_state import get_addon
        from lib.auto_source import early_select
        from lib.last_source import load as successful_source
        remembered = successful_source(api.STORE.directory, self.meta.get('type'), self._streams_identity) if self._streams_resume > 0 else None
        return early_select(self._streams_rows, get_addon(), self.meta,
            (self._streams_provider_filter, self._streams_codec_filter, self._streams_dynamic_filter,
             self._streams_audio_filter, self._streams_quality_filter), remembered=None if resume_fallback else remembered, identity=self._streams_identity, profile=api.STORE.directory)

    def _schedule_early_stream(self, generation):
        if not getattr(self, '_streams_allow_auto', False):return
        selected=self._early_stream_match()
        delay=0.0
        if selected is None:
            if not self._streams_resume or self._early_stream_match(resume_fallback=True) is None:return
            # Start the grace only when an exact alternative is available, not
            # at search launch. Further arrivals do not restart the deadline.
            if self._streams_resume_grace is None:self._streams_resume_grace=time.monotonic()+2.0
            delay=max(0.0,self._streams_resume_grace-time.monotonic())
        if self._streams_early_timer is not None:
            if delay>0:return
            self._cancel_early_stream()  # The working release arrived: start now.
        def settle():
            with self._streams_lock:
                if self._streams_early_timer is not timer:return
                self._streams_early_timer = None
                if (self._streams_dead or not self._streams_open or generation != self._streams_generation
                        or not self._streams_allow_auto):return
                selected = self._early_stream_match()
                if (selected is None and self._streams_resume_grace is not None
                        and time.monotonic()>=self._streams_resume_grace):
                    selected=self._early_stream_match(resume_fallback=True)
                if selected is not None:
                    self._streams_allow_auto = False
                    self._streams_auto_chain = True
                    self._play_stream_row(selected)
        # Dispatch playback off the provider callback, without an artificial delay.
        timer = threading.Timer(delay, settle)
        timer.daemon = True
        self._streams_early_timer = timer
        try:timer.start()
        except RuntimeError:self._streams_early_timer = None

    def _sports_sources(self):
        if getattr(self, 'sports_source_only', False) is True:
            return True
        # InfoWindow initialises sources before onInit loads self.meta.
        meta = getattr(self, 'meta', None)
        if not isinstance(meta, dict):
            meta = getattr(self, 'preview', None)
        return isinstance(meta, dict) and meta.get('type') in ('sport', 'sports')

    def _source_sort_index(self, addon):
        if self._sports_sources():
            return self._streams_sports_sort
        try:
            index = int(addon.getSetting('source_sort') or '0')
            return index if 0 <= index <= 4 else 0
        except (ValueError, TypeError):
            return 0

    def _prepare_stream_display(self):
        previous = getattr(self, '_streams_display', None) if (
            getattr(self, '_streams_display_generation', None) == self._streams_generation) else None
        prepared = DisplayBatch(self._streams_rows, previous)
        self._streams_display = prepared
        self._streams_display_generation = self._streams_generation
        return prepared

    def _render_streams(self, restore=False, prepared=None):
        timing = getattr(self, '_streams_timing', None)
        if timing is None:return self._render_stream_rows(restore, prepared)
        timing.add('render_calls', 1)
        with timing.measure('render_ms'):
            return self._render_stream_rows(restore, prepared)

    def _render_stream_rows(self, restore=False, prepared=None):
        timing = getattr(self, '_streams_timing', None)
        rank_started = time.monotonic()
        prepared = prepared if prepared is not None else self._prepare_stream_display()
        from addon_state import get_addon
        from lib.source_preferences import preferences, rank_rows, limit_sources
        prefs = preferences(get_addon())
        if self._sports_sources():
            prefs['sort'] = ('recommended', 'provider', 'smallest', 'largest', 'highest_bitrate')[self._source_sort_index(get_addon())]
        ranked = rank_rows(limit_sources(self._streams_rows, prefs,prepared=prepared), prefs,prepared=prepared)
        self._streams_visible = filter_rows(ranked, self._streams_provider_filter, self._streams_codec_filter, self._streams_dynamic_filter, self._streams_audio_filter, self._streams_quality_filter,prepared=prepared)
        from lib.source_groups import group_rows
        total = len(self._streams_visible)
        if get_addon().getSetting('source_group_duplicates') != 'false':
            self._streams_visible = group_rows(self._streams_visible,prepared=prepared)
        if timing:timing.add('rank_ms', (time.monotonic() - rank_started) * 1000)
        items_started = time.monotonic()
        control = self.getControl(LIST)
        selected_url = getattr(self, '_streams_selected_url', '')
        old_position = control.getSelectedPosition()
        previous = getattr(self, '_streams_rendered', [])
        if restore and 0 <= old_position < len(previous):
            selected_url = previous[old_position].get('url', '')
        # Kodi items contain presentation only; playback always uses the fresh
        # _streams_visible rows below. Keep separate entries for identical labels.
        reusable = getattr(self, '_streams_item_generation', None) == self._streams_generation
        old_items = getattr(self, '_streams_items', []) if reusable else []
        from collections import defaultdict, deque
        pool = defaultdict(deque)
        for signature, entry in old_items:
            pool[signature].append(entry)
        from lib.stream_presenter import choice_labels, line
        live_labels = choice_labels(self._streams_visible,prepared=prepared) if (
            getattr(self, 'sports_source_only', False) or self.meta.get('type') in ('sport', 'sports')) else None
        items = []
        created = reused = 0
        from lib.source_items import ItemBuilder
        builder = ItemBuilder(timing)
        for row_index, row in enumerate(self._streams_visible):
            view = prepared.view(row)
            alternatives = row.get('_alternatives') or [row]
            suffix = ' | {} options'.format(len(alternatives)) if len(alternatives)>1 else ''
            title = live_labels[row_index] if live_labels else (
                ('Failed to play | ' if row.get('_session_failed') else '') + view['title'])
            from core.channel_art import channel_logo
            properties = (
                ('stream_channel_logo', channel_logo(row) if live_labels else ''),
                ('stream_service', view['service_badge']),
                ('stream_detail', view['detail']),
                ('stream_audio', view['audio']),
                ('stream_release', line(prepared.card(row).get('filename'), 180)),
            )
            signature = (title + suffix, properties)
            if pool[signature]:
                entry = pool[signature].popleft()
                reused += 1
            else:
                # Prepare before publication; never mutate retained items.
                entry = builder.create(xbmcgui.ListItem, title + suffix, properties)
                created += 1
            items.append((signature, entry))
        builder.flush()
        if timing:
            timing.add('items_created', created)
            timing.add('items_reused', reused)
            timing.add('item_prepare_ms', (time.monotonic() - items_started) * 1000)
        native_started = time.monotonic()
        old_signatures = [signature for signature, _ in old_items]
        signatures = [signature for signature, _ in items]
        if not reusable or signatures != old_signatures:
            # Append without clearing when the existing prefix is unchanged;
            # reordered/removed/changed rows still need a full native replacement.
            append = reusable and signatures[:len(old_signatures)] == old_signatures
            self._streams_item_generation = None  # A failed native update cannot be reused.
            if timing:timing.add('list_appends' if append else 'list_resets', 1)
            if not append:control.reset()
            entries = [entry for _, entry in (items[len(old_items):] if append else items)]
            if entries:
                add_items = getattr(control, 'addItems', None)
                if callable(add_items):add_items(entries)
                else:
                    for entry in entries:control.addItem(entry)
        elif timing:
            timing.add('list_unchanged', 1)
        self._streams_items = items  # Evict removed/changed entries; no cross-search retention.
        self._streams_item_generation = self._streams_generation
        key = self._streams_identity
        pos = self._streams_positions.get(key, 0) if restore else 0
        if restore and selected_url:
            pos = next((i for i, row in enumerate(self._streams_visible)
                        if any(source.get('url') == selected_url for source in (row.get('_alternatives') or [row]))), pos)
        selected_position = max(0, min(pos, len(self._streams_visible) - 1))
        if not reusable or signatures != old_signatures or selected_position != old_position:
            control.selectItem(selected_position)
        if timing:
            timing.add('native_update_ms', (time.monotonic() - native_started) * 1000)
            timing.add('items_ms', (time.monotonic() - items_started) * 1000)
        self._streams_rendered = list(self._streams_visible)
        self.setProperty('streams_count', '{} releases / {} sources'.format(len(self._streams_visible), total))
        self.setProperty('streams_ready', 'true' if self._streams_visible else '')
        fel_filter = self._streams_dynamic_filter in ('FEL reported','P7 FEL reported')
        p7_unknown = fel_filter and not self._streams_visible and any(
            'Profile 7 reported' in prepared.traits(r)['dynamic'] and
            'P7 FEL reported' not in prepared.traits(r)['dynamic'] for r in ranked)
        fel_empty=fel_filter and p7_unknown
        self.setProperty('streams_message', ('Profile 7 sources are available, but their FEL layer is unreported. Choose Video: Profile 7 to include them.' if fel_empty else 'No sources explicitly report FEL. A Dolby Vision or REMUX label alone does not confirm the enhancement layer.') if not self._streams_visible and self._streams_dynamic_filter in ('FEL reported','P7 FEL reported') else '' if self._streams_visible else 'No sources match your filters or device limits. Clear filters or adjust Maximum stream quality and Bitrate limit in Sources settings.')

    def _sync_stream_filter_labels(self):
        from addon_state import get_addon
        orders=('Recommended','Provider order','Smallest first','Largest first','Highest bitrate first')
        index = self._source_sort_index(get_addon())
        self.setProperty('streams_sort', 'Sort: '+orders[index if 0<=index<len(orders) else 0])
        self.setProperty('streams_provider_filter', 'Source: '+self._streams_provider_filter)
        audio_labels={'Dolby Digital Plus':'DD+','Dolby Digital':'DD','DTS-HD MA':'DTS-HD'}
        self.setProperty('streams_codec_filter', 'Audio: '+audio_labels.get(self._streams_audio_filter,self._streams_audio_filter))
        self.setProperty('streams_quality_filter', 'Quality: '+('Unknown' if self._streams_quality_filter=='AUTO' else self._streams_quality_filter))
        video_labels={'P7 FEL reported':'P7 FEL','FEL reported':'FEL','Profile 7 reported':'Profile 7'}
        self.setProperty('streams_hdr_filter', 'Video: '+video_labels.get(self._streams_dynamic_filter,self._streams_dynamic_filter))

    def _pick_stream_filter(self, kind):
        if kind=='provider':
            values=provider_choices(self._streams_rows); current=self._streams_provider_filter; heading='Source / provider'
        elif kind=='codec':
            values=['All','Atmos','TrueHD','Dolby Digital Plus','Dolby Digital','DTS-HD MA','DTS-X','AAC','FLAC','Stereo','Mono']; current=self._streams_audio_filter; heading='Audio'
        elif kind=='quality':
            from lib.stream_presenter import quality_choices
            values=quality_choices(self._streams_rows); current=self._streams_quality_filter; heading='Quality'
        else:
            values=['All','Dolby Vision','HDR10','HDR','P7 FEL reported','Profile 7 reported','FEL reported']; current=self._streams_dynamic_filter; heading='Video format - FEL requires an explicit layer report'
        selected=themed_dialog().select(heading,values,preselect=(values.index(current) if current in values else 0))
        if selected<0:return
        if kind=='provider': self._streams_provider_filter=values[selected]
        elif kind=='codec': self._streams_audio_filter=values[selected]
        elif kind=='quality': self._streams_quality_filter=values[selected]
        else: self._streams_dynamic_filter=values[selected]
        from addon_state import get_addon
        from lib.source_preferences import save_filters
        save_filters(get_addon(), self._streams_provider_filter, self._streams_codec_filter, self._streams_dynamic_filter)
        if get_addon().getSetting('source_remember_filters')=='true':
            get_addon().setSetting('source_filter_audio', self._streams_audio_filter)
            get_addon().setSetting('source_filter_quality', self._streams_quality_filter)
        self._sync_stream_filter_labels(); self._render_streams()

    def set_stream_filters(self, provider='All', codec='All', dynamic='All'):
        self._streams_provider_filter = provider or 'All'
        self._streams_codec_filter = codec or 'All'
        self._streams_dynamic_filter = dynamic or 'All'
        self._streams_audio_filter = 'All'
        self._streams_quality_filter = 'All'
        if self._streams_open:
            self._render_streams()

    def _remember_stream_position(self):
        if self._streams_visible:
            self._streams_positions[self._streams_identity] = self.getControl(LIST).getSelectedPosition()

    def close_streams(self):
        self._streams_display = None
        self._streams_items = []
        self._streams_item_generation = None
        self._streams_display_generation = None
        with self._streams_lock:
            if not self._streams_open:
                return
            self._remember_stream_position()
            self._cancel_early_stream()
            self._streams_generation += 1
            self._streams_request = None
            self._streams_updates.clear()
            self._streams_open = False
            self._finish_stream_search()
            self.clearProperty('streams_open')
            self.clearProperty('streams_loading')
            self._streams_search_progress = None
            self.preview_suspended = self._streams_previous_preview
            listing = self.getControl(self.active_list)
            if listing.getSelectedPosition() != self._streams_card_position:
                listing.selectItem(max(0, self._streams_card_position))
            # Queue focus after Kodi evaluates the restored cards' visibility.
            import xbmc
            if self._streams_loading_screen and self._streams_loading_screen.window:
                self.setFocusId(self._streams_origin)
            else:xbmc.executebuiltin('SetFocus({})'.format(self._streams_origin))

    def streams_focus(self, cid):
        if self.getProperty('streams_auto_loading'):return
        if self._streams_open and cid not in (LIST, CLOSE, RETRY, PROVIDER_FILTER, CODEC_FILTER, HDR_FILTER, SORT, CLEAR_FILTERS, QUALITY_FILTER):
            self.setFocusId(LIST if self.getProperty('streams_ready') else CLOSE)

    def streams_action(self, action):
        loading=self._streams_search_screen or self._streams_loading_screen
        if loading and loading.attempt:
            if action.getId() in BACK:loading.cancel(loading.attempt)
            return True
        if not self._streams_open:
            return False
        if action.getId() in BACK:
            self.close_streams()
            if getattr(self, 'sports_source_only', False) is True:
                self.close()
        elif action.getId() in (2, 11, 117) and self.getFocusId() == LIST:
            self._show_stream_details()
        return True  # Do not dispatch panel actions to the hidden episode UI.

    def _show_stream_details(self):
        if not self.getProperty('streams_ready'):return
        index = self.getControl(LIST).getSelectedPosition()
        if not 0 <= index < len(self._streams_visible):return
        from lib.stream_presenter import details
        row = self._streams_visible[index]
        alternatives = row.get('_alternatives') or [row]
        sections = [details(source) for source in alternatives]
        themed_dialog().textviewer('Stream details', '\n\n'.join(sections))
        self.setFocusId(LIST)

    def streams_click(self, cid):
        if self._streams_loading_screen and self._streams_loading_screen.attempt:return True
        if self.getProperty('streams_auto_loading'):return True
        if not self._streams_open:
            return False
        if cid == CLOSE:
            self.close_streams()
            if getattr(self, 'sports_source_only', False) is True:
                self.close()
        elif cid == RETRY and not self.getProperty('streams_loading'):
            self._queue_streams(refresh=True)
        elif cid == PROVIDER_FILTER:
            self._pick_stream_filter('provider')
        elif cid == CODEC_FILTER:
            self._pick_stream_filter('codec')
        elif cid == QUALITY_FILTER:
            self._pick_stream_filter('quality')
        elif cid == HDR_FILTER:
            self._pick_stream_filter('hdr')
        elif cid == SORT:
            from addon_state import get_addon
            addon=get_addon();values=['Recommended','Provider order','Smallest first','Largest first','Highest bitrate first']
            current = self._source_sort_index(addon)
            selected=themed_dialog().select('Source order',values,preselect=max(0,min(len(values)-1,current)))
            if selected>=0:
                if self._sports_sources():
                    self._streams_sports_sort = selected
                else:
                    addon.setSetting('source_sort', str(selected))
                self._sync_stream_filter_labels();self._render_streams()
        elif cid == CLEAR_FILTERS:
            from addon_state import get_addon
            from lib.source_preferences import save_filters
            self.set_stream_filters();save_filters(get_addon(),'All','All','All');self._sync_stream_filter_labels()
            if get_addon().getSetting('source_remember_filters')=='true':
                get_addon().setSetting('source_filter_audio','All')
                get_addon().setSetting('source_filter_quality','All')
        elif cid == LIST:
            self._play_selected_stream()
        return True

    def _play_selected_stream(self):
        if self._streams_launching or not self.getProperty('streams_ready'):
            return
        index = self.getControl(LIST).getSelectedPosition()
        if not 0 <= index < len(self._streams_visible):
            return
        row=self._streams_visible[index]
        alternatives=row.get('_alternatives') or [row]
        row=alternatives[0]
        if len(alternatives)>1:
            from lib.stream_presenter import choice_labels
            labels=choice_labels(alternatives)
            selected=themed_dialog().select('Choose source for this release',labels,preselect=next((i for i,r in enumerate(alternatives) if not r.get('_session_failed')),0))
            if selected<0:return
            row=alternatives[selected]
        self._streams_auto_chain = False
        self._play_stream_row(row)

    def _stream_opened(self,token):
        # Opened is not AV-ready, including manually selected large files.
        # Keep the card until AVStarted or verified progressing video.
        pass

    def _intro_opened(self,token):
        if token and self._streams_loading_screen:
            self._streams_loading_screen.cover(token)

    def _stream_started(self,token):
        if not token:return
        if self._streams_loading_screen:
            self._streams_loading_screen.finish_started(token)
        from lib.playback_timing import mark
        mark(token,'playing')
        from lib.player_back import PROPERTY,STOPPING_PROPERTY
        session=xbmcgui.Window(10000)
        session.clearProperty(PROPERTY);session.clearProperty(STOPPING_PROPERTY)

    def _play_stream_row(self, row):
        if self._streams_launching or self._streams_dead or not self._streams_open:return
        from lib.source_failures import blocked
        from lib.playback_recovery import digest
        failures=blocked(api.STORE.directory)
        if failures is None:
            self.report('Playback could not start because the failed-source list is unavailable.')
            return
        if digest(row.get('url','')) in failures:
            self.report('That link previously failed and is blacklisted. Choose another source, or reset the failed-source blacklist in Troubleshooting to retry it.')
            return
        from lib.playback_loading import cancelled
        if self._streams_search_token and cancelled(self._streams_search_token):return
        from addon_state import get_addon
        from lib.source_preferences import preferences, limit_bitrate
        if not limit_bitrate([row], preferences(get_addon())):
            self._render_streams(restore=True)
            self.setProperty('streams_message', 'This source exceeds the current bitrate limit or has an unknown bitrate. Adjust Bitrate limit in Sources settings.')
            return
        self._streams_launching = True
        from lib.diagnostic_export import record_source
        record_source(api.STORE.directory, self._streams_identity, row)
        try:
            from lib.playback_recovery import player
            if self._streams_recovery_player is None:
                self._streams_recovery_player=player(self._streams_recovery, api.STORE.directory,
                    on_started=self._stream_started,on_opened=self._stream_opened,on_intro=self._intro_opened)
            live_sports = bool(getattr(self, 'sports_source_only', False) or self.meta.get('type') in ('sport', 'sports'))
            self._streams_recovery.profile=api.STORE.directory
            attempt = self._streams_recovery.arm(row.get('url',''),self._streams_identity,self._streams_resume,getattr(self,'_streams_owner_window',xbmcgui.getCurrentWindowId()),automatic=getattr(self,'_streams_auto_chain',False),provider=stream_traits(row)['provider'],live_sports=live_sports)
            self._streams_probe_url=row.get('url','')
            from source_probe import delayed_redirect_check
            self._streams_probe_recheck=delayed_redirect_check(self._streams_probe_url)
            self._streams_probe_live=bool(row.get('isLive') or self.meta.get('type')=='tv' or '.m3u8' in row.get('url','').partition('?')[0].lower())
            from lib.playback_timing import transfer
            transfer(self._streams_search_token,attempt)
            self._streams_playback_generation = self._streams_generation
            from lib.playback_loading import LoadingSession,video_running,loading_artwork
            def video_ready():
                import xbmc
                native=self._streams_recovery_player
                pending=self._streams_recovery.snapshot()
                return bool(pending and pending.get('attempt')==attempt and video_running(native,pending,
                    fullscreen=xbmc.getCondVisibility('Window.IsVisible(fullscreenvideo)')))
            from lib.loading_trivia import choose as loading_fact
            art=self._streams_loading_art or dict(loading_fact(self.meta), **loading_artwork(
                self.meta, self.getProperty('fanart'), self._sports_sources()))
            search=self._streams_search_screen
            if search and search.advance(attempt,target_label(self.meta,self._streams_identity),
                    presentation(row)['title'],art=art,on_cancel=lambda:self._cancel_video_loading(attempt),
                    state=self._stream_loading_state,ready=video_ready):
                self._streams_loading_screen=search
                self._streams_search_screen=None
            elif search:
                # Cancel may win after selection checked its search token.
                # Never replace a cancelled card with a fresh playback attempt.
                self._streams_recovery.clear()
                if not cancelled(self._streams_search_token):
                    self._finish_stream_search()
                    self._streams_allow_auto=False
                    self._streams_auto_chain=False
                    self._render_streams(restore=True)
                    self.setProperty('streams_message','Could not open the loading screen. Choose a source or retry.')
                    self.setFocusId(LIST if self._streams_visible else CLOSE)
                return
            if self._streams_loading_screen is not search or self._streams_loading_screen is None:
                if self._streams_loading_screen:self._streams_loading_screen.finish()
                self._streams_loading_screen=LoadingSession(lambda:self._cancel_video_loading(attempt),
                    state=self._stream_loading_state,ready=video_ready)
            if self._streams_loading_screen is not search:
                self._streams_loading_screen.begin(attempt,target_label(self.meta,self._streams_identity),
                    presentation(row)['title'],art=art)
                self._streams_loading_screen.load_trivia(dict(self.meta))
            self._finish_stream_search()
            if getattr(self, '_streams_auto_chain', False):self._streams_auto_attempts += 1
            episode = next((card for card in getattr(self, 'cards', [])
                            if card.get('id') == self._streams_identity), None)
            meta = playback_meta(self.meta, self._streams_identity, episode)
            from lib.playback_timing import mark
            mark(attempt,'handoff_ready')
            identity,resume=self._streams_identity,self._streams_resume
            automatic=getattr(self,'_streams_auto_chain',False)
            random_mode=getattr(self,'_streams_random_mode',False)
            loading=self._streams_loading_screen
            def dispatch():
                try:
                    if not loading.wait_visible(attempt):
                        pending=self._streams_recovery.snapshot()
                        if pending and pending['attempt']==attempt and not cancelled(attempt):
                            self._streams_recovery.failed()
                        return
                    # Check redirects under the existing card, before an error
                    # slate can enter fullscreen. Never probe a live session.
                    if automatic:
                        from source_probe import unavailable, unsupported_disc
                        live=bool(row.get('isLive') or meta.get('type')=='tv' or '.m3u8' in row.get('url',''))
                        failure=unsupported_disc(row.get('url',''),row) or unavailable(row.get('url',''),live=live)
                        pending=self._streams_recovery.snapshot()
                        if not pending or pending['attempt']!=attempt or cancelled(attempt):return
                        if failure:
                            self._streams_recovery.failed(failure)
                            return
                    pending=self._streams_recovery.snapshot()
                    if pending and pending['attempt']==attempt and not cancelled(attempt):
                        details = []
                        if automatic:
                            try:
                                from addon_state import get_addon
                                from lib.auto_source import selection_details
                                details = selection_details(row,get_addon(),meta,identity)
                            except Exception:pass
                        api.play(meta, identity, dict(row, _playback_attempt=attempt,
                            _live_sports=live_sports, _random_episode=random_mode,
                            _automatic_selection=automatic, _selection_details=details), resume)
                except Exception as error:
                    from lib.diagnostic_events import record
                    record('sources.play', error)
                    pending=self._streams_recovery.snapshot()
                    if pending and pending['attempt']==attempt:self._streams_recovery.failed()
            # Manual startup also includes payload writes/pre-roll selection.
            # Return from the input callback so the loading card can initialise
            # before PlayMedia introduces Kodi's native resolver busy dialog.
            threading.Thread(target=dispatch,daemon=True).start()
            # Sports open the picker directly from the catalogue. Keep that
            # same event and selection underneath fullscreen playback so a
            # native Stop/Back returns to its sources, not an empty hero.
            if not getattr(self, 'sports_source_only', False):
                self.close_streams()
        except Exception as error:
            from lib.diagnostic_events import record
            record('sources.play', error)
            self._finish_stream_search()
            if self._streams_loading_screen:self._streams_loading_screen.finish()
            from lib.playback_recovery import digest
            if getattr(self, '_streams_auto_chain', False):self._streams_recovery.failed()
            else:self._streams_recovery.clear()
            row['_session_failed'] = True
            self._streams_failed.add(digest(row.get('url','')))
            for source in self._streams_rows:
                if digest(source.get('url','')) in self._streams_failed:source['_session_failed']=True
            self._render_streams()
            self.setProperty('streams_message', 'Playback could not start. Select another source or Refresh.')
            self.setFocusId(LIST if self._streams_visible else CLOSE)
        finally:
            self._streams_launching = False

    def _cancel_video_loading(self, attempt):
        import xbmc
        from lib.playback_recovery import digest, playing_attempt
        with self._streams_lock:
            pending = self._streams_recovery.snapshot()
            if not pending or pending['attempt'] != attempt:
                return
            self._streams_allow_auto=False
            self._streams_auto_chain=False
            self._streams_recovery.clear()
            self._streams_recovery_event=None
            self.close_streams()
        player = xbmc.Player()
        try:
            if (not player.isPlayingVideo() or playing_attempt(player) == attempt
                    or digest(player.getPlayingFile()) == pending['hash']):
                player.stop()
        except (AttributeError, RuntimeError):
            pass
        self.report('Playback cancelled.')

    def _stream_loading_state(self):
        state=self._streams_recovery.loading_state()
        return state or (dict(self._streams_recovery_event,failed=True) if self._streams_recovery_event else None)

    def _return_reported_episode(self):
        """Consume only this episode's report request after Kodi finishes Stop."""
        import json
        import time
        from lib.last_source import key
        session = xbmcgui.Window(10000)
        raw = session.getProperty('strem4kodi.wrong_episode.return')
        if not raw or self._streams_dead:
            return False
        try:
            request = json.loads(raw)
            if not 0 <= time.time() - request['created'] <= 30:
                session.clearProperty('strem4kodi.wrong_episode.return')
                return False
            if request['target'] != key(self.meta.get('type'), self._streams_identity):
                return False
        except (ValueError, TypeError, KeyError):
            session.clearProperty('strem4kodi.wrong_episode.return')
            return False
        if xbmc.Player().isPlayingVideo():
            return True
        session.clearProperty('strem4kodi.wrong_episode.return')
        self._streams_auto_chain = False
        self._streams_recovery.clear()
        self._streams_recovery_event = None
        if self._streams_loading_screen:
            self._streams_loading_screen.finish()
        xbmc.executebuiltin('ActivateWindow({})'.format(self._streams_owner_window))
        if self._streams_open:
            self._render_streams(restore=True)
        else:
            self.choose_source(self._streams_identity, allow_auto=False)
        self.setProperty('streams_message', 'Wrong-episode report saved. Choose another source.')
        return True

    def recover_stream_tick(self):
        self._drain_stream_updates()
        if self._return_reported_episode():
            return
        # Cancel revokes the card immediately; its parent-window cleanup can
        # still be waiting for this tick's native/window locks. Do not launch
        # a retry while that cleanup is pending.
        if any(screen and not screen.cancel_done.is_set() for screen in
               (self._streams_search_screen,self._streams_loading_screen)):return
        if self._streams_open and self.getProperty('streams_loading'):
            self._update_search_progress()
        if self._streams_dead or self._streams_recovery_player is None:return
        import xbmc
        player=self._streams_recovery_player
        self._streams_recovery.poll_failure(api.STORE.directory)
        pending=self._streams_recovery.snapshot()
        caching=False
        cache_level=None
        queue_levels=None
        observed_attempt=''
        if pending:
            try:
                if player.isPlayingVideo():
                    from lib.playback_recovery import playing_attempt, digest
                    from lib.playback_recovery import startup_video_state
                    current=player.getPlayingFile()
                    attempt=playing_attempt(player)
                    startup_state=startup_video_state(player,pending)
                    slate=startup_state=='failed'
                    # Some Kodi builds drop ListItem properties when an HTTP
                    # resolver redirects to its error MP4. The exact slate
                    # URL is strong failure evidence and belongs to the sole
                    # outstanding app-owned attempt; requiring the original
                    # URL hash here strands autoplay on the provider's error
                    # screen after that redirect.
                    owned=(attempt==pending['attempt'] or
                           (not attempt and (digest(current)==pending['hash'] or slate)))
                    observation=(pending['attempt'], pending['started'], owned, slate, digest(current)!=pending['hash'])
                    if observation != getattr(self, '_streams_playback_observation', None):
                        self._streams_playback_observation=observation
                        from lib.runtime_trace import playback
                        playback('poll', *observation[1:])
                    if owned and slate:
                        self._streams_recovery.failed('provider-error-video')
                    elif startup_state=='ready' and not pending['started'] and player.getTime()>0.5:
                        token=self._streams_recovery.started(current,attempt)
                        if token:
                            from lib.prerolls import phase, clear_phase
                            handoff = phase()
                            if handoff.startswith('handoff:'):clear_phase(handoff)
                            self._stream_started(token)
                    if owned and pending['started'] and startup_state=='ready':
                        # A fixed playback clock alone is not a stall. Require
                        # Kodi's caching signal and an explicitly unpaused,
                        # owned item; failed queries reset the observation.
                        try:duration=player.getTotalTime()
                        except (AttributeError,RuntimeError):duration=None
                        self._streams_recovery.position(current,player.getTime(),attempt,duration=duration)
                        caching=(not getattr(self,'_streams_probe_live',True) and
                                 xbmc.getCondVisibility('Player.Caching') is True and
                                 xbmc.getCondVisibility('Player.Paused') is False)
                        observed_attempt=pending['attempt']
                        if caching:
                            # Query only the owned buffering item. If this
                            # optional label is unavailable, retain the normal
                            # stalled-buffer deadline rather than hiding it.
                            try:cache_level=xbmc.getInfoLabel('Player.CacheLevel')
                            except (AttributeError,RuntimeError):pass
                            from lib.playback_buffer import queues
                            queue_levels=queues(xbmc)
            except Exception:pass
        if observed_attempt:
            from lib.seek_diagnostics import observe
            observe(self._streams_recovery,api.STORE.directory,observed_attempt,
                    xbmc,player,caching,cache_level,queue_levels)
        else:
            self._streams_recovery._finish_trace('unobserved')
        self._streams_recovery.caching(caching,cache_level,
                                       pending['attempt'] if pending else '',queue_levels)
        self._streams_recovery.startup_timeout()
        with self._streams_recovery.lock:
            active=self._streams_recovery.pending
            recheck=bool(active and active.get('started') and not active.get('redirect_rechecked')
                         and getattr(self, '_streams_auto_chain', False)
                         and getattr(self, '_streams_probe_recheck', False)
                         and not getattr(self, '_streams_probe_live', True)
                         and self._streams_recovery.clock()-active.get('started_at', self._streams_recovery.clock())>=2)
            if recheck:
                active['redirect_rechecked']=True
                recheck_attempt=active['attempt']
        if recheck:
            from lib.playback_recovery import check_source
            check_source(self._streams_recovery,self._streams_probe_url,recheck_attempt,
                         profile=api.STORE.directory,redirect_only=True)
        with self._streams_recovery.lock:
            pending=dict(self._streams_recovery.pending) if self._streams_recovery.pending else None
        if self._streams_loading_screen:self._streams_loading_screen.observe(self._stream_loading_state())
        event=self._streams_recovery_event or self._streams_recovery.take()
        if event:
            if event.get('reason')=='caching-stall':
                from lib.playback_recovery import deliberate_stop
                if deliberate_stop(player):
                    self._streams_recovery_event=None
                    self._streams_recovery.clear()
                    self._streams_auto_chain=False
                    if self._streams_loading_screen:self._streams_loading_screen.finish()
                    return
            from lib.playback_recovery import stop_failed
            self._streams_recovery_event=event
            state=stop_failed(player,event)
            if state=='waiting':return
            if state in ('blocked','unrelated'):
                trace_playback('retry',reason=event.get('reason','unknown'),outcome=state)
                self._streams_recovery_event=None
                self._streams_recovery.clear()
                self._streams_auto_chain=False
                if self._streams_loading_screen:self._streams_loading_screen.finish()
                if state=='blocked':self.report('Kodi is still busy with the failed stream. Automatic retries have stopped.')
                return
        if not event:return
        from lib.playback_loading import signal_cancel
        signal_cancel(event.get('attempt'))
        self._streams_recovery_event=event
        current=xbmcgui.getCurrentWindowId()
        if current not in (event['window'],12005,12006):return
        self._streams_failed.add(event['hash'])
        if current!=event['window']:xbmc.executebuiltin('ActivateWindow({})'.format(event['window']))
        self._streams_recovery.clear()
        from addon_state import get_addon
        try:limit=(3,5,10,25)[int(get_addon().getSetting('auto_source_attempts') or '1')]
        except (ValueError,IndexError):limit=5
        was_auto=getattr(self,'_streams_auto_chain',False)
        attempts=getattr(self,'_streams_auto_attempts',0)
        retry_auto=was_auto and attempts<limit
        from lib.runtime_trace import playback
        playback('retry', attempt_number=attempts, attempt_limit=limit,
                 reason=event.get('reason','unknown'),
                 outcome='same-episode-retry' if retry_auto else 'retry-limit' if was_auto else 'manual-fallback')
        if not retry_auto and self._streams_loading_screen:self._streams_loading_screen.finish()
        if self._streams_open:
            if self._streams_identity!=event['identity']:return
            from lib.playback_recovery import digest
            for row in self._streams_rows:
                if digest(row.get('url','')) in self._streams_failed:row['_session_failed']=True
            self._streams_resume=event['resume'];self._render_streams(restore=True)
            if retry_auto:
                self.close_streams()
                self.choose_source(event['identity'],resume_ms=event['resume'],allow_auto=True,continue_auto=True)
        else:self.choose_source(event['identity'],resume_ms=event['resume'],allow_auto=retry_auto,continue_auto=True)
        self._streams_recovery_event=None
        if retry_auto and not self._streams_open:return
        if was_auto and not retry_auto:
            self._manual_source_only=True
            self.refresh_primary_action()
        from lib.diagnostic_export import report_reference
        self.setProperty('streams_message','That source failed. Choose another source or Refresh. '+report_reference(api.STORE.directory))

    def stop_streams(self):
        with self._streams_lock:
            self._streams_dead = True
            self._cancel_early_stream()
            self._finish_stream_search()
            if self._streams_loading_screen:self._streams_loading_screen.finish()
            self._streams_recovery.clear()
            if self._streams_prefetch_timer:
                self._streams_prefetch_timer.cancel()
                self._streams_prefetch_timer = None
            self._streams_open = False
            self._streams_generation += 1
            self._streams_request = None
