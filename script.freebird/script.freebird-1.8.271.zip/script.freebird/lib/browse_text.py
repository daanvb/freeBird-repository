"""Fit owned hero text and filter pills without measuring fonts on Kodi's UI thread."""
import math
from lib.title_text import plain
from lib.text_metrics import width


def heading_geometry(value):
    text=plain(value)
    if not text:return 0,332,156
    lines=1;used=0
    for word in text.split():
        length=width(word,25)*1.08
        gap=width(' ',25) if used else 0
        if used and used+gap+length>740:lines+=1;used=0;gap=0
        # Include long words, even without a space to break at.
        rows=max(1,math.ceil(length/740))
        lines+=rows-1;used=(length-(rows-1)*740)+gap+(used if rows==1 else 0)
    height=min(112,lines*32)
    top=332+height+12
    return height,top,488-top


def hero(window,heading):
    page = window.getProperty('page')
    if getattr(window, '_detail_hero', False) is not True and page in ('Home', ''):
        # Both hero views reserve the final band for runtime and format marks.
        old_height, _, _ = heading_geometry(heading)
        height = min(112, old_height)
        top = 282 + height + (12 if height else 0)
        plot_height = max(1, 476 - top)
    else:
        height, _, _ = heading_geometry(heading)
        top = 282 + height + (8 if height else 0)
        plot_height = max(1, 410 - top)
    geometry=(height,top,plot_height)
    try:
        heading_control=window.getControl(9280)
        heading_control.setHeight(max(1,height))
        plot=window.getControl(9281)
        plot.setPosition(0,top)
        plot.setHeight(plot_height)
        panel=window.getControl(9282)
        panel.setPosition(-12,max(0,top-10))
        panel.setHeight(plot_height+20)
        if getattr(window,'_synopsis_geometry',None)!=geometry:
            # Kodi caches the textbox's rendered clip height until its text
            # layout changes. A late tagline can resize an unchanged synopsis.
            # LABEL_RESET invalidates that layout while retaining its INFO
            # binding; repeating it would restart the synopsis autoscroll.
            heading_control.reset()
            plot.reset()
        window._synopsis_geometry=geometry
    except (AttributeError,RuntimeError):pass


def filter_geometry(labels):
    desired=[max(120,min(420,math.ceil(width(plain(text),21)*1.06)+68)) for text in labels]
    # Keep the three pills within the hero's available horizontal lane.
    excess=max(0,sum(desired)+30-1120)
    if excess:
        flexible=sum(w-120 for w in desired)
        desired=[w-math.ceil(excess*(w-120)/flexible) for w in desired]
    x=50;result=[]
    for size in desired:
        result.append((x,size));x+=size+15
    return result


def filters(window):
    labels=[window.getProperty('filter_label_%d'%i) for i in range(3)]
    if not any(labels):return
    for i,(x,size) in enumerate(filter_geometry(labels)):
        try:
            window.getControl(9200+i).setPosition(x,535)
            window.getControl(9200+i).setWidth(size)
            if i == 0 and window.getProperty('page') == 'Sports':
                window.getControl(9203).setPosition(x+size+15,535)
            for cid in (9240+i*2,9241+i*2):
                window.getControl(cid).setPosition(x+20,535)
                window.getControl(cid).setWidth(size-64)
            window.getControl(9260+i).setPosition(x+size-35,560)
            if i==2:
                for cid in (9272,9273):window.getControl(cid).setPosition(x+size-44,551)
        except (AttributeError,RuntimeError):pass
