"""Small per-content Discover preferences; never persist provider URLs or items."""
from account import Store
from pathlib import Path


class Preferences:
    def __init__(self, profile):
        self.store = Store(Path(profile) / 'discover-preferences')
        try:
            self.data = self.store.load()
        except Exception:
            self.data = {}
        self.data = self.data if isinstance(self.data, dict) else {}
        for key in ('opening', 'movie', 'series'):
            if key in self.data and not isinstance(self.data[key], dict):
                self.data[key] = {}
        for kind in ('movie', 'series'):
            if kind not in self.data:continue
            saved = self.data[kind]
            for key in ('extras', 'positions'):
                if not isinstance(saved.get(key), dict):
                    saved[key] = {}
            saved['extras'] = {k:v for k,v in saved['extras'].items()
                               if isinstance(k, str) and isinstance(v, str)}
            from lib.progress_values import integer
            saved['positions'] = {k:integer(v) for k,v in saved['positions'].items()
                                   if isinstance(k, str) and len(k) <= 5 and k.isdecimal()}
            for key in ('offset', 'skip'):
                saved[key] = integer(saved.get(key))
            saved['overview'] = saved.get('overview') is True
        if self.data.get('last_kind') not in ('movie', 'series'):
            self.data.pop('last_kind', None)

    def set_opening(self, mode, catalog=None):
        if mode not in ('last', 'anticipated', 'list'):
            raise ValueError('Unknown Discover opening mode')
        opening = {'mode': mode}
        if mode == 'list':
            if not catalog or catalog.get('kind') not in ('movie', 'series') or catalog.get('_search_collection'):
                raise ValueError('Choose a movie or series catalogue')
            opening.update(kind=catalog['kind'], id=catalog['id'], label=catalog.get('label'))
        self.data['opening'] = opening
        self.save()

    def fixed_opening(self):
        return self.data.get('opening', {}).get('mode') in ('anticipated', 'list')

    def opening_options(self, choices):
        labels = ['Last visited list', 'Most Anticipated']
        values = [{'mode':'last'}, {'mode':'anticipated'}]
        for catalog in choices:
            if catalog.get('kind') not in ('movie', 'series') or catalog.get('_search_collection'):
                continue
            labels.append(('Movies' if catalog['kind']=='movie' else 'Series') + ' · ' + str(catalog.get('family') or 'Lists') + ' · ' + catalog['label'])
            values.append({'mode':'list', 'catalog':catalog})
        return labels, values

    def remember(self, catalog, extras, overview, offset, skip, positions):
        if not catalog or catalog.get('kind') not in ('movie', 'series') or catalog.get('_search_collection'):
            return
        kind = catalog['kind']
        self.data[kind] = dict(id=catalog['id'], family=catalog.get('family'), label=catalog.get('label'),
                               extras={k: v for k, v in extras.items() if not k.startswith('_') and isinstance(v, str)},
                               overview=bool(overview), offset=max(0, int(offset)), skip=max(0, int(skip)),
                               positions={str(k): max(0, int(v)) for k, v in positions.items()})
        self.data['last_kind'] = kind

    def restore(self, choices, kind=None):
        from lib.discovery_groups import default_catalogue
        opening = self.data.get('opening', {})
        if opening.get('mode') == 'anticipated':
            return default_catalogue(choices, kind) or default_catalogue(choices), {'overview':False}
        if opening.get('mode') == 'list' and (kind is None or kind == opening.get('kind')):
            catalog = next((c for c in choices if c.get('kind') == opening.get('kind') and c['id'] == opening.get('id')), None)
            return catalog or default_catalogue(choices, kind or opening.get('kind')) or default_catalogue(choices), {'overview':False}
        kind = kind or self.data.get('last_kind')
        saved = self.data.get(kind, {}) if kind in ('movie', 'series') else {}
        catalog = next((c for c in choices if c.get('kind') == kind and c['id'] == saved.get('id')), None)
        if catalog is None:
            return default_catalogue(choices, kind) or default_catalogue(choices), {}
        # Validate filters against the current manifest, which may have changed.
        options = {e['name']: e.get('options', []) for e in catalog.get('extras', []) if e.get('name') not in ('skip', 'search')}
        if saved.get('overview'):
            from lib.discovery_groups import overview_genres
            options = {'genre': overview_genres(choices, catalog)}
        state = dict(saved)
        state['extras'] = {k: v for k, v in saved.get('extras', {}).items() if k in options and v in map(str, options[k])}
        # Cursor-based merged pagination cannot be replayed from a numeric skip.
        state['skip'] = 0
        return catalog, state

    def save(self):
        self.store.save(self.data)
