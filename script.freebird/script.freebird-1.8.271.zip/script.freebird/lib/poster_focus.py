"""Resolve only the settled selection and its small look-ahead window."""
from lib.catalogue_identity import identity
from lib.input_guard import idle


def tick(window):
    if window.closed or window.preview_suspended or not idle(window):return
    cid = window.getFocusId()
    rows = window.rows.get(cid, [])
    if not rows:return
    pos = window.getControl(cid).getSelectedPosition()
    if not 0 <= pos < len(rows):return
    selected = [rows[pos]] + rows[max(0, pos - 6):pos + 14]
    priority = tuple(dict.fromkeys(identity(row) for row in selected if identity(row)))
    key = (window._poster_generation, window.getProperty('page'), cid, priority)
    if window.__dict__.get('_focused_poster_request') == key:return
    window._focused_poster_request = key
    window._poster_priority = priority
    window.refresh_catalog_posters([{'items': selected}])
