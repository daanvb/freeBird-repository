"""Session-only recovery for explicitly selected sources; no URL logging/storage."""
import hashlib
import math
import threading
import time
import uuid

def digest(url):
    return hashlib.sha256(str(url).encode('utf-8')).hexdigest()

def premature_end(position_ms,duration_ms):
    """Leave the final ten percent/last minute and short clips to normal completion."""
    return (type(position_ms) in (int,float) and type(duration_ms) in (int,float)
            and math.isfinite(position_ms) and math.isfinite(duration_ms)
            and duration_ms>=120000 and 0<position_ms<duration_ms*.9
            and duration_ms-position_ms>60000)

def playing_attempt(player):
    try:
        value=player.getPlayingItem().getProperty('Strem4KodiPlaybackAttempt')
        return value if isinstance(value,str) else ''
    except (AttributeError,RuntimeError):return ''


def deliberate_stop(player):
    """Recognise the app's explicit double-Back stop during owned startup."""
    try:
        import json
        import xbmcgui
        from lib.player_back import STOPPING_PROPERTY
        mark=json.loads(xbmcgui.Window(10000).getProperty(STOPPING_PROPERTY))
        elapsed=time.monotonic()-float(mark['time'])
        try:url=player.getPlayingFile()
        except (AttributeError,RuntimeError):url=''
        identity=digest(url) if url else getattr(player,'_active_hash','')
        return bool(identity and mark.get('identity')==identity and 0<=elapsed<=3.0)
    except (ImportError,AttributeError,RuntimeError,ValueError,TypeError,KeyError):
        return False


def persist_failure(profile, pending, reason):
    """Share an owned rejection with the independent progress observer."""
    if profile is None or not pending:return
    from pathlib import Path
    from account import Store
    try:
        Store(Path(profile)/'source-failure').save({
            'hash':pending['hash'], 'attempt':pending['attempt'],
            'reason':reason, 'created':time.time()})
    except Exception:pass  # Optional cross-listener evidence cannot break retry.


def owns_stream(player, stream, url):
    """An active attempt can identify a source after Kodi follows a redirect."""
    expected=stream.get('_playback_attempt')
    token=playing_attempt(player) if expected else ''
    if token and token!=expected:return False
    return bool(url==stream.get('url') or (expected and token==expected))


def stop_failed(player,event,clock=time.monotonic):
    """Serialise failure recovery with native player shutdown; Stop is async."""
    from lib.native_playback import busy
    if busy():
        # isPlayingVideo is false during resolver/decoder startup. That is not
        # permission to open another modal or dispatch another PlayMedia.
        event.setdefault('busy_since',clock())
        return 'blocked' if clock()-event['busy_since']>=15 else 'waiting'
    event.pop('busy_since',None)
    try:
        if not player.isPlayingVideo():return 'ready'
        current=player.getPlayingFile()
        from source_probe import error_video
        redirected_error=(event.get('reason')=='provider-error-video' and error_video(current))
        if (playing_attempt(player)!=event['attempt'] and digest(current)!=event['hash']
                and not redirected_error):
            return 'unrelated'
        if 'stop_requested' not in event:
            event['stop_requested']=clock()
            player.stop()
            return 'waiting'
        return 'blocked' if clock()-event['stop_requested']>=5 else 'waiting'
    except (AttributeError,RuntimeError):
        return 'blocked'


def opening_attempt(player,pending):
    """Identify a native player opening without marking AV/progress successful."""
    if not pending:return ''
    try:
        from lib.prerolls import phase
        intro=phase()
        if intro and intro.startswith('handoff:'):
            # Keep the neutral cover until AVStarted confirms the movie.
            # Kodi switches the playing item before its fullscreen window is
            # ready. Closing on that early callback exposes the title screen.
            # The cover's XML already hides it while fullscreen is visible.
            return ''
        if intro and not intro.startswith('handoff:'):
            # Keep the owned card through an audio pre-roll. Kodi briefly
            # leaves the fullscreen window while handing the intro to the
            # selected movie; closing here exposes the source picker beneath it.
            return ''
        attempt=playing_attempt(player)
        if attempt:return attempt if attempt==pending['attempt'] else ''
        return pending['attempt'] if digest(player.getPlayingFile())==pending['hash'] else ''
    except (AttributeError,RuntimeError,KeyError,TypeError):return ''

class RecoveryTracker:
    def __init__(self,clock=time.monotonic,profile=None):
        self.clock=clock;self.profile=profile;self.lock=threading.RLock();self.pending=None;self.event=None
    def _finish_trace(self, outcome):
        with self.lock:
            if getattr(self, '_buffer_trace', None) is not None:
                from lib.seek_diagnostics import finish
                finish(self, outcome)
    def arm(self,url,identity,resume_ms,window,automatic=False,provider=None,live_sports=False):
        with self.lock:
            self._finish_trace('replaced')
            self.event=None
            self.pending={'hash':digest(url),'identity':identity,'resume':resume_ms,
                          'window':window,'created':self.clock(),'started':False,
                          'automatic':bool(automatic),'attempt':uuid.uuid4().hex,
                          'live_sports':bool(live_sports),
                          'resume_target':max(0,int(resume_ms or 0))}
            if provider:
                from lib.provider_health import identity as provider_identity
                self.pending['provider_health'] = provider_identity(provider)
            return self.pending['attempt']
    def poll_failure(self, profile):
        from pathlib import Path
        if not isinstance(profile, (str, Path)):return
        with self.lock:
            if not self.pending:return
            from account import Store
            try:row = Store(Path(profile)/'source-failure').load()
            except Exception:return
            if row.get('hash') == self.pending['hash'] and row.get('attempt') == self.pending['attempt']:
                self.failed(row.get('reason', 'http-unavailable'))
    def startup_timeout(self):
        with self.lock:
            if self.pending and not self.pending.get('preroll') and not self.pending['started'] and self.clock()-self.pending['created']>45:
                self._finish_trace('startup-timeout')
                from lib.source_failures import record
                record(self.profile,self.pending['hash'])
                self.event=dict(self.pending,reason='startup-timeout')
                self.pending=None
    def preroll(self, active):
        with self.lock:
            if self.pending:
                self.pending['preroll']=bool(active)
                if not active:self.pending['created']=self.clock()
    def started(self,url,attempt=''):
        with self.lock:
            if self.pending:
                if attempt and attempt!=self.pending['attempt']:return
                current=self.pending['attempt']
                # Kodi may report the redirected URL instead of the selected URL.
                # The resolver's attempt property identifies that same playback.
                if not attempt and digest(url)!=self.pending['hash']:
                    self._finish_trace('replaced')
                    self.pending=None
                    return
                self.pending['started']=True
                self.pending.setdefault('started_at', self.clock())
                return current
    def snapshot(self):
        with self.lock:
            return dict(self.pending) if self.pending else None
    def loading_state(self):
        """Keep a failed attempt covered until its owner chooses the retry."""
        with self.lock:
            if self.pending:return dict(self.pending)
            return dict(self.event,failed=True) if self.event else None
    def position(self,url,seconds,attempt='',duration=None):
        with self.lock:
            if (self.pending and (not attempt or attempt==self.pending['attempt']) and
                    (digest(url)==self.pending['hash'] or attempt==self.pending['attempt'])):
                position=max(0,int(seconds*1000))
                target=self.pending['resume_target']
                # Kodi can expose zero/the opening seconds before its initial
                # seek lands. Preserve the requested point for a replacement
                # source, using the observer's three-second seek tolerance.
                if target and position < max(1000,target-3000):return
                self.pending['resume_target']=0
                self.pending['resume']=position
                # Terminal callbacks often arrive after Kodi clears its clocks.
                # Keep a fresh owned position/duration pair for early EOF only.
                try:
                    total=float(duration) if type(duration) in (int,float) else 0
                    total=total if math.isfinite(total) and total>0 else 0
                except (ValueError,TypeError,OverflowError):total=0
                self.pending['end_sample']=(self.clock(),position,total*1000)
    def ended(self):
        """Recover only a freshly observed automatic VOD ending far from credits."""
        with self.lock:
            pending=self.pending
            if pending and pending.get('automatic') and pending['started'] and not pending.get('live_sports'):
                sampled,position,duration=pending.get('end_sample',(0,0,0))
                if 0<=self.clock()-sampled<=5 and premature_end(position,duration):
                    self.failed('premature-end')
                    return
            self.stopped()
    def caching(self,active,cache_level=None,attempt='',queues=None):
        """Recover automatic VOD after 12 seconds without cache or queue growth."""
        with self.lock:
            pending=self.pending
            if not pending:return
            if attempt and pending['attempt']!=attempt:return
            if (not active or not pending.get('automatic') or not pending['started']
                    or pending.get('live_sports') or pending.get('preroll')):
                pending.pop('caching_since',None)
                pending.pop('cache_high_water',None)
                pending.pop('queue_high_water',None)
                pending.pop('buffer_progress_source',None)
                return
            now=self.clock()
            pending.setdefault('caching_since',now)
            # Kodi reports integer percentages. A new high-water mark proves
            # refill progress, including after a resume/seek. A fixed playback
            # clock or a stuck Seeking flag does not prove the stream is dead
            # or alive. Missing readings retain the ordinary stall deadline.
            try:
                level=float(cache_level) if type(cache_level) in (str,int,float) else -1
                if math.isfinite(level) and 0<=level<=100:
                    high=pending.setdefault('cache_high_water',level)
                    if level-high>=1:
                        pending['cache_high_water']=level
                        pending['caching_since']=now
                        pending['buffer_progress_source']='cache_pct'
            except (ValueError,TypeError,OverflowError):pass
            # Queue refill can precede growth in Kodi's file cache after a
            # seek. Only new high-water marks count: oscillating/stale/full
            # queues or a first observation are not recovery progress.
            from lib.playback_buffer import QUEUE_LABELS, percentage
            high_water=pending.setdefault('queue_high_water',{})
            for key in QUEUE_LABELS:
                level=percentage(queues.get(key)) if isinstance(queues,dict) else None
                if level is None:continue
                high=high_water.setdefault(key,level)
                if level-high>=1:
                    high_water[key]=level
                    pending['caching_since']=now
                    pending['buffer_progress_source']=key
            if now-pending['caching_since']>=12:self.failed('caching-stall')
    def _health(self, success=False):
        if self.pending and self.pending.get('automatic') and self.pending.get('provider_health'):
            from lib.provider_health import record
            record(self.pending['provider_health'], success=success)
    def failed(self, reason=None):
        confirmed=reason is not None
        reason=reason or 'playback-error'
        with self.lock:
            self._finish_trace(reason)
            if self.pending and self.pending.get('live_sports') and self.pending['started']:
                self.pending=None
                return  # Persistent service owns recovery after sports AV start.
            if self.pending and (self.pending['started'] or self.clock()-self.pending['created']<120):
                if confirmed:
                    from lib.source_failures import record
                    record(self.profile,self.pending['hash'])
                if confirmed and reason in ('provider-error-video','http-unavailable','playback-error','caching-stall','premature-end'):
                    self._health()
                self.event=dict(self.pending)
                self.event['reason']=reason if reason in {'provider-error-video','http-unavailable','startup-timeout','playback-stopped','playback-error','caching-stall','premature-end'} else 'unknown'
            self.pending=None
    def stopped(self):
        with self.lock:
            self._finish_trace('stopped')
            self.pending=None
    def take(self):
        with self.lock:
            event=self.event;self.event=None;return event
    def clear(self):
        with self.lock:
            self._finish_trace('cancelled')
            self.pending=None;self.event=None

def check_source(tracker, url, attempt, live=False, profile=None, redirect_only=False):
    """Check redirects in parallel with Kodi; only fail the same owned attempt."""
    with tracker.lock:
        if not tracker.pending or tracker.pending['attempt']!=attempt or tracker.pending['hash']!=digest(url):return
        tracker.pending['checking']=True
    def check():
        from source_probe import unavailable, redirect_failure
        probe=redirect_failure if redirect_only else unavailable
        failure=probe(url, live=live)
        with tracker.lock:
            if tracker.pending and tracker.pending['attempt']==attempt:
                from lib.runtime_trace import playback
                playback('redirect.failed' if failure else 'redirect.inconclusive',
                         reason=failure if failure else None)
                tracker.pending['checking']=False
                if failure:
                    if profile is not None:
                        from pathlib import Path
                        from account import Store
                        try:Store(Path(profile)/'source-failure').save({'hash':digest(url),'attempt':attempt,'reason':failure})
                        except Exception:pass
                    tracker.failed(failure)
    worker=threading.Thread(target=check,daemon=True)
    try:worker.start()
    except RuntimeError:
        with tracker.lock:
            if tracker.pending and tracker.pending['attempt']==attempt:tracker.pending['checking']=False

def preroll_video(native):
    from lib.prerolls import ORIGIN, phase
    try:
        current = phase()
        key = current.partition(':')[2] if current.startswith('handoff:') else current
        marker = native.getPlayingItem().getProperty('Strem4KodiPreRoll')
        if isinstance(marker, str) and key and marker == key:return True
    except (AttributeError, RuntimeError):pass
    try:
        url = native.getPlayingFile()
        return isinstance(url, str) and url.startswith(ORIGIN)
    except (AttributeError, RuntimeError):return False


def startup_video_state(native, pending):
    """Classify before releasing the cover, including delayed duration metadata."""
    from lib.prerolls import phase
    intro = phase()
    if intro and not intro.startswith('handoff:'):return 'waiting'
    # Intro and feature share an attempt token. That token cannot distinguish
    # them, including redirects and the interval after Skip but before PlayMedia.
    if preroll_video(native):return 'waiting'
    from source_probe import error_video, comet_episode_request, comet_episode_status_video
    url=native.getPlayingFile()
    if error_video(url):return 'failed'
    pending=pending or {}
    if comet_episode_request(url,pending.get('identity'),pending.get('automatic',False)):
        try:duration=float(native.getTotalTime())
        except (AttributeError,RuntimeError,TypeError,ValueError):return 'waiting'
        if duration<=0:return 'waiting'
        if comet_episode_status_video(url,duration,pending.get('identity'),True):return 'failed'
    return 'ready'


def player(tracker, profile=None, on_started=None, on_opened=None, on_intro=None):
    import xbmc
    if profile is not None:tracker.profile=profile
    class RecoveryPlayer(xbmc.Player):
        _preroll = False
        _preroll_error = False
        _active_hash = None
        def _opening_intro(self):
            from lib.prerolls import phase
            pending=tracker.snapshot();current=phase()
            if not pending or not current or current.startswith('handoff:'):return False
            try:
                item=self.getPlayingItem()
                if (item.getProperty('Strem4KodiPreRoll')!=current or
                        playing_attempt(self)!=pending['attempt']):return False
            except (AttributeError,RuntimeError):return False
            self._preroll=True
            tracker.preroll(True)
            if on_intro:on_intro(pending['attempt'])
            return True
        def onPlayBackStarted(self):
            # This callback precedes AVStarted and display/decoder readiness.
            # Manual playback may yield now; automatic playback must first
            # validate AV metadata so a provider failure video stays covered.
            if self._opening_intro():return
            pending=tracker.snapshot()
            attempt=opening_attempt(self,pending)
            if attempt:
                # Remember ownership before AVStarted. Some Kodi/provider
                # failures stop the item without ever delivering onAVStarted.
                self._active_attempt=attempt
                self._active_hash=pending['hash']
                try:
                    url=self.getPlayingFile()
                    if url:self._active_hash=digest(url)
                except (AttributeError,RuntimeError):pass
            # An error MP4 also fires this callback. Automatic attempts retain
            # their cover until AV metadata has passed provider validation.
            if pending and pending.get('automatic'):return
            if attempt and on_opened:on_opened(attempt)
        def onAVStarted(self):
            try:
                url=self.getPlayingFile()
                from lib.prerolls import phase, clear_phase
                current_phase=phase()
                if preroll_video(self):
                    if current_phase and not current_phase.startswith('handoff:'):self._opening_intro()
                    return
                if current_phase and not current_phase.startswith('handoff:'):
                    self._opening_intro()
                    return
                pending=tracker.snapshot()
                native_attempt=playing_attempt(self)
                if pending and native_attempt and native_attempt!=pending['attempt']:return
                if (pending and not native_attempt and digest(url)!=pending['hash'] and
                        startup_video_state(self,pending)!='failed'):
                    # A queued AV callback for the previous trailer/episode
                    # must not disarm the new request or clear its handoff.
                    # Recognized provider error videos still need recovery
                    # when Kodi drops the attempt property on a redirect.
                    return
                self._active_hash=digest(url)
                self._preroll=False
                self._preroll_error=False
                tracker.preroll(False)
                if current_phase.startswith('handoff:'):clear_phase(current_phase)
                state=startup_video_state(self,pending)
                if state=='failed':
                    # Native player calls are deferred to the recovery tick;
                    # do not stop/reopen playback inside an AV callback. Kodi
                    # can lose the attempt property on an HTTP redirect, so a
                    # recognized provider slate is enough to fail the single
                    # pending app-owned attempt.
                    if pending and (native_attempt == pending['attempt'] or not native_attempt):
                        persist_failure(profile,pending,'provider-error-video')
                        tracker.failed('provider-error-video')
                elif state=='ready':
                    attempt=tracker.started(url,native_attempt)
                    if attempt and on_started:on_started(attempt)
            except Exception as error:
                # Kodi may clear the item before this queued AV callback can
                # query it. That is neither successful playback nor a user
                # cancellation. Keep the attempt armed for Error/Stop recovery
                # or its existing startup timeout instead of dropping its cover.
                pending=tracker.snapshot()
                from lib.runtime_trace import playback
                playback('startup.callback_error',started=bool(pending and pending.get('started')),
                         owned=bool(pending and getattr(self,'_active_attempt','')==pending['attempt']),
                         error=error)
        def onPlayBackError(self):
            pending=tracker.snapshot()
            attempt=playing_attempt(self)
            if pending and attempt and attempt!=pending['attempt']:return
            from lib.prerolls import phase
            current_phase = phase()
            if preroll_video(self) or (current_phase and not current_phase.startswith('handoff:')):
                self._preroll_error=True
                tracker.preroll(False)
            else:
                self._preroll=False
                tracker.failed('playback-error')
        def onPlayBackStopped(self):
            from lib.prerolls import phase
            if phase() and (self._preroll_error or (self._preroll and phase().startswith('handoff:'))):
                self._preroll=False
                self._preroll_error=False
                tracker.preroll(False)
                return
            tracker.poll_failure(profile)
            if self._startup_terminal():return
            self._finish_current()
        def _startup_terminal(self):
            """Kodi can reject an owned item without its opening/AV callbacks."""
            pending=tracker.snapshot()
            attempt=playing_attempt(self)
            if pending and attempt and attempt!=pending['attempt']:return True
            if (pending and pending.get('automatic') and not pending.get('started')
                    and not pending.get('preroll') and (attempt==pending['attempt']
                    or getattr(self,'_active_attempt','')==pending['attempt'])):
                try:
                    if self.isPlayingVideo() is True:return True
                except (AttributeError,RuntimeError):pass
                if deliberate_stop(self):
                    tracker.stopped()
                    return True
                # Kodi can report a failed source as Stopped without sending
                # PlaybackError or AVStarted. Preserve the normal bounded
                # source retry path for this owned startup failure.
                persist_failure(profile,pending,'playback-stopped')
                tracker.failed('playback-stopped')
                return True
            return False
        def _finish_current(self,ended=False):
            pending=tracker.snapshot()
            if pending and pending.get('automatic') and not pending['started']:
                # A Stop/End without an identified opening can belong to the
                # previous video or to a failed resolver. Neither proves that
                # this new request was cancelled. Owned Stop is handled above;
                # ambiguous callbacks leave the bounded startup timer running.
                from lib.runtime_trace import playback
                playback('startup.terminal_wait')
                return
            # A lasting listener also sees the trailer/previous video's queued
            # Stop/End. That event must not clear a newly armed source attempt.
            if (pending and not pending['started'] and self._active_hash
                    and pending['hash']!=self._active_hash and not self._preroll):return
            if ended and pending and pending.get('automatic') and not deliberate_stop(self):
                # A queued End must not recover over replacement playback.
                attempt=playing_attempt(self)
                if attempt and attempt!=pending['attempt']:return
                try:
                    if self.isPlayingVideo():
                        if (attempt!=pending['attempt'] and
                                digest(self.getPlayingFile()) not in (pending['hash'],self._active_hash)):
                            tracker.stopped()
                        # Still playing: this can be the previous item's queued
                        # End arriving after the replacement has already started.
                        return
                except (AttributeError,RuntimeError):
                    if not attempt:return
                tracker.ended()
            else:tracker.stopped()
        def onPlayBackEnded(self):
            if self._preroll:
                self._preroll=False
                tracker.preroll(False)
            else:
                tracker.poll_failure(profile)
                if not self._startup_terminal():self._finish_current(ended=True)
    native=RecoveryPlayer()
    try:
        if native.isPlayingVideo():native._active_hash=digest(native.getPlayingFile())
    except (AttributeError,RuntimeError):pass
    return native
