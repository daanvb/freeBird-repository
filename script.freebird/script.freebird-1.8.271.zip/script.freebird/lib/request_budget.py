"""Bounded daemon workers and caller deadlines for optional metadata work."""
import queue
import threading
import time
from concurrent.futures import Future, TimeoutError


class Pool:
    def __init__(self, workers=6, pending=24):
        self.jobs = queue.Queue(pending)
        self.workers = workers
        self.lock = threading.Lock()
        self.started = 0

    def submit(self, work):
        with self.lock:
            if self.started < self.workers:
                for _ in range(self.workers - self.started):
                    threading.Thread(target=self._run, daemon=True).start()
                    self.started += 1
        future = Future()
        try:self.jobs.put_nowait((future, work))
        except queue.Full:future.set_exception(RuntimeError('Metadata workers busy'))
        return future

    def _run(self):
        while True:
            future, work = self.jobs.get()
            try:
                if future.set_running_or_notify_cancel():
                    try:future.set_result(work())
                    except Exception as error:future.set_exception(error)
            finally:self.jobs.task_done()


REQUESTS = Pool()


class Budget:
    def __init__(self, seconds=20, alive=lambda: True, clock=time.monotonic, pool=REQUESTS):
        self.clock, self.alive, self.pool = clock, alive, pool
        self.deadline = clock() + max(0, seconds)
        self.closed = False
        self.futures = []

    def remaining(self):
        return max(0, self.deadline - self.clock()) if not self.closed and self.alive() else 0

    def submit(self, work):
        def guarded():
            if not self.remaining():raise TimeoutError()
            return work()
        future = self.pool.submit(guarded)
        self.futures.append(future)
        return future

    def result(self, future, default=None):
        while self.remaining():
            try:return future.result(timeout=min(.05, self.remaining()))
            except TimeoutError:
                if future.done():return default
                continue
            except Exception:return default
        future.cancel()
        return default

    def close(self):
        self.closed = True
        for future in self.futures:future.cancel()
