"""Attempt-bound playback loading screen; never stores stream URLs."""
import json
import threading
import time
import uuid
import xml.etree.ElementTree as ET
from lib.stream_presenter import line

CANCEL_KEY='strem4kodi.playback.cancelled'
ACTIVE_KEY='strem4kodi.loading.active'
COVER_KEY='strem4kodi.loading.cover'
_visibility_lock=threading.RLock()
_dialog_gate=threading.Lock()


def loading_artwork(meta, background='', sports=False):
    landscape = sports or meta.get('type') in ('sport', 'sports')
    poster = meta.get('poster') or ''
    if landscape:
        poster = (meta.get('landscape') or meta.get('thumbnail') or meta.get('thumb')
                  or meta.get('background') or poster)
    return dict(poster=poster, background=background or meta.get('background') or '',
                landscape=bool(landscape))


def trivia_fields(art,sources=False):
    text=art.get('trivia') or ''
    label=art.get('trivia_label') or ''
    source=(art.get('trivia_sources') or {}).get(text,'')
    if sources and source:
        attribution=('Wikipedia contributors · CC BY-SA 4.0 · excerpt\n'
                     if 'Wikipedia' in label else '')
        return 'Trivia source',attribution+source,'Info: back to trivia'
    return label.split(' · ',1)[0],text,''


def _busy_owner(token, clear=False):
    """Suppress only the companion skin's duplicate busy artwork, not Kodi's work."""
    try:
        import xbmcgui
        with _visibility_lock:
            home=xbmcgui.Window(10000)
            if clear:
                if home.getProperty(ACTIVE_KEY)==token:home.clearProperty(ACTIVE_KEY)
                if home.getProperty(COVER_KEY)==token:home.clearProperty(COVER_KEY)
            else:home.setProperty(ACTIVE_KEY,token)
    except (ImportError,AttributeError,RuntimeError):pass

def _initial_layout(tree,title,detail,art):
    """Populate the very first frame, before Kodi queues Python onInit."""
    art=dict(art or {})
    if art.get('landscape'):
        image=tree.find('.//control[@id="305"]')
        for key,value in (('top','438'),('width','288'),('height','162'),('aspectratio','keep')):
            image.find(key).text=value
        # A portrait mask would clip the team logos at the image edges.
        image.find('texture').attrib.pop('diffuse',None)
        tree.find('.//control[@id="306"]/left').text='648'
        for control in tree.findall('.//control[@id="300"]/control'):
            left=control.find('left')
            if left is not None and int(left.text)>=852:
                left.text=str(int(left.text)+56)
                width=control.find('width')
                if width is not None and int(width.text)==484:width.text='428'
    fact_label,fact_text,fact_hint=trivia_fields(art)
    owner=art.get('_loading_owner')
    if owner:
        # Kodi can process a queued show after close. Gate every top-level
        # control against this lifetime, including the opaque backdrop.
        for index,control in enumerate(tree.findall('./controls/control')):
            # Fullscreen can be a provider's error MP4. Keep covering it until
            # the attempt is validated; only an actual pre-roll may show through.
            condition=('String.IsEqual(Window(Home).Property({}),{}) + '
                       '[!String.IsEqual(Window(Home).Property({}),{}) | '
                       '!Window.IsVisible(fullscreenvideo) | '
                       'String.IsEmpty(Window(Home).Property(strem4kodi.preroll)) | '
                       'String.StartsWith(Window(Home).Property(strem4kodi.preroll),handoff:)]').format(ACTIVE_KEY,owner,COVER_KEY,owner)
            # Restore the existing card during intro-to-feature handoff. Keeping
            # only a backdrop here hides feedback and can expose details when
            # an intro is wrongly classified as the feature by another listener.
            ET.SubElement(control,'visible').text=condition
    for cid,value in ((301,art.get('stage') or 'Starting playback'),(302,title),
                      (303,art.get('hint') or 'Opening your selected source'),
                      (304,detail),(311,fact_label),(312,fact_text),(313,fact_hint)):
        tree.find('.//control[@id="{}"]/label'.format(cid)).text=value
    for cid,key in ((305,'poster'),(307,'background')):
        tree.find('.//control[@id="{}"]/texture'.format(cid)).text=art.get(key) or ''
    # Keep the optional frame absent even before the first callback arrives.
    if not art.get('trivia'):
        tree.find('.//control[@id="314"]/texture').text=''
    if art.get('poster'):
        tree.find('.//control[@id="306"]/texture').text=''

def cancelled(attempt):
    if not attempt:return False
    import xbmcgui
    try:return attempt in json.loads(xbmcgui.Window(10000).getProperty(CANCEL_KEY) or '[]')
    except (ValueError,TypeError):return False

def signal_cancel(attempt):
    if not attempt:return
    import xbmcgui
    window=xbmcgui.Window(10000)
    try:rows=json.loads(window.getProperty(CANCEL_KEY) or '[]')
    except (ValueError,TypeError):rows=[]
    if not isinstance(rows,list):rows=[]
    window.setProperty(CANCEL_KEY,json.dumps((rows+[attempt])[-16:]))

def _make_window(title,detail,on_cancel,art=None):
    import xbmcgui
    from addon_state import get_addon
    from lib.theme import window as themed_window
    class LoadingWindow(xbmcgui.WindowXMLDialog):
        initialized=False
        dismissed=False
        sources=False
        def render_fact(self,art):
            for cid,value in zip((311,312,313),trivia_fields(art,self.sources)):
                control=self.getControl(cid)
                if cid==312:control.setText(value)
                else:control.setLabel(value)
        def update(self,title,detail='',art=None):
            self.content=(title,detail,dict(art or {}))
            if not self.initialized or self.dismissed:return
            # Modeless dialog Window.Property can resolve against the underlying
            # media window. Address this dialog's own controls for every field.
            title,detail,art=self.content
            self.getControl(301).setLabel(art.get('stage') or 'Starting playback')
            self.getControl(302).setText(title)
            self.getControl(303).setText(art.get('hint') or 'Opening your selected source')
            self.getControl(304).setText(detail)
            for cid,name in ((305,'poster'),(307,'background')):
                self.getControl(cid).setImage(art.get(name) or '')
                self.getControl(cid).setVisible(bool(art.get(name)))
            self.getControl(306).setVisible(not bool(art.get('poster')))
            self.getControl(310).setVisible(bool(art.get('trivia')))
            self.getControl(314).setImage('special://home/addons/script.freebird/resources/skins/Main/media/controls/status-rounded-v1.png' if art.get('trivia') else '')
            self.render_fact(art)
        def hint(self,text):
            title,detail,art=self.content
            art['hint']=text
            self.content=(title,detail,art)
            if self.initialized and not self.dismissed:self.getControl(303).setText(text)
        def fact(self,label,text):
            title,detail,art=self.content
            self.content=(title,detail,dict(art,trivia_label=label,trivia=text))
            if self.initialized and not self.dismissed:
                self.render_fact(self.content[2])
        def onInit(self):
            if self.dismissed:
                self.close()
                return
            self.initialized=True
            self.update(*self.content)
            self.setFocusId(201)
            shown=(art or {}).get('_loading_shown')
            if shown is not None:shown.set()
        def onAction(self,action):
            if action.getId() in (10,13,92,216,247):on_cancel()
            elif action.getId()==11 and not self.dismissed:
                self.sources=not self.sources
                self.render_fact(self.content[2])
        def onClick(self,control_id):
            if control_id==201:on_cancel()
    window=themed_window(LoadingWindow,'script-freebird-loading.xml',
                         get_addon().getAddonInfo('path'),'Main','1080i',
                         unique_layout=True,
                         layout_transform=lambda tree:_initial_layout(tree,title,detail,art))
    window.update(title,detail,art)
    return window

class LoadingSession:
    def __init__(self,on_cancel,factory=_make_window,state=None,ready=None,clock=time.monotonic,
                 thread_factory=threading.Thread):
        self.on_cancel=on_cancel;self.factory=factory
        self.lock=threading.RLock();self.attempt='';self.window=None
        self.state=state;self.ready=ready;self.clock=clock
        self.created=0;self.elapsed=-1;self.wake=threading.Event()
        self.lifetime=None;self.content=None;self.ui_thread=None
        self.visibility_token='';self.covered=False;self.video_started_at=None;self.fullscreen_requested=False
        self.rotation_wake=threading.Event();self.rotation_due=0
        self.rotation_running=False
        self.thread_factory=thread_factory
        self.cancel_done=threading.Event();self.cancel_done.set()
        self.shown=threading.Event()
    def begin(self,attempt,title,detail='',art=None):
        self.finish()
        try:
            with self.lock:
                self.attempt=attempt
                self.covered=False;self.video_started_at=None;self.fullscreen_requested=False
                self.created=self.clock();self.elapsed=-1;self.wake=threading.Event()
                self.content=(line(title,110),line(detail,140),dict(art or {}))
                self.rotation_wake=threading.Event();self.rotation_due=self.clock()+10
                self.rotation_running=False
                lifetime=self.lifetime=threading.Event()
                self.shown=threading.Event()
                self.visibility_token=uuid.uuid4().hex
                _busy_owner(self.visibility_token)
                self.ui_thread=self.thread_factory(target=self._run_dialog,args=(lifetime,),daemon=True)
                self.ui_thread.start()
                if len(self.content[2].get('trivia_choices') or [])>1:
                    self.rotation_running=True
                    self.thread_factory(target=self._rotate_facts,args=(lifetime,self.rotation_wake),daemon=True).start()
                if self.state is not None:
                    threading.Thread(target=self._watch,args=(attempt,self.wake),daemon=True).start()
        except RuntimeError:
            self.finish(attempt)
            raise
    def _run_dialog(self,lifetime):
        """Create AND pump on the same live thread; never nest in a media callback.

        Kodi binds callbacks to the Python thread that constructs the window.
        A parent callback must return so provider updates can acquire its native
        window lock. Calling doModal inside that callback stalls those updates.
        """
        window=None;acquired=False
        try:
            # Native close is queued: a replacement must wait for the previous
            # modal loop to unwind, including windows owned by another session.
            while not acquired:
                with self.lock:
                    if self.lifetime is not lifetime:return
                acquired=_dialog_gate.acquire(timeout=.1)
            from lib.native_playback import busy
            while busy():
                with self.lock:
                    if self.lifetime is not lifetime:return
                    wake=self.wake
                if wake.wait(.1):return
            with self.lock:
                if self.lifetime is not lifetime:return
                title,detail,art=self.content
                owner=self.visibility_token
                shown=self.shown
            arguments=(title,detail,lambda:self._cancel_window(window))
            window=self.factory(*arguments,dict(art,_loading_owner=owner,_loading_shown=shown))
            with self.lock:
                if self.lifetime is not lifetime:
                    window.dismissed=True
                    return
                self.window=window
                content=self.content
            window.update(*content)
            # Construction may race with Kodi entering its resolver wait.
            while busy():
                with self.lock:
                    if self.lifetime is not lifetime:return
                    wake=self.wake
                if wake.wait(.1):return
            with self.lock:
                if self.lifetime is not lifetime:return
            window.doModal()
        except Exception:
            pass  # Native GUI failures must not print a private source/title.
        finally:
            self.finish(lifetime=lifetime)
            # doModal can return as soon as close flips its modal flag, before
            # another thread's synchronous native close has returned.
            lifetime.wait()
            # Attempt-specific layouts prevent overlapping construction/retry
            # from loading the other dialog's owner or first-frame content.
            path=getattr(window,'_theme_layout_path',None) if window else None
            if path:
                try:path.unlink()
                except OSError:pass
            if acquired:_dialog_gate.release()
    def _cancel_window(self,window):
        self.cancel(window=window)
    def wait_visible(self,attempt,timeout=5):
        """Only dispatch from a worker after this card has initialised.

        Waiting in a Kodi input callback prevents the dialog's onInit from
        running. Cancellation or a new lifetime invalidates this wait.
        """
        with self.lock:
            lifetime=self.lifetime;shown=self.shown
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            with self.lock:
                if self.attempt!=attempt or self.lifetime is not lifetime:return False
            if shown.wait(min(.05,max(0,deadline-time.monotonic()))):
                # Yield one rendering interval after onInit; never dispatch
                # from inside that native activation callback.
                if lifetime is None or lifetime.wait(.05):return False
                with self.lock:
                    return self.attempt==attempt and self.lifetime is lifetime
        return False
    def cover(self,attempt):
        """Retain a neutral gap cover through the intro, with no new window."""
        import xbmcgui
        with self.lock:
            if self.attempt!=attempt or not self.visibility_token:return
            with _visibility_lock:
                home=xbmcgui.Window(10000)
                if home.getProperty(ACTIVE_KEY)==self.visibility_token:
                    home.setProperty(COVER_KEY,self.visibility_token)
                    self.covered=True
    def advance(self,attempt,title,detail='',art=None,on_cancel=None,state=None,ready=None):
        """Transfer search to playback without closing or allocating a dialog."""
        try:
            with self.lock:
                if not self.attempt:return False
                self.wake.set()
                self.attempt=attempt
                self.covered=False;self.video_started_at=None;self.fullscreen_requested=False
                self.on_cancel=on_cancel or self.on_cancel
                self.state,self.ready=state,ready
                self.created=self.clock();self.elapsed=-1;self.wake=threading.Event()
                next_art=dict(art or {})
                # Handover retains both the current fact and the ten-second cadence.
                previous=self.content[2] if self.content else {}
                for key in ('trivia','trivia_label','trivia_choices','trivia_sources'):
                    if key in previous:next_art[key]=previous[key]
                self.content=(line(title,110),line(detail,140),next_art)
                # A retry reuses this lifetime but must show the card again after
                # an intro's neutral cover, without allocating another modal.
                try:
                    import xbmcgui
                    with _visibility_lock:
                        home=xbmcgui.Window(10000)
                        if home.getProperty(COVER_KEY)==self.visibility_token:home.clearProperty(COVER_KEY)
                except (ImportError,AttributeError,RuntimeError):pass
                window=self.window
                content=self.content
                if state is not None:
                    threading.Thread(target=self._watch,args=(attempt,self.wake),daemon=True).start()
            if window:window.update(*content)
            return True
        except RuntimeError:
            self.finish(attempt)
            raise
    def load_trivia(self,meta):
        """Subscribe without HTTP/disk work or a wait on any input/playback thread."""
        from lib import loading_trivia
        with self.lock:lifetime=self.lifetime
        def arrived(rows):
            if rows:self._accept_trivia(lifetime,loading_trivia.choose(meta,rows))
        loading_trivia.prefetch(meta,arrived)
    def _accept_trivia(self,lifetime,card):
        start=False
        with self.lock:
            if self.lifetime is not lifetime or not self.attempt or not card:return
            title,detail,art=self.content
            self.content=(title,detail,dict(art,**card))
            self.rotation_due=self.clock()+10
            window=self.window;content=self.content;wake=self.rotation_wake
            if not self.rotation_running and len(card.get('trivia_choices') or [])>1:
                self.rotation_running=True;start=True
        if window:window.update(*content)
        if start:
            try:self.thread_factory(target=self._rotate_facts,args=(lifetime,wake),daemon=True).start()
            except RuntimeError:
                with self.lock:
                    if self.lifetime is lifetime:self.rotation_running=False
                raise
    def hint(self,text):
        with self.lock:
            if not self.content:return
            title,detail,art=self.content
            self.content=(title,detail,dict(art,hint=text))
            window=self.window
        if window:window.hint(text)
    def _rotate_facts(self,lifetime,wake):
        while not wake.wait(.2):
            try:self.rotate_fact(lifetime)
            except Exception:pass  # Optional facts never interrupt playback or Cancel.
    def rotate_fact(self,lifetime):
        with self.lock:
            if self.lifetime is not lifetime or self.clock()<self.rotation_due or not self.content:return
            title,detail,art=self.content
            choices=art.get('trivia_choices') or []
            if len(choices)<2:return
            current=(art.get('trivia_label'),art.get('trivia'))
            position=next((i for i,row in enumerate(choices) if tuple(row)==current),-1)
            label,text=choices[(position+1)%len(choices)]
            self.content=(title,detail,dict(art,trivia_label=label,trivia=text))
            self.rotation_due=self.clock()+10
            window=self.window
        if window:window.fact(label,text)
    def _watch(self,attempt,wake):
        """Keep overlay cleanup independent of the media-details refresh thread."""
        while not wake.wait(.2):
            try:
                pending=self.state()
                # AVStarted identifies the movie; the intro's neutral cover
                # remains until Kodi has restored its fullscreen video view.
                ready=bool(not (pending and pending.get('started')) and self.ready and self.ready())
                self.check(attempt,pending,ready)
            except Exception:
                # Even unavailable player/state queries cannot strand the dialog.
                self.check(attempt,{'attempt':attempt,'started':False})
    def check(self,attempt,pending,ready=False):
        text=None
        with self.lock:
            if self.attempt!=attempt:return
            if pending and pending.get('attempt')==attempt and pending.get('preroll'):
                # A long intro is not a stalled movie. Give the selected movie
                # its own startup allowance after the intro ends or is skipped.
                self.created=self.clock()
                self.cover(attempt)
            done=not (pending and pending.get('failed')) and self.clock()-self.created>=50
            if not done:
                elapsed = int(max(0, self.clock() - self.created))
                if elapsed != self.elapsed:
                    self.elapsed = elapsed
                    text=('That source failed. Please wait or cancel.' if pending and pending.get('failed') else
                          'This source is taking longer. You can cancel and choose another.' if elapsed >= 15 else 'Opening your selected source')
        if done:self.finish(attempt)
        else:
            if text:self.hint(text)
            self.observe(pending,ready=ready,attempt=attempt)
    def cancel(self,attempt=None,window=None):
        with self.lock:
            if window is not None:
                if window is not self.window:return
                attempt=self.attempt
            if not attempt:return
            if self.attempt!=attempt:return
            signal_cancel(attempt)
            callback=self.on_cancel
            self.cancel_done.clear()
            # Consume ownership atomically with the token. A simultaneous
            # search-to-playback advance cannot retarget a cancelled dialog.
            window=self._detach()
        from lib.playback_timing import mark
        mark(attempt,'cancelled')
        self._hide(window)
        # Return from Kodi's onAction immediately. It holds this dialog's native
        # object lock; a provider can hold the parent lock while updating it.
        # Native close can itself block behind Kodi's resolver/window locks.
        # Revoke the actual work independently: never queue cancellation behind
        # a close that is waiting for the very playback operation being stopped.
        finished=[False,False]
        def complete(index):
            with self.lock:
                finished[index]=True
                if all(finished):self.cancel_done.set()
        def close():
            try:self._close(window)
            finally:complete(0)
        def cleanup():
            try:
                callback()
            except Exception:pass
            finally:complete(1)
        try:
            self.thread_factory(target=close,daemon=True).start()
            close_started=True
        except RuntimeError:
            close_started=False
        if not close_started:
            # A constrained device may refuse another thread. Revoke playback
            # first, then close on the cleanup worker rather than losing Cancel.
            def cleanup_then_close():
                try:cleanup()
                finally:close()
            cleanup_target=cleanup_then_close
        else:
            cleanup_target=cleanup
        try:self.thread_factory(target=cleanup_target,daemon=True).start()
        except RuntimeError:
            # With no worker capacity left, complete cancellation on this thread.
            # Keep native close after the playback cleanup in that fallback.
            cleanup_target()
    def observe(self,pending,ready=None,attempt=None):
        if pending and pending.get('failed'):return
        started=pending and pending.get('started')
        with self.lock:
            if attempt is not None and self.attempt!=attempt:return
            attempt=self.attempt
            done=attempt and (not pending or pending.get('attempt')!=attempt or started or ready)
        if done:
            if started or ready:self.finish_started(attempt)
            else:self.finish(attempt)
    def finish_started(self,attempt):
        """Keep startup covered until Kodi has restored fullscreen video."""
        with self.lock:
            if self.attempt!=attempt:return
            if self.video_started_at is None:self.video_started_at=self.clock()
            elapsed=self.clock()-self.video_started_at
            try:
                import xbmc
                visible=xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)') is True
            except (ImportError,AttributeError,RuntimeError):visible=False
            if not visible:
                # A visible closing intro is not the active feature window.
                # Ask Kodi to restore fullscreen under our existing cover,
                # instead of dropping it on a timer and exposing the hero.
                if not self.fullscreen_requested:
                    try:
                        xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
                        self.fullscreen_requested=True
                    except (NameError,AttributeError,RuntimeError):pass
                return
            if self.covered and elapsed<.35:return
        self.finish(attempt)
    def finish(self,attempt=None,lifetime=None):
        with self.lock:
            if attempt is not None and self.attempt!=attempt:return
            if lifetime is not None and self.lifetime is not lifetime:return
            window=self._detach()
        self._close(window)
    def _detach(self):
        window=self.window;token=self.visibility_token;lifetime=self.lifetime
        self.window=None;self.attempt='';self.lifetime=None;self.visibility_token=''
        self.wake.set()
        self.rotation_wake.set()
        return window,token,lifetime
    @staticmethod
    def _hide(owned):
        window,token,lifetime=owned
        if window:
            window.dismissed=True
        # Hide before a potentially queued/blocking native close. Never let
        # a stale dialog's final frame cover a new card or the video.
        if token:_busy_owner(token,clear=True)
    @staticmethod
    def _close(owned):
        window,token,lifetime=owned
        LoadingSession._hide(owned)
        if window:
            try:window.close()
            except Exception:pass
        if lifetime:lifetime.set()


def video_running(player,pending,fullscreen=False):
    """Yield to owned progressing video if AVStarted is missed."""
    if not pending:return False
    if pending.get('automatic') and not pending.get('started'):return False
    try:
        if not player.isPlayingVideo():return False
        # Fullscreen can already be active while a heavy decoder is opening.
        # Without AVStarted, require actual progress before yielding the card.
        from lib.native_playback import busy
        resume=max(0,float(pending.get('resume') or 0)/1000.0)
        if busy() or player.getTime()<=resume:return False
        from lib.playback_recovery import opening_attempt
        return bool(opening_attempt(player,pending))
    except (RuntimeError,AttributeError,KeyError,TypeError,ValueError):return False
