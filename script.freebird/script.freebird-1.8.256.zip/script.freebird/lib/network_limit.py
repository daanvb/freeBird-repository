"""Device-local source ceilings; no speed tests, shell commands or network calls."""
from pathlib import Path
import re

MBPS = (5, 10, 15, 20, 25, 30, 40, 50, 75, 100, 150, 200)
SETTING_IDS = ('source_bitrate_mode', 'source_bitrate_mbps', 'source_bitrate_unknown')


def _read(path):
    try:
        with open(path, encoding='ascii', errors='replace') as stream:
            data = stream.read(65537)
        return data if len(data) <= 65536 else None
    except (OSError, ValueError):
        return None


def _routes(data, ipv6=False):
    """Lowest-metric usable default routes; tied interfaces stay ambiguous."""
    candidates = []
    for line in (data or '').splitlines():
        fields = line.split()
        try:
            if ipv6:
                if len(fields) != 10 or fields[0] != '0' * 32 or fields[1] != '00':
                    continue
                # Source-specific routes do not establish a general default.
                if fields[2] != '0' * 32 or fields[3] != '00':
                    continue
                interface, metric, flags = fields[9], int(fields[5], 16), int(fields[8], 16)
            else:
                if len(fields) < 8 or fields[1] != '00000000' or fields[7] != '00000000':
                    continue
                interface, metric, flags = fields[0], int(fields[6]), int(fields[3], 16)
            if flags & 1 and not flags & 0x200 and interface != 'lo' and metric >= 0:
                candidates.append((metric, interface))
        except (ValueError, IndexError):
            continue
    if not candidates:
        return set()
    best = min(metric for metric, _ in candidates)
    return {name for metric, name in candidates if metric == best}


def connection():
    """Best-effort Linux/CoreELEC/Android detection; inaccessible means unknown.

    Android 10+ commonly denies proc access. Never infer an active route merely
    from an installed Wi-Fi adapter, SSID, link speed or interface availability.
    VPNs, mixed default routes and unrecognised interfaces remain unknown.
    """
    v4, v6 = _read('/proc/net/route'), _read('/proc/net/ipv6_route')
    if v4 is None or v6 is None:
        return 'unknown'
    # Split-tunnel VPNs can keep the physical default while routing internet
    # prefixes elsewhere. Do not remove the cap based on that default alone.
    for data, position in ((v4, 0), (v6, -1)):
        for line in data.splitlines():
            fields = line.split()
            if fields and re.match(r'^(tun|tap|wg|ppp|vpn|tailscale)', fields[position]):
                return 'unknown'
    interfaces = _routes(v4) | _routes(v6, ipv6=True)
    if len(interfaces) != 1:
        return 'unknown'
    name = next(iter(interfaces))
    if not re.fullmatch(r'[A-Za-z0-9_.-]{1,32}', name):
        return 'unknown'
    base = Path('/sys/class/net') / name
    if (_read(base / 'carrier') or '').strip() != '1':
        return 'unknown'
    try:
        if (base / 'wireless').is_dir() or (base / 'phy80211').exists():
            return 'wifi'
    except OSError:
        return 'unknown'
    # ARPHRD_ETHER alone also describes Wi-Fi: require a wired interface name.
    if re.fullmatch(r'(?:eth\d+|en[a-zA-Z0-9_.-]+)', name) and (_read(base / 'type') or '').strip() == '1':
        return 'ethernet'
    return 'unknown'


def policy(addon):
    mode = addon.getSetting('source_bitrate_mode')
    if mode not in ('1', '2'):
        return {'bps': 0, 'allow_unknown': True, 'connection': 'unchecked', 'mode': 'off'}
    try:
        index = int(addon.getSetting('source_bitrate_mbps') or '4')
        mbps = MBPS[index] if 0 <= index < len(MBPS) else 25
    except (TypeError, ValueError):
        mbps = 25
    kind = connection() if mode == '2' else 'unchecked'
    return {'bps': 0 if kind == 'ethernet' else mbps * 1000000,
            'allow_unknown': addon.getSetting('source_bitrate_unknown') == 'true',
            'connection': kind, 'mode': 'automatic' if mode == '2' else 'manual'}


def summary(addon):
    current = policy(addon)
    if current['mode'] == 'off':
        return 'Off'
    if current['connection'] == 'ethernet':
        return 'Ethernet detected - no bitrate cap'
    prefix = {'wifi': 'Wi-Fi detected', 'unknown': 'Connection unknown; fallback',
              'unchecked': 'Manual'}.get(current['connection'], 'Manual')
    return '{} - {} Mbps'.format(prefix, current['bps'] // 1000000)
