"""Bounded, asynchronous download measurements shared by freeBird's UI process.

No SSIDs, addresses, credentials or samples are persisted or logged. Kodi's
portable network labels provide a change hint, not a guaranteed network ID.
"""
import hashlib
import math
import socket
import threading
import time
from urllib.request import Request, HTTPRedirectHandler, build_opener

URL = 'https://speed.cloudflare.com/__down'
MAX_BYTES = 16 * 1024 * 1024
TEST_SECONDS = 8.0
WAIT_SECONDS = 12.0
TTL = 300.0
RETRY_SECONDS = 60.0
HEADROOM = 0.70


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def measure(cancelled, opener=None, clock=time.monotonic):
    """Read/discard at most 16 MiB; include setup/stalls in the estimate.

    Socket timeouts bound each blocking operation, with an overall read deadline.
    DNS can outlive that deadline on some OSes; the caller never waits beyond
    WAIT_SECONDS and never creates another worker while the old one is alive.
    """
    if cancelled():return None
    opener = opener or build_opener(NoRedirect())
    start = clock()
    request = Request(URL + '?bytes=' + str(MAX_BYTES), headers={
        'User-Agent': 'freeBird-throughput/1', 'Accept-Encoding': 'identity',
        'Cache-Control': 'no-cache'})
    total, window_bytes, windows = 0, 0, []
    window_start = start
    try:
        with opener.open(request, timeout=1.5) as response:
            if (response.getcode() != 200 or response.geturl() != request.full_url
                    or response.headers.get('Content-Type', '').split(';')[0].lower() != 'application/octet-stream'
                    or response.headers.get('Content-Encoding', 'identity').lower() != 'identity'
                    or int(response.headers.get('Content-Length', '0')) != MAX_BYTES):
                return None
            while total < MAX_BYTES and clock() - start < TEST_SECONDS:
                if cancelled():return None
                try:
                    chunk = response.read(min(65536, MAX_BYTES - total))
                except (socket.timeout, TimeoutError):
                    break
                if not chunk:
                    if total != MAX_BYTES:return None
                    break
                total += len(chunk)
                window_bytes += len(chunk)
                now = clock()
                if now - window_start >= 1.0:
                    windows.append(window_bytes * 8 / (now - window_start))
                    window_bytes, window_start = 0, now
    except Exception:
        return None
    if cancelled() or total < 65536:return None
    elapsed = max(clock() - start, 0.25)
    overall = total * 8 / elapsed
    # Lower quartile avoids treating a brief burst as sustained capacity.
    conservative = sorted(windows)[(len(windows) - 1) // 4] if windows else overall
    return min(overall, conservative)


class Meter:
    def __init__(self, sampler=measure, clock=time.monotonic):
        self.sampler, self.clock = sampler, clock
        self.lock = threading.Lock()
        self.key = None
        self.rate = None
        self.finished = None
        self.status = 'unmeasured'
        self.worker = None
        self.stop = threading.Event()
        self.started = 0
        self.generation = 0

    def snapshot(self, key, busy, allowed, force=False, cancelled=lambda:False):
        thread = None
        now = self.clock()
        with self.lock:
            if key != self.key or force or not allowed:
                self.stop.set()
                self.generation += 1
                self.key, self.rate, self.finished = key, None, None
                self.status = 'unmeasured'
            if self.worker is not None and now - self.started >= WAIT_SECONDS:
                self.stop.set()
                self.rate, self.finished, self.status = None, now, 'failed'
            if not allowed:
                return dict(status='unavailable', bps=None)
            if self.worker is not None and self.status == 'unmeasured' and not busy:
                self.status = 'measuring'  # Wait for cancelled old work to exit.
            age = now - self.finished if self.finished is not None else float('inf')
            fresh = 0 <= age < (TTL if self.rate else RETRY_SECONDS)
            if not fresh and self.worker is None and not busy:
                self.rate, self.status = None, 'measuring'
                self.stop = threading.Event()
                token, stop = self.generation, self.stop
                self.started = now
                def work():
                    try:
                        value = self.sampler(lambda: stop.is_set() or cancelled())
                    except Exception:
                        value = None
                    with self.lock:
                        self.worker = None
                        if token != self.generation or stop.is_set():return
                        valid = type(value) in (float, int) and math.isfinite(value) and 0 < value < 1e10
                        self.rate = value if valid else None
                        self.finished = self.clock()
                        self.status = 'measured' if valid else 'failed'
                thread = threading.Thread(target=work, daemon=True)
                self.worker = thread
            if busy and self.worker is not None:
                self.stop.set()
                self.generation += 1
                self.status = 'deferred'
            rate = self.rate if fresh else None
            status = 'deferred' if busy and not rate else self.status
            result = dict(status=status, bps=rate)
        if thread is not None:
            try:thread.start()
            except RuntimeError:
                with self.lock:
                    self.worker = None
                    self.finished, self.status = self.clock(), 'failed'
                return dict(status='failed', bps=None)
        return result


METER = Meter()


def environment():
    """Portable labels work even when Android denies /proc/net access."""
    try:
        import xbmc
        playing = xbmc.Player().isPlaying()
        abort = xbmc.Monitor().abortRequested()
        labels = [xbmc.getInfoLabel('Network.' + name) for name in
                  ('IPAddress', 'GatewayAddress', 'SubnetMask')]
        if type(playing) is not bool or type(abort) is not bool or not all(isinstance(v, str) for v in labels):
            return None, True, True
        from lib.network_limit import connection
        labels.append(connection())
        digest = hashlib.sha256('\0'.join(labels).encode('utf-8')).hexdigest()
        return digest, playing, abort
    except Exception:
        return None, True, True


def snapshot(addon, force=False):
    key, busy, abort = environment()
    allowed = addon.getSetting('source_bitrate_mode') == '2' and not abort
    def cancelled():
        current_key, playing, stopping = environment()
        return (playing or stopping or current_key != key
                or addon.getSetting('source_bitrate_mode') != '2')
    return METER.snapshot(key, busy, allowed, force, cancelled)


def wait(addon, cancelled=lambda:False):
    """Only call from a background search worker; UI threads never wait."""
    if addon.getSetting('source_bitrate_mode') != '2':return
    deadline = time.monotonic() + WAIT_SECONDS
    while not cancelled() and time.monotonic() < deadline:
        if snapshot(addon)['status'] != 'measuring':return
        time.sleep(0.1)


def cap(rate):
    return max(1, int(rate * HEADROOM))
