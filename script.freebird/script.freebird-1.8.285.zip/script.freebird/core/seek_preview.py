"""Optional, bounded keyframe extraction. No Kodi/player calls or source logging.

FFmpeg only sees a loopback URL. The existing range reader owns authentication,
redirects and cancellation; playlists and non-range HTTP servers are rejected.
"""
from collections import OrderedDict, deque
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
import os
import math
from pathlib import Path
import re
import shutil
import socket
import subprocess
import threading
import time
import uuid

from core.file_chapters import Reader, Unavailable

# A new HTTP request per 128 KiB exhausted the five-second frame deadline on
# ordinary high-latency 4K streams. Keep the same byte/cache limits, but amortise
# connection/response latency across larger bounded reads.
BLOCK = 512 * 1024
FRAME_BYTES = 8 * 1024 * 1024
RATE_BYTES = 64 * 1024 * 1024
RATE_SECONDS = 60
MEMORY_BYTES = 8 * 1024 * 1024
CACHE_BYTES = 64 * 1024 * 1024
FRAME_SECONDS = 5


class PreviewFailure(Unavailable):
    """A fixed public reason, never an upstream address or exception message."""
    def __init__(self, reason, evidence=None):
        if not isinstance(reason, str) or reason not in {'timeout', 'range', 'network', 'read_limit', 'container', 'budget'}:
            raise ValueError('Unknown preview failure reason')
        self.reason = reason
        self.evidence = evidence
        super().__init__('Preview '+reason)


def create_decoder(backend, source):
    if backend.startswith('native:'):
        from core.native_preview import NativeDecoder
        return NativeDecoder(backend, source)
    return Decoder(backend, source)


def find_decoder(translate=lambda path: path):
    """Use an installed executable only; never download or chmod binaries."""
    candidates = [shutil.which('ffmpeg')]
    for addon in ('tools.ffmpeg-tools', 'tools.ffmpeg'):
        candidates.append(translate('special://home/addons/{}/bin/ffmpeg'.format(addon)))
    for candidate in candidates:
        if candidate and Path(candidate).is_file() and os.access(candidate, os.X_OK):
            return str(candidate)
    return None


class PreviewReader(Reader):
    # Preview reads share the frame deadline, not the metadata reader's short
    # per-socket ceiling. The UI remains independent of this worker.
    socket_seconds = FRAME_SECONDS

    def __init__(self, source, **kwargs):
        super().__init__(source, **kwargs)
        self.cache = OrderedDict()
        self.spent = 0
        self.recent = deque()
        self.recent_bytes = 0
        self.frame_bytes = 0
        self.failure = None
        self.lock = threading.Lock()
        self.begin(self.alive)

    def _expire_reads(self):
        now = self.clock()
        while self.recent and now-self.recent[0][0] >= RATE_SECONDS:
            self.recent_bytes -= self.recent.popleft()[1]

    def cooldown(self):
        """Reserve enough rate allowance for one bounded picture; never reset totals."""
        with self.lock:
            self._expire_reads()
            needed = self.recent_bytes + FRAME_BYTES - RATE_BYTES
            for at, size in self.recent:
                if needed <= 0:
                    break
                needed -= size
                if needed <= 0:
                    return max(0, at + RATE_SECONDS-self.clock())
            return 0

    def begin(self, alive):
        self.alive = alive
        self.attempt_started = self.clock()
        self.deadline = self.attempt_started + FRAME_SECONDS
        self.frame_bytes = self.requests = 0
        self.failure = None
        self.phase = 'header'
        self.received_bytes = self.cache_hits = 0
        self.read_seconds, self.read_started = 0, None

    def received(self, size):
        self.received_bytes += size

    def evidence(self):
        # No lock: the decoder poller must not wait behind an upstream read.
        # Capture before cancellation/cleanup clears the active-read flag.
        now = self.clock()
        active = self.read_started
        reading = self.read_seconds + (max(0, now-active) if active is not None else 0)
        elapsed = max(0, now-self.attempt_started)
        return dict(wait='header' if self.phase == 'header' else 'stream' if active is not None else 'frame',
                    elapsed_ms=int(elapsed*1000), read_ms=int(min(elapsed, reading)*1000),
                    received_bytes=self.received_bytes, requests=self.requests, cache_hits=self.cache_hits)

    def check(self):
        if not self.alive():
            raise Unavailable('Preview cancelled')
        if self.failure is not None:
            raise self.failure
        if self.clock() >= self.deadline:
            raise PreviewFailure('timeout', self.evidence())

    def remote(self, offset, wanted):
        started = self.clock()
        self.read_started = started
        try:
            return super().remote(offset, wanted)
        except PreviewFailure:
            raise
        except Unavailable as error:
            if str(error) in ('Byte ranges unavailable', 'Inconsistent metadata range',
                              'Media changed during metadata read'):
                raise PreviewFailure('range') from None
            raise
        except OSError as error:
            timed_out = isinstance(error, TimeoutError) or isinstance(getattr(error, 'reason', None), TimeoutError)
            raise PreviewFailure('timeout' if timed_out else 'network', self.evidence()) from None
        finally:
            self.read_seconds += max(0, self.clock()-started)
            self.read_started = None

    def chunk(self, offset):
        with self.lock:
            try:
                return self._chunk(offset)
            except PreviewFailure as error:
                # The loopback HTTP thread cannot pass exceptions directly to
                # the decoder poller. Preserve only our fixed, public reason.
                self.failure = error
                raise

    def _chunk(self, offset):
        self.check()
        start = offset // BLOCK * BLOCK
        if start in self.cache:
            self.cache_hits += 1
            self.cache.move_to_end(start)
            return self.cache[start][offset-start:]
        length = BLOCK if self.total is None else min(BLOCK, self.total-start)
        if length <= 0:
            return b''
        self._expire_reads()
        if self.recent_bytes + length > RATE_BYTES:
            raise PreviewFailure('budget')
        if self.frame_bytes + length > FRAME_BYTES or self.requests >= 80:
            raise PreviewFailure('read_limit')
        self.requests += 1
        # Charge before I/O, including failed/partial responses.
        self.frame_bytes += length
        self.spent += length
        self.recent.append((self.clock(), length))
        self.recent_bytes += length
        if self.local is not None:
            with self.local.open('rb') as handle:
                handle.seek(start)
                data = handle.read(length)
                self.received(len(data))
        else:
            data = self.remote(start, length)
        self.check()
        self.cache[start] = data
        while len(self.cache) * BLOCK > MEMORY_BYTES:
            self.cache.popitem(last=False)
        return data[offset-start:]


class RangeServer(ThreadingMixIn, HTTPServer):
    """One decoder, at most two reads (FFmpeg may overlap a seek connection)."""
    allow_reuse_address = False
    daemon_threads = False

    def __init__(self, *args):
        self.slots = threading.BoundedSemaphore(2)
        super().__init__(*args)

    def get_request(self):
        connection, address = super().get_request()
        try:
            # A large loopback send buffer fetches megabytes beyond the header
            # before FFmpeg can close it and seek. Bound speculative read-ahead.
            connection.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 32*1024)
            connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError:
            connection.close()
            raise
        return connection, address

    def process_request(self, request, address):
        if not self.slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, address)
        except Exception:
            self.slots.release()
            raise

    def process_request_thread(self, request, address):
        try:
            super().process_request_thread(request, address)
        finally:
            self.slots.release()

    def handle_error(self, request, address):
        pass


class Decoder:
    def __init__(self, binary, source, reader_factory=PreviewReader):
        self.binary = binary
        self.reader = reader_factory(source)
        self.server = None
        self.server_thread = None
        self.token = '/' + uuid.uuid4().hex

    def _serve(self):
        reader, token = self.reader, self.token

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                if self.path != token:
                    self.send_error(404)
                    return
                try:
                    self.connection.settimeout(1)
                    reader.check()
                    match = re.fullmatch(r'bytes=(\d+)-(\d*)', self.headers.get('Range', 'bytes=0-'))
                    if not match:
                        self.send_error(416)
                        return
                    start = int(match[1])
                    end = min(int(match[2]) if match[2] else reader.total-1, reader.total-1)
                    if start > end or start < 0:
                        self.send_error(416)
                        return
                    self.send_response(206 if 'Range' in self.headers else 200)
                    self.send_header('Accept-Ranges', 'bytes')
                    self.send_header('Content-Range', 'bytes {}-{}/{}'.format(start, end, reader.total))
                    self.send_header('Content-Length', str(end-start+1))
                    self.send_header('Connection', 'close')
                    self.end_headers()
                    while start <= end:
                        data = reader.chunk(start)[:end-start+1]
                        if not data:
                            return
                        self.wfile.write(data)
                        start += len(data)
                except (OSError, ValueError):
                    pass
                finally:
                    self.close_connection = True

        self.server = RangeServer(('127.0.0.1', 0), Handler)
        self.server_thread = threading.Thread(target=self.server.serve_forever,
                                              kwargs={'poll_interval': .05}, daemon=True)
        self.server_thread.start()

    def extract(self, target, destination, alive):
        self.reader.begin(alive)
        header = self.reader.chunk(0)
        # Pin the demuxer: a URL returning an HLS/DRM playlist must never cause
        # FFmpeg to fetch child URLs or open another protocol.
        if header.startswith(b'\x1a\x45\xdf\xa3'):
            container = 'matroska'
        elif header[4:8] in (b'ftyp', b'moov', b'wide', b'free'):
            container = 'mov'
        else:
            raise Unavailable('Preview container unsupported')
        self.reader.phase = 'frame'
        if self.server is None:
            self._serve()
        url = 'http://127.0.0.1:{}{}'.format(self.server.server_port, self.token)
        # Fast input seek and keyframes only. Preview times are approximate;
        # the UI never changes the user's actual requested seek position.
        command = [self.binary, '-hide_banner', '-loglevel', 'quiet', '-nostdin',
                   '-threads', '1', '-filter_threads', '1', '-rw_timeout', '2000000',
                   '-protocol_whitelist', 'http,tcp', '-f', container,
                   '-ss', str(max(0, target)), '-noaccurate_seek', '-skip_frame', 'nokey',
                   '-i', url, '-map', '0:v:0', '-an', '-sn', '-dn', '-frames:v', '1',
                   '-vf', 'scale=384:216:force_original_aspect_ratio=decrease',
                   '-threads', '1', '-q:v', '5', '-fs', '524288', '-f', 'image2', '-y', str(destination)]
        process = None
        try:
            process = subprocess.Popen(command, stdin=subprocess.DEVNULL,
                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                       creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            while process.poll() is None:
                self.reader.check()
                time.sleep(.04)
            self.reader.check()
            return process.returncode == 0 and valid_image(destination)
        finally:
            if process is not None and process.poll() is None:
                process.kill()
                process.wait(timeout=2)
            self.reader.alive = lambda: False
            # Join the HTTP readers before resetting their per-frame
            # budget/cancellation predicate for another extraction.
            self._stop_server()

    def _stop_server(self):
        if self.server is not None:
            self.server.shutdown()
            self.server.server_close()
            self.server = None
        if self.server_thread is not None:
            self.server_thread.join(timeout=3)
            self.server_thread = None

    def close(self):
        self.reader.alive = lambda: False
        self._stop_server()


def valid_image(path):
    try:
        path = Path(path)
        if not 100 <= path.stat().st_size <= 524288:
            return False
        with path.open('rb') as handle:
            start = handle.read(2)
            handle.seek(-2, 2)
            return start == b'\xff\xd8' and handle.read(2) == b'\xff\xd9'
    except OSError:
        return False


class Cache:
    """Exact-source hashes only. Atomic JPEGs; bounded, expiring device storage."""
    def __init__(self, root, key):
        if not re.fullmatch('[a-f0-9]{64}', key):
            raise ValueError('Invalid preview identity')
        self.root = Path(root) / 'seek-previews'
        self.directory = self.root / key
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.images = {}
        self.timestamps = {}
        for path in self.directory.glob('*.jpg'):
            match = re.fullmatch(r'(\d{1,6})(?:-(\d{1,9}))?', path.stem)
            if match and valid_image(path):
                target = int(match[1])
                self.images[target] = str(path)
                self.timestamps[target] = int(match[2])/1000.0 if match[2] else target
        self.trim()

    def trim(self):
        rows = []
        for folder in self.root.iterdir():
            if not re.fullmatch('[a-f0-9]{64}', folder.name) or folder.is_symlink() or not folder.is_dir():
                continue
            for path in folder.iterdir():
                if path.is_symlink() or not re.fullmatch(r'\d{1,6}(?:-\d{1,9})?\.(jpg|part)', path.name):
                    continue
                try:
                    stat = path.stat()
                    if path.suffix == '.part' or time.time()-stat.st_mtime > 7*86400:
                        path.unlink()
                    else:
                        rows.append((stat.st_mtime, stat.st_size, path))
                except OSError:
                    pass
        total = sum(row[1] for row in rows)
        for _, size, path in sorted(rows):
            if total <= CACHE_BYTES:
                break
            try:
                path.unlink()
                total -= size
            except OSError:
                pass
        self.images = {t: p for t, p in self.images.items() if Path(p).is_file()}
        self.timestamps = {t: self.timestamps.get(t, t) for t in self.images}

    def make(self, target, decoder, alive):
        path = self.directory / '{}.jpg'.format(target)
        temporary = path.with_suffix('.part')
        try:
            if decoder.extract(target, temporary, alive) and alive():
                actual = getattr(decoder, 'actual_time', None)
                actual = actual if type(actual) in (int, float) and math.isfinite(actual) and 0 <= actual < 86400 else target
                if actual != target:
                    path = self.directory / '{}-{}.jpg'.format(target, int(actual*1000))
                os.replace(str(temporary), str(path))
                self.images[target] = str(path)
                self.timestamps[target] = actual
                self.trim()
                return True
            return False
        finally:
            try:
                temporary.unlink()
            except FileNotFoundError:
                pass

    def nearest(self, target, reach=30):
        if not self.images:
            return None
        t = min(self.images, key=lambda t: abs(self.timestamps.get(t, t)-target))
        actual = self.timestamps.get(t, t)
        return {'time': actual, 'path': self.images[t]} if abs(actual-target) <= reach else None

    def preceding(self, target, reach=5):
        eligible = [t for t in self.images if 0 <= target-self.timestamps.get(t, t) <= reach]
        if not eligible:
            return None
        t = max(eligible, key=lambda t: self.timestamps.get(t, t))
        return {'time': self.timestamps.get(t, t), 'path': self.images[t]}
