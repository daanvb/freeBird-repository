"""Native VFS decoder adapter; all extraction runs on the preview worker.

All methods run on the preview service worker, never a remote/UI callback.
The caller owns the bounded loopback proxy and its lifetime.
"""
import json
import re
import uuid
import time
from pathlib import Path
from core.seek_preview import Decoder, FRAME_SECONDS, PreviewFailure, valid_image

MAX_REPLY = 524288 + 64
PREFIX = 'freebirdpreview://'


class NativeUnavailable(RuntimeError):
    pass


def kodi_request(url):
    import xbmcvfs
    handle = xbmcvfs.File(url)
    try:
        return bytes(handle.readBytes(MAX_REPLY + 1))
    finally:
        handle.close()


class Client:
    def __init__(self, request=kodi_request, prefix=PREFIX):
        self.request = request
        self.prefix = prefix
        self.current = None

    def _call(self, path):
        result = self.request(self.prefix + path)
        if not isinstance(result, (bytes, bytearray)) or len(result) > MAX_REPLY:
            raise NativeUnavailable('Invalid native response')
        return bytes(result)

    def capabilities(self):
        try:
            value = json.loads(self._call('capabilities/'))
        except (ValueError, TypeError) as error:
            raise NativeUnavailable('Native decoder unavailable') from error
        if (not isinstance(value, dict) or type(value.get('protocol')) is not int or
                value['protocol'] != 1):
            raise NativeUnavailable('Unsupported native protocol')
        return value

    def start(self, port, token, container, milliseconds):
        if self.current is not None:
            raise NativeUnavailable('A native request is already owned')
        if (type(port) is not int or not 1024 <= port <= 65535 or
                not isinstance(token, str) or not re.fullmatch('[0-9a-f]{32}', token) or
                container not in ('matroska', 'mov') or type(milliseconds) is not int or
                not 0 <= milliseconds <= 604800000):
            raise ValueError('Invalid native request')
        request_id = uuid.uuid4().hex
        reply = self._call('start/{}/{}/{}/{}/{}'.format(
            request_id, port, token, container, milliseconds))
        if reply == b'busy\n':
            return False
        if reply != b'accepted\n':
            raise NativeUnavailable('Native decoder rejected request')
        self.current = request_id
        return True

    def poll(self):
        if self.current is None:
            raise NativeUnavailable('No native request')
        reply = self._call('result/' + self.current)
        if reply == b'pending\n':
            return None
        if reply == b'timeout\n':
            raise PreviewFailure('timeout')
        try:
            magic, stamp, jpeg = reply.split(b'\n', 2)
            if (magic != b'FBP1' or not re.fullmatch(b'[0-9]{1,12}', stamp) or
                    not 100 <= len(jpeg) <= 524288 or not jpeg.startswith(b'\xff\xd8') or
                    not jpeg.endswith(b'\xff\xd9')):
                raise ValueError('frame')
            timestamp = int(stamp)
            if timestamp > 604800000:
                raise ValueError('timestamp')
        except ValueError as error:
            raise NativeUnavailable('Native frame unavailable') from error
        return timestamp, jpeg

    def cancel(self):
        if self.current is not None:
            self._call('cancel/' + self.current)

    def release(self):
        if self.current is None:
            return True
        reply = self._call('release/' + self.current)
        if reply == b'busy\n':
            return False
        if reply not in (b'released\n', b'missing\n'):
            raise NativeUnavailable('Invalid release response')
        self.current = None
        return True


class NativeDecoder(Decoder):
    """Reuse the authenticated range proxy; never give native code source URLs."""
    def __init__(self, backend, source, client=None, **kwargs):
        super().__init__(None, source, **kwargs)
        self.client = client or Client(prefix=backend[len('native:'):]+'://')
        self.client.capabilities()
        self.actual_time = None
        self.busy = False

    def extract(self, target, destination, alive):
        self.actual_time = None
        self.busy = False
        # An interrupted old job must finish before resetting the reader budget.
        if not self.client.release():
            self.busy = True
            return False
        self.reader.begin(alive)
        try:
            header = self.reader.chunk(0)
            if header.startswith(b'\x1a\x45\xdf\xa3'):
                container = 'matroska'
            elif header[4:8] in (b'ftyp', b'moov', b'wide', b'free'):
                container = 'mov'
            else:
                raise PreviewFailure('container')
            self.reader.phase = 'frame'
            self._serve()
            if not self.client.start(self.server.server_port, self.token[1:], container,
                                     max(0, int(target*1000))):
                self.busy = True
                return False
            deadline = time.monotonic() + FRAME_SECONDS
            while time.monotonic() < deadline:
                self.reader.check()
                try:
                    result = self.client.poll()
                except NativeUnavailable:
                    self.reader.check()  # Prefer a specific loopback read failure.
                    raise
                if result is not None:
                    stamp, jpeg = result
                    self.reader.check()
                    Path(destination).write_bytes(jpeg)
                    self.actual_time = stamp / 1000.0
                    return valid_image(destination)
                time.sleep(.025)
            raise PreviewFailure('timeout')
        except PreviewFailure as error:
            if error.reason == 'timeout' and error.evidence is None:
                error.evidence = self.reader.evidence()
            raise
        finally:
            self.reader.alive = lambda: False
            try:
                self.client.cancel()
            finally:
                self._stop_server()
                self.client.release()

    def close(self):
        self.reader.alive = lambda: False
        try:
            self.client.cancel()
        finally:
            super().close()
            self.client.release()
